/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.example;
import infovis.io.AbstractReader;
import infovis.panel.ControlPanel;
import infovis.panel.ControlPanelFactory;
import infovis.tree.DefaultTree;
import infovis.tree.io.TreeReaderFactory;
import infovis.tree.visualization.TreemapVisualization;
import infovis.tree.visualization.treemap.Squarified;

import javax.swing.JFrame;

/**
 * Example of Treemap visualization.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class Example2 {
    public static void main(String[] args) {
        String fileName =
            (args.length == 0) ? "data/salivary.tqd" : args[0];
        DefaultTree t = new DefaultTree();
        AbstractReader reader =
            TreeReaderFactory.createTreeReader(fileName, t);
        if (reader == null || !reader.load()) {
            System.err.println("cannot load " + fileName);
        }

        TreemapVisualization visualization =
            new TreemapVisualization(t, null, Squarified.SQUARIFIED);
        ControlPanel control =
            ControlPanelFactory.createControlPanel(
                visualization);

        JFrame frame = new JFrame(fileName);
        frame.getContentPane().add(control);
        frame.setVisible(true);
        frame.pack();
    }
}
