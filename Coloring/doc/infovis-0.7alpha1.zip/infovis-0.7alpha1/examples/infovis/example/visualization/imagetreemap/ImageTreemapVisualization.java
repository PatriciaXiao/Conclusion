/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/

package infovis.example.visualization.imagetreemap;
import infovis.Tree;
import infovis.column.*;
import infovis.tree.io.DirectoryTreeReader;
import infovis.tree.visualization.TreemapVisualization;
import infovis.tree.visualization.treemap.BorderDrawer;
import infovis.tree.visualization.treemap.Treemap;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.util.HashSet;

/**
 * Displays a directory tree as a treemap with thumbnail images inside
 * the treemap.
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class ImageTreemapVisualization
    extends TreemapVisualization
    implements ImageObserver {
    protected ObjectColumn imageColumn;
    protected StringColumn urlColumn;
    protected HashSet imageBeingLoaded = new HashSet();
    protected HashSet iconBeingLoaded = new HashSet();
    protected ObjectColumn iconColumn;
    protected Rectangle iconSize = new Rectangle(0, 0, 128, 128);
    protected static Image nullImage = new Image() {
        public void flush() {}
        public Graphics getGraphics() { return null; }
        public int getHeight(ImageObserver observer) { return 0; }
        public Object getProperty(
            String name,
            ImageObserver observer) {
            return null;
        }
        public ImageProducer getSource() { return null; }
        public int getWidth(ImageObserver observer) { return 0; }
    };

    public ImageTreemapVisualization(
        Tree tree,
        NumberColumn size,
        Treemap treemap,
        BorderDrawer border) {
        super(tree, size, treemap, border);
        imageColumn = ObjectColumn.findColumn(tree, "image");
        urlColumn =
            StringColumn.findColumn(
                tree,
                DirectoryTreeReader.COLUMN_PATH);
        iconColumn = ObjectColumn.findColumn(tree, "icon");
    }

    public ImageTreemapVisualization(
        Tree tree,
        NumberColumn size,
        Treemap treemap) {
        this(tree, size, treemap, null);
    }

    public Image getImageAt(int row) {
        if (imageColumn.isValueUndefined(row))
            return null;
        return (Image) imageColumn.get(row);
    }

    public void setImageAt(int row, Image img) {
        imageColumn.setExtend(row, img);
    }

    public String getURLAt(int row) {
        return urlColumn.get(row);
    }

    public Image getIconAt(int row) {
        if (iconColumn.isValueUndefined(row))
            return null;
        return (Image) iconColumn.get(row);
    }

    public void setIconAt(int row, Image img) {
        iconColumn.setExtend(row, img);
    }

    public boolean isImage(String url) {
        return url.endsWith(".png")
            || url.endsWith("PNG")
            || url.endsWith(".jpg")
            || url.endsWith(".JPG")
            || url.endsWith(".jpeg")
            || url.endsWith(".JPEG")
            || url.endsWith(".gif")
            || url.endsWith(".GIF");
    }

    public Image loadImage(int row) {
        Image img = getImageAt(row);
        if (img == null) {
            if (imageBeingLoaded.size() > 3)
                return null;
            String url = getURLAt(row);
            if (!isImage(url))
                return null;
            img = Toolkit.getDefaultToolkit().getImage(url);
            if (img == null) {
                img = nullImage;
            }
            else {
                imageBeingLoaded.add(img);
            }

            setImageAt(row, img);
        }
        return img;
    }

    public Image loadIcon(int row, Rectangle2D bounds) {
        Image icon = getIconAt(row);
        if (icon != null) {
            Image img = getImageAt(row);
            // Remove the image if the icon if fully computed
            if (img != null 
                && (!iconBeingLoaded.contains(icon))) {
                setImageAt(row, null);
                img.flush();
            }
            return icon;
        }
        Image img = loadImage(row);
        if (img == null)
            return null;

        int iw = img.getWidth(this);
        int ih = img.getHeight(this);
        if (iw == -1 || ih == -1 || imageBeingLoaded.contains(img)) {
            return null;
        }
        if (iw == 0 && ih == 0)
            return img;
        double sx = bounds.getWidth() / iw;
        double sy = bounds.getHeight() / ih;

        if (sx < sy) {
            sy = sx;
            iw = (int) (bounds.getWidth());
            ih = (int) (ih * sy);
        }
        else {
            sx = sy;
            iw = (int) (iw * sx);
            ih = (int) (bounds.getHeight());
        }
        if (sx > 1) {
            icon = img;
            setImageAt(row, null);
        }
        else {
            icon = img.getScaledInstance(iw, ih, Image.SCALE_FAST);
            iconBeingLoaded.add(icon);
        }
        setIconAt(row, icon);
        return icon;
    }

    public void paintShape(Graphics2D graphics, int row, Shape s) {
        super.paintShape(graphics, row, s);
        Rectangle2D bounds = s.getBounds2D();
        if (bounds.getWidth() < 3 || bounds.getWidth() < 3)
            return; // don't even try        

        Image icon = loadIcon(row, iconSize);
        if (icon == null)
            return;
        int iw = icon.getWidth(this);
        int ih = icon.getHeight(this);
        if (iw == -1 || ih == -1 
            || (iw == 1 && ih == 1))
            return;
        double sx = bounds.getWidth() / iw;
        double sy = bounds.getHeight() / ih;

        if (sx < sy) {
            sy = sx;
            iw = (int) (bounds.getWidth());
            ih = (int) (ih * sy);
        }
        else {
            sx = sy;
            iw = (int) (iw * sx);
            ih = (int) (bounds.getHeight());
        }
        
        System.out.println("Painting " + row);
        int x =
            (int) (bounds.getX()
                + (bounds.getWidth() - iw) / 2);
        int y =
            (int) (bounds.getY()
                + (bounds.getHeight() - ih) / 2);
        graphics.drawImage(icon, x, y, x+iw, y+ih,
            0, 0, icon.getWidth(null), icon.getHeight(null),
            this);
    }
    
    public int find(ObjectColumn imgColumn, Image img) {
        for (int i = 0; i < imgColumn.getRowCount(); i++) {
            if (imgColumn.get(i) == img)
                return i;
        }
        return -1;
    }
    public boolean imageUpdate(
        Image img,
        int infoflags,
        int x,
        int y,
        int width,
        int height) {

        boolean ret = (infoflags & (ALLBITS | ABORT)) == 0;
        if (!ret) {
            if (iconBeingLoaded.remove(img)) {
                System.out.println(
                    "Icon "
                        + find(iconColumn, img)
                        + " finished loading");
            }
            else if (imageBeingLoaded.remove(img)) {
                System.out.println(
                    "Image "
                        + find(imageColumn, img)
                        + " finished loading");
            }
            getParent().repaint();
        }
        return ret;
    }
}