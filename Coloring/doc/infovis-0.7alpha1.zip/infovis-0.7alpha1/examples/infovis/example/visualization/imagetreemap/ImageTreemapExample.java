/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.example.visualization.imagetreemap;

import infovis.Tree;
import infovis.Visualization;
import infovis.column.StringColumn;
import infovis.example.ExampleRunner;
import infovis.tree.DefaultTree;
import infovis.tree.io.DirectoryTreeReader;
import infovis.tree.visualization.treemap.Squarified;

/**
 * Class ImageTreemapExample
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class ImageTreemapExample {
    public static void main(String args[]) {
        ExampleRunner example =
            new ExampleRunner(args, "ImageTreemapVisualization");
        if (example.fileCount() != 1) {
            System.err.println(
                "Syntax: ImageTreemapVisualization <dir>");
            System.exit(1);
        }
        Tree t = new DefaultTree();
        t.addColumn(new StringColumn(DirectoryTreeReader.COLUMN_PATH));
        DirectoryTreeReader reader =
            new DirectoryTreeReader(example.getArg(0), t);
        if (reader.load()) {
            ImageTreemapVisualization visualization =
                new ImageTreemapVisualization(
                    t,
                    null,
                    Squarified.SQUARIFIED);

            visualization.setVisualColumn(
                Visualization.VISUAL_LABEL,
                ExampleRunner.getStringColumn(t, 0));
            example.createFrame(visualization);
        }
        else {
            System.err.println("cannot load " + example.getArg(0));
        }
    }    
}
