/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.example.visualization.graphontreemap;

import infovis.*;
import infovis.column.IntColumn;
import infovis.column.StringColumn;
import infovis.example.ExampleRunner;
import infovis.graph.DefaultGraph;
import infovis.graph.io.HTMLGraphReader;
import infovis.table.DefaultTable;
import infovis.tree.DefaultTree;
import infovis.tree.io.FileListTreeReader;
import infovis.tree.visualization.treemap.Squarified;
import infovis.utils.RowIterator;

import java.io.*;

/**
 * Class GraphOnTreemapExample
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.3 $
 */
public class GraphOnTreemapExample {

    public static void main(String[] args) {
        ExampleRunner example =
            new ExampleRunner(args, "GraphOnTreemapExample");
        if (example.fileCount() > 2) {
            System.err.println(
                "Syntax: GraphAsTreemapExample <root-url> [start-name]");
            System.exit(1);
        }

        String url =
            example.fileCount() == 0
                ? "http://www.lri.fr/~fekete/InfovisToolkit/api/infovis/panel/"
                : example.getArg(0);
        String startPath =
            (example.fileCount() < 2) ? "" : example.getArg(1);

        Graph g = new DefaultGraph();
        HTMLGraphReader reader = new HTMLGraphReader(url, g);

        reader.setLog(new PrintStream(System.out));
        reader.add(startPath);
        if (!reader.load()) {
            System.out.println("Cannot load url " + url);
            System.exit(1);
        }

        Tree tree;
        try {
            tree = extractTree(g, url);

            Table edges = extractEdges(g, tree);

            GraphOnTreemapVisualization visualization =
                new GraphOnTreemapVisualization(
                    tree,
                    edges,
                    null,
                    Squarified.SQUARIFIED,
                    null);

            StringColumn nameColumn =
                StringColumn.findColumn(
                    g.getVertexTable(),
                    HTMLGraphReader.COLUMN_NAME);

            visualization.setVisualColumn(
                Visualization.VISUAL_LABEL,
                nameColumn);
            nameColumn.set(1, null); // remove name of root directory.
            example.createFrame(visualization);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Tree extractTree(Graph g, String prefix)
        throws IOException {
        DefaultTree tree = new DefaultTree();
        StringColumn urlColumn =
            StringColumn.findColumn(
                g.getVertexTable(),
                HTMLGraphReader.COLUMN_URL);
        IntColumn vertexColumn = IntColumn.findColumn(tree, "vertex");

        StringBuffer fileList = new StringBuffer();
        for (int i = 0; i < urlColumn.getRowCount(); i++) {
            fileList.append(urlColumn.get(i));
            fileList.append('\n');
        }
        BufferedReader in =
            new BufferedReader(new StringReader(fileList.toString()));
        FileListTreeReader reader =
            new FileListTreeReader(in, "fileList", tree);
        reader.setPrefix(prefix);
        reader.setIndexColumn(vertexColumn);

        if (reader.load()) {
            return tree;
        }
        return null;
    }

    public static Table extractEdges(Graph g, Tree tree) {
        DefaultTable edges = new DefaultTable();
        IntColumn inColumn =
            IntColumn.findColumn(edges, DefaultGraph.INVERTEX_COLUMN);
        IntColumn outColumn =
            IntColumn.findColumn(edges, DefaultGraph.OUTVERTEX_COLUMN);
        IntColumn vertexColumn = IntColumn.findColumn(tree, "vertex");
        int vertex2node[] = new int[vertexColumn.getRowCount()];
        int node;
        for (node = 0; node < vertexColumn.getRowCount(); node++) {
            if (vertexColumn.isValueUndefined(node))
                continue;
            vertex2node[vertexColumn.get(node)] = node;
        }
        for (node = 0; node < vertexColumn.getRowCount(); node++) {
            if (vertexColumn.isValueUndefined(node))
                continue;
            int vertex = vertexColumn.get(node);
            for (RowIterator iter = g.edgeIterator(vertex); iter.hasNext(); ) {
                int edge = iter.nextRow();
                inColumn.add(node);
                outColumn.add(vertex2node[g.getOutVertex(edge)]);
            }
        }
        return edges;
    }
}
