/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.example.visualization.graphontreemap;
import infovis.*;
import infovis.column.*;
import infovis.graph.DefaultGraph;
import infovis.panel.ControlPanelFactory;
import infovis.tree.visualization.TreemapVisualization;
import infovis.tree.visualization.treemap.BorderDrawer;
import infovis.tree.visualization.treemap.Treemap;
import infovis.visualization.*;
import infovis.visualization.linkShapers.CurvedLinkShaper;

import java.awt.Graphics2D;
import java.awt.Shape;
//import java.awt.event.MouseEvent;
import java.awt.geom.*;

import javax.swing.JComponent;

/**
 * Visualize a web site as a treemap and overlays the non-tree links as quadratic splines.
 * See HCIL-2003-32 report: "Overlaying Graph Links on Treemaps",
 * Jean-Daniel Fekete, David Wang, Niem Dang, Aleks Aris, Catherine Plaisant
 * ftp://ftp.cs.umd.edu/pub/hcil/Reports-Abstracts-Bibliography/2003-32html/2003-32.pdf 
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.4 $
 */
public class GraphOnTreemapVisualization
    extends TreemapVisualization
    implements NodeAccessor {
    protected Table edgeTable;
    protected boolean linksAlwaysVisible = true;
    protected LinkVisualization linkVisualization;
    protected IntColumn inColumn;
    protected IntColumn outColumn;

    static {
        ControlPanelFactory.getInstance().setDefault(
            GraphOnTreemapVisualization.class,
            GraphOnTreemapControlPanel.class);
    }

    public GraphOnTreemapVisualization(
        Tree tree,
        Table edgeTable,
        NumberColumn size,
        Treemap treemap,
        BorderDrawer border) {
        super(tree, size, treemap, border);
        this.edgeTable = edgeTable;

        inColumn =
            IntColumn.findColumn(edgeTable, DefaultGraph.INVERTEX_COLUMN);
        outColumn =
            IntColumn.findColumn(edgeTable, DefaultGraph.OUTVERTEX_COLUMN);

        linkVisualization =
            new LinkVisualization(edgeTable, this, this);
        linkVisualization.setOrientation(ORIENTATION_INVALID);
        linkVisualization.setShowingSelected(true);
        linkVisualization.setLinkShaper(
            new LinkShaper(this, getShapes()));
    }

    public GraphOnTreemapVisualization(
        Tree tree,
        Table edgeTable,
        NumberColumn size,
        Treemap treemap) {
        this(tree, edgeTable, size, treemap, null);
    }

    // NodeAccessor interface    
    public int getStartNode(int link) {
        return inColumn.get(link);
    }

    public int getEndNode(int link) {
        return outColumn.get(link);
    }
    public void paintItems(Graphics2D graphics, Rectangle2D bounds) {
        super.paintItems(graphics, bounds);
        linkVisualization.paint(graphics, bounds);
    }

    public void setParent(JComponent parent) {
        super.setParent(parent);
        linkVisualization.setParent(parent);
    }

    public void dispose() {
        super.dispose();
        linkVisualization.dispose();
    }

    public void setOrientation(int orientation) {
        super.setOrientation(orientation);
        linkVisualization.setOrientation(orientation);
    }

    public void setFisheyes(Fisheyes fisheyes) {
        super.setFisheyes(fisheyes);
        linkVisualization.setFisheyes(fisheyes);
    }
    
    // Remove the following comments for testing an "edgeLens" type of
    // interaction with fisheyes enabled.
    public Shape transformShape(Shape s) {
        return s;
    }


    public Visualization getVisualization(int index) {
        if (index == 0)
            return linkVisualization;
        return null;
    }

    public LinkVisualization getLinkVisualization() {
        return linkVisualization;
    }

    // Comment-out the following two methods to revert to click for selection
//    public void mouseDragged(MouseEvent e) {
//    }
//    
//    public void mouseMoved(MouseEvent e) {
//        super.mouseMoved(e);
//
//        int sel = linkVisualization.pickTop(e.getX(), e.getY(), parent.getBounds());
//        if (sel == NIL) {
//            sel = pickTop(
//                    e.getX(),
//                    e.getY(),
//                    parent.getBounds());
//        }
//        if ((e.getModifiers() & MouseEvent.SHIFT_MASK) == 0)
//            setSelection(sel);
//        else {
//            addSelection(sel);
//        }
//    }

    static class LinkShaper extends CurvedLinkShaper {
        public LinkShaper(
            Visualization visualization,
            ObjectColumn nodeShapes) {
            super(visualization, nodeShapes);
        }
        public Shape createSelfLink(Shape nodeShape) {
            Rectangle2D bounds = nodeShape.getBounds2D();
            Ellipse2D e = new Ellipse2D.Double();
            e.setFrame(bounds);
            return e;
        }

        public Point2D linkStart(
            Shape s,
            int orientation,
            Point2D ptRet) {
            if (ptRet == null) {
                ptRet = new Point2D.Float();
            }
            Rectangle2D bounds = s.getBounds2D();
            ptRet.setLocation(bounds.getCenterX(), bounds.getCenterY());
            return ptRet;
        }
        public Point2D linkEnd(
            Shape s,
            int orientation,
            Point2D ptRet) {
            return linkStart(s, orientation, ptRet);
        }
    }
}
