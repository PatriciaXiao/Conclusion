/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/

package infovis.example;
import infovis.io.AbstractReader;
import infovis.panel.*;
import infovis.table.DefaultTable;
import infovis.table.io.TableReaderFactory;
import infovis.table.visualization.TimeSeriesVisualization;

import javax.swing.JFrame;

/**
 * First Example using the Infovis Toolkit
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */

public class Example1 {
    public static void main(String args[]) {
        String fileName =
            (args.length == 0) ? "data/salivary.tqd" : args[0];
        DefaultTable t = new DefaultTable();
        t.setName(fileName);
        AbstractReader reader =
            TableReaderFactory.createTableReader(fileName, t);
        if (reader == null || !reader.load()) {
            System.err.println("cannot load " + fileName);
            return;
        }
        TimeSeriesVisualization visualization =
            new TimeSeriesVisualization(t);
        VisualizationPanel panel =
            new VisualizationPanel(visualization);
//        ControlPanel panel =
//            ControlPanelFactory.sharedInstance()
//              .createControlPanel(visualization);            
            
        JFrame frame = new JFrame(fileName);
        frame.getContentPane().add(panel);
        frame.setVisible(true);
        frame.pack();
    }
}
