import java.util.Iterator;
import java.util.WeakHashMap;

import infovis.Column;
import infovis.Table;
import infovis.column.IntColumn;
import infovis.table.DefaultTable;
import infovis.utils.RowIterator;
import junit.framework.TestCase;

/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/

/**
 * Class TableTest
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class TableTest extends TestCase {
    public TableTest(String name) {
        super(name);
    }

    public void testCreation() {
        testCreation(new DefaultTable());
    }
    
    public static void testCreation(Table table) {
        int i;
        
        assertNull(table.getName());
        assertEquals(table.getColumnCount(), 0);
        for (i = -1; i < 10; i++) {
            assertNull(table.getColumnAt(i));
        }
        assertEquals(table.getRowCount(), 0);
        RowIterator iter = table.iterator();
        assertTrue(!iter.hasNext());
        iter = table.reverseIterator();
        assertTrue(!iter.hasNext());
        assertEquals(table, table.getTable());
        for (i = -1; i < 10; i++) {
            assertTrue(! table.isRowValid(i));
        }
    }
    
    public void testInvariants() {
        DefaultTable table = new DefaultTable();
        testInvariants(table);
        testClear(table);
    }
    
    public static void testInvariants(Table table) {
        int i;
        final String randomName = "randomName";
        String savedName = table.getName();
        WeakHashMap colMap = new WeakHashMap();
        
        table.setName(randomName);
        assertEquals(table.getName(), randomName);
        table.setName(savedName);
        assertEquals(table.getName(), savedName);
        
        int count = table.getColumnCount();
        int rows = table.getRowCount();
        Column[] cols = new Column[10];
        for (i = 0; i < 10; i++) {
            Column c = new IntColumn(randomName+i);
            cols[i] = c;
            table.addColumn(c);
            colMap.put(c, c.getName());
        }
        assertEquals(table.getColumnCount(), count+10);
        for (i = 0; i < 10; i++) {
            assertEquals(table.getColumnAt(count+i), cols[i]);
            assertEquals(table.getColumn(randomName+i), cols[i]);
            assertEquals(table.indexOf(cols[i]), count+i);
            assertEquals(table.indexOf(randomName+i), count+i);
        }
        assertEquals(table.getRowCount(), rows);
        for (i = 0; i < (rows+10); i++) {
            cols[0].addValueOrNull(""+i);
            assertTrue(!cols[0].isValueUndefined(i));
        }
        assertEquals(table.getRowCount(), rows+10);
        
        table.remove(cols[3]);
        assertEquals(table.getColumnCount(), count+9);
        
        for (i = 0; i < 10; i++) {
            assertEquals(table.remove(cols[i]), (i!=3));
        }
        cols = null;
        System.gc();
        for (Iterator iter = colMap.keySet().iterator(); iter.hasNext(); ) {
            Column c = (Column)iter.next();
            System.out.println("Column "+c.getName()+" not reclaimed");
        }
    }
    
    private static void testClear(Table table) {
        int count = table.getColumnCount();
        table.clear();
        assertEquals(table.getRowCount(), 0);
        assertEquals(table.getColumnCount(), count);
    }
}
