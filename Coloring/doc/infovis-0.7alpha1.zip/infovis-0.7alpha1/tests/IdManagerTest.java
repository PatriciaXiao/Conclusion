import infovis.utils.IdManager;
import junit.framework.TestCase;

/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/

/**
 * Class IdManagerTest
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class IdManagerTest extends TestCase {
    public IdManagerTest(String name) {
        super(name);
    }
    
    public void testIdManager()  {
        IdManager mgr = new IdManager();
        
        assertEquals(mgr.newId(), 0);
        assertEquals(mgr.newId(), 1);
        assertEquals(mgr.newId(), 2);
        assertEquals(mgr.newId(), 3);
        mgr.free(3);
        assertEquals(mgr.newId(), 3);
        mgr.free(0);
        assertEquals(mgr.newId(), 0);
        mgr.free(2);
        assertEquals(mgr.getMinId(), 0);
        assertEquals(mgr.getMaxId(), 3);
        mgr.free(1);
        assertEquals(mgr.getMinId(), 0);
        assertEquals(mgr.getMaxId(), 3);
        mgr.free(0);
        assertEquals(mgr.getMinId(), 0);
        assertEquals(mgr.getMaxId(), -1);
        
        mgr.clear();
        for (int i = 0; i < 100; i++) {
            mgr.newId();
        }
        assertEquals(0, freeNew(0, mgr));
        assertEquals(100, freeNew(100, mgr));
        assertEquals(50, freeNew(50, mgr));
        assertEquals(1, freeNew(1, mgr));
    }

    protected int freeNew(int id, IdManager mgr) {
        mgr.free(id);
        return mgr.newId();
    }
}
