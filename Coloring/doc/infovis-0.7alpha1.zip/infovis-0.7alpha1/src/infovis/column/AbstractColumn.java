/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.column;

import infovis.Column;

import java.util.EventListener;

import javax.swing.event.*;

/**
 * Class AbstractColumn
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.10 $
 */
public abstract class AbstractColumn implements Column {
    /**
     * The number of time this column has been modified.
     *
     * This field is used to trigger notifications.
     */
    protected int modCount = 0;

    /**
     * The number of time disableNotify() has been called minus the
     * number of time enableNotify() has been called.
     */
    protected int inhibitNotify = 0;

    /**
     * List of listeners registered to this column.
     */
    protected EventListenerList eventListenerList;
    protected ChangeEvent       changeEvent;

    /**
     * Returns the modCount.
     * @return int
     */
    public int getModCount() {
        return modCount;
    }

    /**
     * Disables notification until enableNotify has been called.
     *
     * <p>This method is useful if a large number of modifications is
     * going to happen on the column and notifying each time would be
     * too time consuming.  The notification will be deferred until
     * enableNotify is called.</p>
     *
     * <p>Calls to disableNotify can be nested</p>
     * @see #enableNotify()
     */
    public void disableNotify() {
        inhibitNotify++;
    }

    /**
     * Re enable notifications, triggering eventListeners if
     * modifications occur.
     *
     * @see #disableNotify()
     */
    public void enableNotify() {
        inhibitNotify--;
        if (inhibitNotify <= 0) {
            inhibitNotify = 0;
            fireColumnChanged();
        }
    }

    /**
     * Fire the notification.
     */
    public void fireColumnChanged() {
        if (inhibitNotify > 0 || modCount == 0)
            return;
        if (eventListenerList != null) {
            EventListener[] list = eventListenerList.getListeners(ChangeListener.class);
            for (int i = list.length - 1; i >= 0; i--) {
                ((ChangeListener)list[i]).stateChanged(changeEvent);
            }
        }
        modCount = 0;
    }

    /**
     * Adds a listener to the list that's notified each time a change occurs.
     *
     * @param listener the listener
     */
    public void addChangeListener(ChangeListener listener) {
        if (eventListenerList == null) {
            eventListenerList = new EventListenerList();
            changeEvent = new ChangeEvent(this);
        }
        eventListenerList.add(ChangeListener.class, listener);
    }

    /**
     * Removes a listener from the list that's notified each time a change occurs.
     *
     * @param listener the listener
     */
    public void removeChangeListener(ChangeListener listener) {
        if (eventListenerList != null) {
            eventListenerList.remove(ChangeListener.class, listener);
        }
    }

    /**
     * Mark the column as modified.
     *
     * Call notifications if not disabled.
     *
     * @return true if notifications have been called.
     */
    protected boolean modified() {
        modCount++;
        if (eventListenerList != null && inhibitNotify == 0) {
            fireColumnChanged();
            return true;
        }
        return false;
    }
    
    public String toString() {
        return getName();
    }


}
