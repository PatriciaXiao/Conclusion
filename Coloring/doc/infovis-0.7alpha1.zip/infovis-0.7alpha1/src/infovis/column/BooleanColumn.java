/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.column;

import infovis.Column;
import infovis.Table;
import infovis.utils.RowFilter;

import java.text.ParseException;
import java.util.BitSet;

import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * Column of booleans.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.22 $
 */
public class BooleanColumn extends LiteralColumn
    implements ListSelectionModel, RowFilter {
    private BitSet value;
    private boolean	min;
    private boolean	max;
    private int minSelection = Integer.MAX_VALUE;
    private int maxSelection = -1;

    /**
     * Creates a new FloatColumn object.
     *
     * @param name the column name.
     */
    public BooleanColumn(String name) {
	this(name, 10);
    }

    /**
     * Creates a new FloatColumn object.
     *
     * @param name the column name.
     * @param reserve the initial capacity.
     */
    public BooleanColumn(String name, int reserve) {
	super(name, reserve);

	if (reserve != 0) {
	    value = new BitSet(reserve);
	}

	size = 0;
    }

    /**
     * Returns the element at the specified position in this column.
     *
     * @param index index of element to return.
     *
     * @return the element at the specified position in this column.
     */
    public final boolean get(int index) {
	assert((index>=0) && (index < getRowCount()));
	return value.get(index);
    }
    
    /**
     * Replaces the element at the specified position in this column
     * with the specified element.
     *
     * @param index index of element to replace.
     * @param element element to be stored at the specified position.
     */
    public final void set(int index, boolean element) {
	assert((index>=0) && (index < getRowCount()));
	value.set(index, element);
	setValueUndefined(index, false);
	min_max_updated = false;
	if (minSelection != Integer.MAX_VALUE && index < minSelection)
	    minSelection = index;
	if (maxSelection != -1 && index > maxSelection)
	    maxSelection = index;
	modified();
    }

    /**
     * Replaces the element at the specified position in this column
     * with the specified element, growing the column if necessary.
     *
     * @param index index of element to replace.
     * @param element element to be stored at the specified position.
     */
    public final void setExtend(int index, boolean element) {
	assert(index >=0);
	disableNotify();
	try {
	    if (index >= getRowCount()) {	
		setSize(index + 1);
	    }
	
            value.set(index, element);
	    setValueUndefined(index, false);
	    min_max_updated = false;
	    if (minSelection != Integer.MAX_VALUE && index < minSelection)
		minSelection = index;
	    if (maxSelection != -1 && index > maxSelection)
		maxSelection = index;
	}
	finally {
	    enableNotify();
	}
    }

    /**
     * Adds a new element in the column,
     *
     * @param element the element.
     */
    public final void add(boolean element) {
	int index = size;
	ensureCapacity(index+1);
        value.set(size++, element);
	min_max_updated = false;
	if (minSelection != Integer.MAX_VALUE && index < minSelection)
	    minSelection = index;
	if (maxSelection != -1 && index > maxSelection)
	    maxSelection = index;
	modified();
    }
    
    public boolean isFiltered(int row) {
        return isValueUndefined(row) ? false : value.get(row);
    }
    
    public void copyFrom(Column from) {
        if (from instanceof BooleanColumn) {
            BooleanColumn new_from = (BooleanColumn) from;
            reallocate(from.getRowCount());
            System.arraycopy(new_from.value, 0, value, 0, from.getRowCount());
            modified();
        }
        else {
            super.copyFrom(from);
        }
    }

    /**
     * See BasicColumn#reallocate(int)
     */
    protected void reallocate(int size) {
        if(size <= reserve)
            return;
	if (value == null) {
	    value = new BitSet(reserve);
	}
        reserve = size;
    }

    /**
     * Parse a string and return the value for the column.
     *
     * @param v the string representation of the value
     *
     * @return the value
     *
     * @throws ParseException if the value cannot be parsed
     */
    public boolean parse(String v) throws ParseException {
	if (v == null)
	    return false;
	try {
	    if (getFormat() != null) {
		return ((Number)getFormat().parseObject(v)).intValue() != 0;
	    }

	    return Boolean.valueOf(v).booleanValue();
	} catch (Exception e) {
	    throw new ParseException(e.getMessage(), 0);
	}
    }

    /**
     * Returns the string representation of a value according to the current format.
     *
     * @param v the value
     *
     * @return the string representation.
     */
    public String format(boolean v) {
	if (getFormat() != null) {
	    return getFormat().format(new Boolean(v));
	}

	return Boolean.toString(v);
    }

    /**
     * @see infovis.Column#getValueAt(int)
     */
    public String getValueAt(int i) {
	if (i < 0 || i >= getRowCount() || isValueUndefined(i))
	    return null;
	return format(get(i));
    }

    /**
     * @see infovis.Column#setValueAt(int, String)
     */
    public void setValueAt(int i, String v) throws ParseException {
	setExtend(i, parse(v));
    }

    /**
     * @see infovis.Column#addValue(String)
     */
    public void addValue(String v) throws ParseException {
	add(parse(v));
    }

    /**
     * See BasicColumn#updateMinMax()
     */
    protected void updateMinMax() {
	if (min_max_updated) {
	    return;
	}

	max = false;
	min = true;
	minSelection = Integer.MAX_VALUE;
	maxSelection = -1;

	for (int i = 0; i < size; i++) {
	    if (!isValueUndefined(i)) {
		if (minSelection == Integer.MAX_VALUE)
		    minSelection = i;
		boolean v = value.get(i);

		if (v == false) {
		    min = false;
		}
		else {
		    max = true;
		}
		maxSelection = i;
	    }
	}
	min_max_updated = true;
    }

    /**
     * @see infovis.Column#minValue()
     */
    public String minValue() {
	return format(getMin());
    }

    /**
     * @see infovis.Column#maxValue()
     */
    public String maxValue() {
	return format(getMax());
    }

    /**
     * Returns a column as a <code>FloatColumn</code> from a
     * <code>Table</code>.
     *
     * @param t the <code>Table</code>
     * @param index index in the <code>Table</code>
     *
     * @return a <code>FloatColumn</code> or null if no such column
     *         exists or the column is not a
     *         <code>FloatColumn</code>.
     */
    public static BooleanColumn getColumn(Table t, int index) {
	Column c = t.getColumnAt(index);

	if (c instanceof BooleanColumn) {
	    return (BooleanColumn)c;
	} else {
	    return null;
	}
    }
	
    /**
     * Returns a column as a <code>BooleanColumn</code> from a
     * <code>Table</code>.
     *
     * @param t the <code>Table</code>
     * @param name the column name.
     *
     * @return a <code>BooleanColumn</code> or null if no such column
     *         exists or the column is not a
     *         <code>BooleanColumn</code>.
     */
    public static BooleanColumn getColumn(Table t, String name) {
	Column c = t.getColumn(name);

	if (c instanceof BooleanColumn) {
	    return (BooleanColumn)c;
	} else {
	    return null;
	}
    }

    /**
     * Returns a column as a <code>FloatColumn</code> from a table,
     * creating it if needed.
     *
     * @param t the <code>Table</code>
     * @param name the column name.
     *
     * @return a column as a <code>FloatColumn</code> from a table,
     */
    public static BooleanColumn findColumn(Table t, String name) {
	Column c = t.getColumn(name);
	if (c == null) {
	    c = new BooleanColumn(name);
	    t.addColumn(c);
	}
	return (BooleanColumn)c;
    }

    /**
     * Returns the maximum value of the column.
     *
     * @return boolean the maximum value of the column.
     */
    public boolean getMax() {
	updateMinMax();

	return max;
    }

    /**
     * Returns the minimum value of the column.
     *
     * @return boolean the minimum value of the column.
     */
    public boolean getMin() {
	updateMinMax();

	return min;
    }

    /**
     * @see infovis.Column#getValueClass()
     */
    public Class getValueClass() {
	return Boolean.class;
    }
	
    /**
     * @see infovis.Column#compare(int,int)
     */
    public int compare(int row1, int row2) {
        int ret = super.compare(row1, row2);
        if (ret != 0)
            return ret;
	int v1 = get(row1) ? 1 : 0;
	int v2 = get(row2) ? 1 : 0;
		
	return v1 - v2;
    }
    // ListSelectionModel
    private int anchorIndex = -1;
    private int leadIndex = -1;
    private boolean isAdjusting = false; 
	
    /**
     * @see javax.swing.ListSelectionModel#addListSelectionListener(ListSelectionListener)
     */
    public void addListSelectionListener(ListSelectionListener x) {
	eventListenerList.add(ListSelectionListener.class, x);
    }

    /**
     * @see javax.swing.ListSelectionModel#addSelectionInterval(int, int)
     */
    public void addSelectionInterval(int index0, int index1) {
	anchorIndex = index0;
	leadIndex = index1;
	disableNotify();
	try {
	    while (index0 <= index1) {
		setExtend(index0, true);
		index0++;
	    }
	}
	finally {
	    enableNotify();
	}
    }

    /**
     * @see javax.swing.ListSelectionModel#clearSelection()
     */
    public void clearSelection() { 
	anchorIndex = -1;
	leadIndex = -1;
	isAdjusting = false;
	clear();
    }

    /**
     * @see javax.swing.ListSelectionModel#getAnchorSelectionIndex()
     */
    public int getAnchorSelectionIndex() {
	return anchorIndex;
    }

    /**
     * @see javax.swing.ListSelectionModel#getLeadSelectionIndex()
     */
    public int getLeadSelectionIndex() {
	return leadIndex;
    }

    /**
     * @see javax.swing.ListSelectionModel#getMaxSelectionIndex()
     */
    public int getMaxSelectionIndex() {
	return lastValidRow();
    }

    /**
     * @see javax.swing.ListSelectionModel#getMinSelectionIndex()
     */
    public int getMinSelectionIndex() {
	return firstValidRow();
    }

    /**
     * @see javax.swing.ListSelectionModel#getSelectionMode()
     */
    public int getSelectionMode() {
	return MULTIPLE_INTERVAL_SELECTION;
    }

    /**
     * @see javax.swing.ListSelectionModel#getValueIsAdjusting()
     */
    public boolean getValueIsAdjusting() {
	return isAdjusting;
    }

    /**
     * @see javax.swing.ListSelectionModel#insertIndexInterval(int, int, boolean)
     */
    public void insertIndexInterval(int index, int length, boolean before) {
    }

    /**
     * @see javax.swing.ListSelectionModel#isSelectedIndex(int)
     */
    public boolean isSelectedIndex(int index) {
	return !isValueUndefined(index);
    }

    /**
     * @see javax.swing.ListSelectionModel#isSelectionEmpty()
     */
    public boolean isSelectionEmpty() {
	return isEmpty();
    }
	
    public int getSelectedCount() {
	int cnt = 0;
	for (int i = getMinSelectionIndex(); i <= getMaxSelectionIndex(); i++) {
	    if (isSelectedIndex(i))
		cnt++;
	}
	return cnt;
    }

    /**
     * @see javax.swing.ListSelectionModel#removeIndexInterval(int, int)
     */
    public void removeIndexInterval(int index0, int index1) {
    }

    /**
     * @see javax.swing.ListSelectionModel#removeListSelectionListener(ListSelectionListener)
     */
    public void removeListSelectionListener(ListSelectionListener x) {
	eventListenerList.remove(ListSelectionListener.class, x);
    }

    /**
     * @see javax.swing.ListSelectionModel#removeSelectionInterval(int, int)
     */
    public void removeSelectionInterval(int index0, int index1) {
	while (index0 <= index1) {
	    setValueUndefined(index0, true);
	    index0++;
	}
    }

    /**
     * @see javax.swing.ListSelectionModel#setAnchorSelectionIndex(int)
     */
    public void setAnchorSelectionIndex(int index) {
	anchorIndex = index;
    }

    /**
     * @see javax.swing.ListSelectionModel#setLeadSelectionIndex(int)
     */
    public void setLeadSelectionIndex(int index) {
	leadIndex = index;
    }

    /**
     * @see javax.swing.ListSelectionModel#setSelectionInterval(int, int)
     */
    public void setSelectionInterval(int index0, int index1) {
	clear();
	addSelectionInterval(index0, index1);
    }

    /**
     * @see javax.swing.ListSelectionModel#setSelectionMode(int)
     */
    public void setSelectionMode(int selectionMode) {
    }

    /**
     * @see javax.swing.ListSelectionModel#setValueIsAdjusting(boolean)
     */
    public void setValueIsAdjusting(boolean valueIsAdjusting) {
	this.isAdjusting = valueIsAdjusting;
    }
	
    private void fireValueChanged() {
	int firstChanged = firstValidRow();
	int lastChanged = lastValidRow();
	Object[] listeners = eventListenerList.getListenerList();
	ListSelectionEvent e = null;
	for (int i = listeners.length - 2; i >= 0; i -= 2) {
	    if (listeners[i] == ListSelectionListener.class) {
		if (e == null) {
		    e = new ListSelectionEvent(this, firstChanged, lastChanged, isAdjusting);
		}
		((ListSelectionListener)listeners[i+1]).valueChanged(e);
	    }
	}	
    }
	
    /**
     * @see BasicColumn#modified()
     */
    protected boolean modified() {
	if (super.modified()) {
	    fireValueChanged();
	    return true;
	}
	return false;
    }

    /**
     * @see infovis.column.NumberColumn#getIntAt(int)
     */
    public int getIntAt(int row) {
	return get(row) ? 1 : 0;
    }
	
    /**
     * @see infovis.column.NumberColumn#setIntAt(int, int)
     */
    public void setDoubleAt(int row, double v) {
	set(row, v != 0);
    }

	
    /**
     * @see infovis.column.NumberColumn#getIntMin()
     */
    public int getIntMin() {
	return getMin() ? 1 : 0;
    }
	
    /**
     * @see infovis.column.NumberColumn#getIntMax()
     */
    public int getIntMax() {
	return getMax() ? 1 : 0;
    }

    /**
     * @see infovis.Column#firstValidRow()
     */
    public int firstValidRow() {
	if (minSelection == Integer.MAX_VALUE)
	    minSelection = super.firstValidRow();
	return minSelection;
    }
	
    /**
     * @see infovis.Column#lastValidRow()
     */
    public int lastValidRow() {
	if (maxSelection == -1)
	    maxSelection = super.lastValidRow();
	return maxSelection;
    }

    public String format(double value) {
        boolean v = (value != 0);
        return format(v);
}

}
