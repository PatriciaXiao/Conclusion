/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.column;

import infovis.Column;

/**
 * Class ColumnSorter
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.3 $
 */
public class ColumnSorter extends ColumnLink {
    IntColumn sortedColumn;
    
    public ColumnSorter(Column col) {
        super(col, new IntColumn("#sorted_"+col.getName()));
        sortedColumn = (IntColumn)toColumn;
        updateColumn();
    }
    
    public void update() {
        sortedColumn.clear();
        // Mat changement : for (int i = 0; i < toColumn.getRowCount(); i++) {
        for (int i = 0; i < fromColumn.getRowCount(); i++) {
            sortedColumn.add(i);
        }
        // Mat changement : sortedColumn.sort(sortedColumn);
        sortedColumn.sort(fromColumn);
    }


    public IntColumn getSortedColumn() {
        return sortedColumn;
    }

}
