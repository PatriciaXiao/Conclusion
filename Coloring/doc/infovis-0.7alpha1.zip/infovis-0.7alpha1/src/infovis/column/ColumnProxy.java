/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.column;

import infovis.Column;
import infovis.metadata.DependencyMetadata;
import infovis.utils.RowIterator;

import java.text.Format;
import java.text.ParseException;
import java.util.Map;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Class ColumnProxy
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class ColumnProxy extends AbstractColumn implements ChangeListener {
    protected Column column;
    
    public ColumnProxy(Column column) {
        this.column = column;
        DependencyMetadata.addDependentColumn(column, this);
        column.addChangeListener(this);
    }
    
    public void dispose() {
        DependencyMetadata.removeDependentColumn(column, this);
        column.removeChangeListener(this);
    }
    
    public void stateChanged(ChangeEvent e) {
        fireColumnChanged();
    }

    public void addValue(String v) throws ParseException {
        column.addValue(v);
    }

    public boolean addValueOrNull(String v) {
        return column.addValueOrNull(v);
    }
    
    public void copyFrom(Column from) {
        column.copyFrom(from);
    }


    public int capacity() {
        return column.capacity();
    }

    public void clear() {
        column.clear();
    }

    public int compare(int row1, int row2) {
        return column.compare(row1, row2);
    }

    public void ensureCapacity(int minCapacity) {
        column.ensureCapacity(minCapacity);
    }

    public boolean equals(Object obj) {
        return column.equals(obj);
    }

    public int firstValidRow() {
        return column.firstValidRow();
    }

    public Map getClientPropery() {
        return column.getClientPropery();
    }

    public Format getFormat() {
        return column.getFormat();
    }

    public Map getMetadata() {
        return column.getMetadata();
    }

    public String getName() {
        return column.getName();
    }

    public int getRowCount() {
        return column.getRowCount();
    }

    public String getValueAt(int index) {
        return column.getValueAt(index);
    }

    public Class getValueClass() {
        return column.getValueClass();
    }

    public int hashCode() {
        return column.hashCode();
    }

    public boolean isEmpty() {
        return column.isEmpty();
    }

    public boolean isInternal() {
        return column.isInternal();
    }

    public boolean isValueUndefined(int row) {
        return column.isValueUndefined(row);
    }

    public RowIterator iterator() {
        return column.iterator();
    }

    public int lastValidRow() {
        return column.lastValidRow();
    }

    public String maxValue() {
        return column.maxValue();
    }

    public String minValue() {
        return column.minValue();
    }
    public void setFormat(Format format) {
        column.setFormat(format);
    }

    public void setName(String name) {
        column.setName(name);
    }

    public void setValueAt(int index, String element)
        throws ParseException {
        column.setValueAt(index, element);
    }

    public boolean setValueOrNullAt(int index, String v) {
        return column.setValueOrNullAt(index, v);
    }

    public void setValueUndefined(int i, boolean undef) {
        column.setValueUndefined(i, undef);
    }

    public String toString() {
        return column.toString();
    }

}
