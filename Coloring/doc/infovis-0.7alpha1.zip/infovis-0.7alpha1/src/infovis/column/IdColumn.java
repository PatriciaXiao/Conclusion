/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.column;

import infovis.Column;
import infovis.utils.RowIterator;

import java.text.Format;
import java.text.ParseException;
import java.util.Map;

import javax.swing.event.ChangeListener;

/**
 * Class IdColumn
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.10 $
 */
public class IdColumn implements NumberColumn {
    protected int size;
    
    public IdColumn() {
    }
    
    public int get(int row) {
        return row;
    }
    
    public void set(int row) {
        size = Math.max(size, row+1);
    }

    public double getDoubleAt(int row) {
        return get(row);
    }

    public double getDoubleMax() {
        return size;
    }

    public double getDoubleMin() {
        return 0;
    }

    public float getFloatAt(int row) {
        return get(row);
    }

    public float getFloatMax() {
        return size;
    }

    public float getFloatMin() {
        return 0;
    }

    public int getIntAt(int row) {
        return get(row);
    }

    public int getIntMax() {
        return size;
    }

    public int getIntMin() {
        return 0;
    }

    public long getLongAt(int row) {
        return get(row);
    }

    public long getLongMax() {
        return size;
    }

    public long getLongMin() {
        return 0;
    }

    public double round(double value) {
        return Math.round(value);
    }

    public void setDoubleAt(int row, double v) {
        set(row);
    }

    public void setFloatAt(int row, float v) {
        set(row);
    }

    public void setIntAt(int row, int v) {
        set(row);
    }

    public void setLongAt(int row, long v) {
        set(row);
    }

    public void addChangeListener(ChangeListener listener) {
    }

    public void addValue(String v) throws ParseException {
        set(size);
    }

    public boolean addValueOrNull(String v) {
        set(size);
        return true;
    }
    
    public void copyFrom(Column from) {
    }


    public int capacity() {
        return size;
    }

    public void clear() {
        size = 0;
    }

    public void disableNotify() {
    }

    public void enableNotify() {
    }

    public void ensureCapacity(int minCapacity) {
    }

    public int firstValidRow() {
        return 0;
    }

    public Format getFormat() {
        return null;
    }

    public String getName() {
        return "(None)";
    }

    public int getRowCount() {
        return size;
    }

    public String getValueAt(int index) {
        return null;
    }

    public Class getValueClass() {
        return Integer.class;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isInternal() {
        return true;
    }

    public boolean isValueUndefined(int i) {
        return i < 0 || i >= size;
    }

    public RowIterator iterator() {
        return new BasicColumn.Iterator(this);
    }

    public int lastValidRow() {
        return size-1;
    }

    public String maxValue() {
        return null;
    }

    public String minValue() {
        return null;
    }

    public void removeChangeListener(ChangeListener listener) {
    }

    public void setFormat(Format format) {
    }

    public void setName(String name) {
    }

    public void setValueAt(int index, String element)
        throws ParseException {
    }

    public boolean setValueOrNullAt(int index, String v) {
        return false;
    }

    public void setValueUndefined(int i, boolean undef) {
    }

    public Map getClientPropery() {
        return null;
    }

    public Map getMetadata() {
        return null;
    }

    public int compare(int row1, int row2) {
        return row1 - row2;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int i) {
        size = i;
    }

    public String format(double value) {
        return ""+(int)value;
    }

}
