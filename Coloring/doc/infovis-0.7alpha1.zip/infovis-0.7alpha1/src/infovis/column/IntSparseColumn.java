/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.column;

import java.text.ParseException;

/**
 * Class IntSparseColumn
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class IntSparseColumn extends BasicColumn {

    public IntSparseColumn(String name) {
        super(name);
        // TODO Auto-generated constructor stub
    }

    protected void setSize(int newSize) {
        // TODO Auto-generated method stub

    }

    protected void reallocate(int capacity) {
        // TODO Auto-generated method stub

    }

    public Class getValueClass() {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean isValueUndefined(int i) {
        // TODO Auto-generated method stub
        return false;
    }

    public void setValueUndefined(int i, boolean undef) {
        // TODO Auto-generated method stub

    }

    public int getRowCount() {
        // TODO Auto-generated method stub
        return 0;
    }

    public void clear() {
        // TODO Auto-generated method stub

    }

    public int capacity() {
        // TODO Auto-generated method stub
        return 0;
    }

    public String getValueAt(int index) {
        // TODO Auto-generated method stub
        return null;
    }

    public void setValueAt(int index, String element)
        throws ParseException {
        // TODO Auto-generated method stub

    }

    public void addValue(String v) throws ParseException {
        // TODO Auto-generated method stub

    }

    public String minValue() {
        // TODO Auto-generated method stub
        return null;
    }

    public String maxValue() {
        // TODO Auto-generated method stub
        return null;
    }

}
