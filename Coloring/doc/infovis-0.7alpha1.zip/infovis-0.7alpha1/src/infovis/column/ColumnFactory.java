/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.column;

import java.util.ArrayList;
import java.util.HashMap;

import infovis.Column;
import infovis.column.format.*;
import infovis.metadata.ValueCategory;

/**
 * Abstract factory of Columns.
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class ColumnFactory {
    /** Constant for requesting a dense column */
    public static final int COLUMN_TYPE_DENSE = 1;
    
    /** Constant for requesting a sparse column */
    public static final int COLUMN_TYPE_SPARSE = 2;
    
    /** Constant for requesting a column by default */
    public static final int COLUMN_TYPE_DEFAULT = COLUMN_TYPE_DENSE;
    
    protected HashMap creators = new HashMap();
    static private ColumnFactory instance;
    
    public static ColumnFactory getInstance() {
        if (instance == null) {
            instance = new ColumnFactory();
        }
        return instance;
    }
    
    public static void setInstance(ColumnFactory factory) {
        instance = factory;
    }

    public static Column createColumn(String typeName, String name) {
        return getInstance().create(typeName, name);    
    }

    public static Column createColumn(String typeName, int type, String name) {
        return getInstance().create(typeName, type, name);    
    }
    
    protected ColumnFactory() {
        addDefaultCreators();
    }
    
    protected void addDefaultCreators() {
        Creator creator = new AbstractCreator("integer", COLUMN_TYPE_DENSE) {
            public Column create(String name) {
                return new IntColumn(name);
            }
        };
        add(creator);
        add("int", creator);
        creator = new AbstractCreator("long", COLUMN_TYPE_DENSE) {
            public Column create(String name) {
                return new LongColumn(name);
            }
        };
        add(creator);
        creator = new AbstractCreator("float", COLUMN_TYPE_DENSE) {
            public Column create(String name) {
                return new FloatColumn(name);
            }
        };
        add(creator);
        add("real", creator);
        creator = new AbstractCreator("double", COLUMN_TYPE_DENSE) {
            public Column create(String name) {
                return new DoubleColumn(name);
            }
        };
        add(creator);
        creator = new AbstractCreator("string", COLUMN_TYPE_DENSE) {
            public Column create(String name) {
                return new StringColumn(name);
            }
        };
        add(creator);
        creator = new AbstractCreator("boolean", COLUMN_TYPE_DENSE) {
            public Column create(String name) {
                return new BooleanColumn(name);
            }
        };
        add(creator);
        add("bool", creator);
        
        creator = new AbstractCreator("color", COLUMN_TYPE_DENSE) {
            public Column create(String name) {
                IntColumn color = new IntColumn(name);
                color.getMetadata().put(
                    ValueCategory.VALUE_CATEGORY_TYPE,
                    ValueCategory.VALUE_CATEGORY_TYPE_EXPLICIT);
                color.setFormat(ColorFormat.getInstance());
                return color;
            }
        };
        add(creator);
        
        creator = new AbstractCreator("date", COLUMN_TYPE_DENSE) {
            public Column create(String name) {
                LongColumn date = new LongColumn(name);
                date.setFormat(UTCDateFormat.getInstance());
                return date;
            }
        };
        add(creator);
    }
    
    public void add(String type, Creator c) {
        type = type.toLowerCase();
        ArrayList cl = (ArrayList)creators.get(type);
        if (cl == null) {
            cl = new ArrayList();
            creators.put(type, cl); 
        }
        cl.add(c);
    }
    
    public void add(Creator c) {
        add(c.getTypeName(), c);
    }
    
    public static void addColumn(Creator c) {
	getInstance().add(c);    
    }
    
    
    public boolean remove(Creator c) {
        ArrayList cl = (ArrayList)creators.get(c.getTypeName());
        if (cl == null) return false;
        return cl.remove(c);
    }
    
    public Creator getCreator(String typeName, int type) {
        typeName = typeName.toLowerCase();
        ArrayList cl = (ArrayList)creators.get(typeName);
        
        for (int i = 0; i < cl.size(); i++) {
            Creator c = (Creator)cl.get(i);
            if (c.getColumnType() == type) {
                return c;
            }
        }
        return null;
    }
    
    public Creator getCreator(String typeName) {
        return getCreator(typeName, COLUMN_TYPE_DEFAULT);
    }
    
    public Column create(String typeName, int type, String name) {
        Creator c = getCreator(typeName, type);
        if (c == null)
            return null;
        return c.create(name);
    }
    
    public Column create(String typeName, String name) {
        return create(typeName, COLUMN_TYPE_DEFAULT, name);
    }

    public interface Creator {
        public String getTypeName();
        public int getColumnType();
        public Column create(String name);
    }
    
    public abstract static class AbstractCreator implements Creator {
        protected String typeName;
        protected int type;
        
        public AbstractCreator(String typeName, int type) {
            this.typeName = typeName;
            this.type = type;
        }
        
        public String getTypeName() {
            return typeName;
        }
        
        public int getColumnType() {
            return type;
        }
    }
}
