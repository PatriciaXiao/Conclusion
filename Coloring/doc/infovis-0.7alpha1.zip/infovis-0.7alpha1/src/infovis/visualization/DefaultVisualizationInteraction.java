/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization;

import infovis.Visualization;
import infovis.column.BooleanColumn;

import java.awt.event.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;

/**
 * Class DefaultVisualizationInteraction
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class DefaultVisualizationInteraction
    implements MouseListener, MouseMotionListener, VisualizationInteractor {
    protected Visualization visualization;
    protected JComponent component;
    
    public DefaultVisualizationInteraction(Visualization vis) {
        this.visualization = vis;
    }
    
    public void install(JComponent comp) {
        comp.addMouseListener(this);
        comp.addMouseMotionListener(this);
    }
    
    public void uninstall(JComponent comp) {
        comp.removeMouseListener(this);
        comp.removeMouseMotionListener(this);
    }
    
    
    public JComponent getJComponent() {
        return component;
    }

    public Visualization getVisualization() {
        return visualization;
    }

    public void setVisualization(Visualization visualization) {
        this.visualization = visualization;
    }

    public void setSelection(int sel) {
        BooleanColumn selection = visualization.getSelection();
        try {
            selection.disableNotify();
            selection.clear();
            addSelection(sel);
        }
        finally {
            selection.enableNotify();
        }
    }

    public void addSelection(int sel) {
        BooleanColumn selection = visualization.getSelection();
        if (sel != -1) {
            selection.setExtend(sel, true);
        }
    }    

    public void mouseClicked(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    // interface MouseListener
    /**
     * @see java.awt.event.MouseListener#mousePressed(MouseEvent)
     */
    public void mousePressed(MouseEvent e) {
        mouseDragged(e);
    }

    // interface MouseMotionListener
    /**
     * @see java.awt.event.MouseMotionListener#mouseMoved(MouseEvent)
     */
    public void mouseMoved(MouseEvent e) {
        Fisheyes fisheyes = visualization.getFisheyes();
        if (fisheyes != null) {
            fisheyes.setFocus(e.getX(), e.getY());
            visualization.repaint();
        }
    }

    /**
     * @see java.awt.event.MouseMotionListener#mouseDragged(MouseEvent)
     */
    public void mouseDragged(MouseEvent e) {
        int sel = visualization.pickTop(e.getX(), e.getY(), visualization.getBounds());
        if ((e.getModifiers() & MouseEvent.SHIFT_MASK) == 0)
            setSelection(sel);
        else {
            addSelection(sel);
        }
    }

}
