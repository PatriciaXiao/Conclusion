/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization;

import infovis.Table;
import infovis.Visualization;
import infovis.column.*;
import infovis.utils.RowIterator;
import infovis.visualization.linkShapers.DefaultLinkShaper;

import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;

/**
 * Class LinkVisualization
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.3 $
 */
public class LinkVisualization extends StrokingVisualization {
    protected Visualization nodeVisualization;
    protected ObjectColumn nodeShapes;
    protected LinkShaper linkShaper;
    protected NodeAccessor nodeAccessor;
    volatile Point2D startPos, endPos;
    protected boolean showingSelected = false;
    
    public LinkVisualization(
        Table table,
        BooleanColumn selection,
        FilterColumn filter,
        Visualization nodeVisualization, 
        NodeAccessor accessor) {
        super(table, selection, filter);
        setNodeVisualization(nodeVisualization);
        setNodeAccessor(accessor);
    }
    
    public LinkVisualization(
            Table table,
            Visualization nodeVisualization, 
            NodeAccessor accessor) {
        this(table, null, null, nodeVisualization, accessor);
        }    
    
    public void dispose() {
        setNodeVisualization(null);
        super.dispose();
    }
    
    public boolean isNodeSelected(int node) {
        return (!nodeVisualization.getSelection().isValueUndefined(node))
               && nodeVisualization.getSelection().get(node);
    }
    
    public boolean isFiltered(int row) {
        if (super.isFiltered(row))
            return true;
        if (showingSelected) {
            if (isNodeSelected(nodeAccessor.getStartNode(row))
                || isNodeSelected(nodeAccessor.getEndNode(row)))
                return false;
            else
                return true;
        }
        else {
            if (nodeVisualization.isFiltered(nodeAccessor.getStartNode(row))
                || nodeVisualization.isFiltered(nodeAccessor.getEndNode(row)))
                return true;
            else         
                return false;
        }
    }


    public void paintBackground(
        Graphics2D graphics,
        Rectangle2D bounds) {
        // Disable erasing background
    }
    
    protected void install(JComponent parent) {
        // don't register interaction handler, they will be managed by the owner
    }
    
    protected void uninstall(JComponent parent) {
        // don't remove interaction handlers since they haven't been installed
    }

    public void computeShapes(Rectangle2D bounds) {
        if (nodeShapes != nodeVisualization.getShapes()) {
            if (nodeShapes != null) {
                nodeShapes.removeChangeListener(this);
            }
            nodeShapes = nodeVisualization.getShapes();
            if (nodeShapes != null) {
                nodeShapes.addChangeListener(this);
            }
            else
                return;
        }
        for (RowIterator iter = iterator(); iter.hasNext(); ) {
            int link = iter.nextRow();
            setShapeAt(
                link,
                getLinkShaper().computeLinkShape(link, getNodeAccessor(), getShapeAt(link)));
        }
    }
    
    public LabeledItem createLabelItem(int row) {
        return new LinkExcentricItem(this, row);
    }

    public void stateChanged(ChangeEvent e) {
        super.stateChanged(e);
        if (e.getSource() == nodeShapes) {
            invalidate();
        }
    }

    public Visualization getNodeVisualization() {
        return nodeVisualization;
    }

    public void setNodeVisualization(Visualization visualization) {
        if (nodeShapes != null) {
            nodeShapes.removeChangeListener(this);
        }
        nodeVisualization = visualization;
    }

    public NodeAccessor getNodeAccessor() {
        return nodeAccessor;
    }

    public void setNodeAccessor(NodeAccessor accessor) {
        nodeAccessor = accessor;
    }

    public LinkShaper getLinkShaper() {
        if (linkShaper == null) {
            linkShaper = new DefaultLinkShaper(this, nodeShapes);
        }
        return linkShaper;
    }

    public void setLinkShaper(LinkShaper shaper) {
        linkShaper = shaper;
    }

    public boolean isShowingSelected() {
        return showingSelected;
    }

    public void setShowingSelected(boolean b) {
        showingSelected = b;
    }

}
