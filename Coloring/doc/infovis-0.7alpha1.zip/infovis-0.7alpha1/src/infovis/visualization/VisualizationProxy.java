/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.visualization;

import infovis.*;
import infovis.column.*;
import infovis.utils.*;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.Set;



/**
 * Class CascadedVisualization
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.12 $
 */
public class VisualizationProxy implements Visualization {
    Visualization visualization;
    
    public VisualizationProxy(Visualization visualization) {
        this.visualization = visualization;
    }
    
    public Visualization getVisualization() {
        return visualization;
    }

    public Visualization findVisualization(Class cls) {
        if (cls.isAssignableFrom(getClass()))
            return this;
        return visualization.findVisualization(cls);
    }
    
    public Visualization getVisualization(int index) {
        if (index == 0)
            return visualization;
        return null;
    }
    
    public int pickTop(Rectangle2D hitBox, Rectangle2D bounds) {
        return visualization.pickTop(hitBox, bounds);
    }

    public void setDefaultColor(Color defaultColor) {
        visualization.setDefaultColor(defaultColor);
    }

    public boolean isFiltered(int row) {
        return visualization.isFiltered(row);
    }

    public Color getUnselectedColor() {
        return visualization.getUnselectedColor();
    }

    public BooleanColumn getSelection() {
        return visualization.getSelection();
    }

    public int pickTop(double x, double y, Rectangle2D bounds) {
        return visualization.pickTop(x, y, bounds);
    }

    public boolean isDisplayingStatistics() {
        return visualization.isDisplayingStatistics();
    }

    public boolean equals(Object obj) {
        return visualization.equals(obj);
    }
    
    public int getColorValue(int row) {
        return visualization.getColorValue(row);
    }

    public int getOrientation() {
        return visualization.getOrientation();
    }

    public Shape getShapeAt(int row) {
        return visualization.getShapeAt(row);
    }

    public void paint(Graphics2D graphics, Rectangle2D bounds) {
        visualization.paint(graphics, bounds);
    }

    public Component getComponent() {
        return visualization.getComponent();
    }

    public Fisheyes getFisheyes() {
        return visualization.getFisheyes();
    }

    public void invalidate(Column c) {
        visualization.invalidate(c);
    }

    public void setOrientation(int orientation) {
        visualization.setOrientation(orientation);
    }

    public RowComparator getComparator() {
        return visualization.getComparator();
    }

    public void computeShapes(Rectangle2D bounds) {
        visualization.computeShapes(bounds);
    }

    public void showAllRows() {
        visualization.showAllRows();
    }

    public void repaint() {
        visualization.repaint();
    }

    public void setDisplayingStatistics(boolean displayingStatistics) {
        visualization.setDisplayingStatistics(displayingStatistics);
    }

    public VisualColumnDescriptor getVisualColumnDescriptor(String name) {
        return visualization.getVisualColumnDescriptor(name);
    }

    public void hideFilteredRows() {
        visualization.hideFilteredRows();
    }

    public boolean isVisualColumnInvalidate(String name) {
        return visualization.isVisualColumnInvalidate(name);
    }

    public boolean isInvalidateColumn(Column c) {
        return visualization.isInvalidateColumn(c);
    }

    public Color getFilteredColor() {
        return visualization.getFilteredColor();
    }

    public void setDefaultSize(double defaultSize) {
        visualization.setDefaultSize(defaultSize);
    }

    public void setMinSize(double minSize) {
        visualization.setMinSize(minSize);
    }

    public double getMaxSize() {
        return visualization.getMaxSize();
    }

    public int getDisplayedItems() {
        return visualization.getDisplayedItems();
    }

    public double getMinSize() {
        return visualization.getMinSize();
    }

    public boolean setComparator(RowComparator comparator) {
        return visualization.setComparator(comparator);
    }

    public FilterColumn getFilter() {
        return visualization.getFilter();
    }

    public Color getColorAt(int row) {
        return visualization.getColorAt(row);
    }

    public Rectangle2D getBounds() {
        return visualization.getBounds();
    }

    public int getRowAtIndex(int index) {
        return visualization.getRowAtIndex(index);
    }

    public void validateShapes(Rectangle2D bounds) {
        visualization.validateShapes(bounds);
    }

    public Color getDefaultColor() {
        return visualization.getDefaultColor();
    }

    public Component getParent() {
        return visualization.getParent();
    }

    public int getRowIndex(int row) {
        return visualization.getRowIndex(row);
    }

    public IntColumn pickAll(
        Rectangle2D hitBox,
        Rectangle2D bounds,
        IntColumn pick) {
        return visualization.pickAll(hitBox, bounds, pick);
    }

    public double getDefaultSize() {
        return visualization.getDefaultSize();
    }

    public void setDefaultFont(Font defaultFont) {
        visualization.setDefaultFont(defaultFont);
    }

    public void setColorFor(Graphics2D g, int row) {
        visualization.setColorFor(g, row);
    }

    public Color getSelectedColor() {
        return visualization.getSelectedColor();
    }

    public void setMaxSize(double maxSize) {
        visualization.setMaxSize(maxSize);
    }

    public double getSizeAt(int row) {
        return visualization.getSizeAt(row);
    }

    public void setFisheyes(Fisheyes fisheyes) {
        visualization.setFisheyes(fisheyes);
    }

    public BasicStroke getDefaultStroke() {
        return visualization.getDefaultStroke();
    }

    public void setParent(Component parent) {
        visualization.setParent(parent);
    }

    public Font getDefaultFont() {
        return visualization.getDefaultFont();
    }

    public String getLabelAt(int row) {
        return visualization.getLabelAt(row);
    }

    public long getLayoutTime() {
        return visualization.getLayoutTime();
    }

    public void setUnselectedColor(Color unselectedColor) {
        visualization.setUnselectedColor(unselectedColor);
    }

    public void hideSelectedRows() {
        visualization.hideSelectedRows();
    }

    public long getRedisplayTime() {
        return visualization.getRedisplayTime();
    }

    public void setShowingLabel(boolean showingLabel) {
        visualization.setShowingLabel(showingLabel);
    }

    public Column getVisualColumn(String name) {
        return visualization.getVisualColumn(name);
    }

    public ColorVisualization getColorVisualization() {
        return visualization.getColorVisualization();
    }

    public void setDefaultStroke(BasicStroke defaultStroke) {
        visualization.setDefaultStroke(defaultStroke);
    }

    public BooleanColumn pickAll(
        Rectangle2D hitBox,
        Rectangle2D bounds,
        BooleanColumn pick) {
        return visualization.pickAll(hitBox, bounds, pick);
    }

    public void invalidate() {
        visualization.invalidate();
    }

    public ObjectColumn getShapes() {
        return visualization.getShapes();
    }

    public void setSmooth(boolean smooth) {
        visualization.setSmooth(smooth);
    }

    public void setFilteredColor(Color filteredColor) {
        visualization.setFilteredColor(filteredColor);
    }

    public Permutation getPermutation() {
        return visualization.getPermutation();
    }

    public boolean setVisualColumn(String name, Column column) {
        return visualization.setVisualColumn(name, column);
    }

    public void setSelectedColor(Color selectedColor) {
        visualization.setSelectedColor(selectedColor);
    }

    public boolean isShowingLabel() {
        return visualization.isShowingLabel();
    }

    public Table getTable() {
        return visualization.getTable();
    }

    public void dispose() {
        visualization.dispose();
    }

    public RowIterator iterator() {
        return visualization.iterator();
    }

    public void setShapeAt(int row, Shape s) {
        visualization.setShapeAt(row, s);
    }

    public boolean isSmooth() {
        return visualization.isSmooth();
    }

    public LabeledItem createLabelItem(int row) {
        return visualization.createLabelItem(row);
    }

    public Set pickAll(
        Rectangle2D hitBox,
        Rectangle2D bounds,
        Set pick) {
        return visualization.pickAll(hitBox, bounds, pick);
    }
    public double getAlphaAt(int row) {
        return visualization.getAlphaAt(row);
    }

    public double getDefaultAlpha() {
        return visualization.getDefaultAlpha();
    }

    public void setDefaultAlpha(double defaultAlpha) {
        visualization.setDefaultAlpha(defaultAlpha);
    }

}
