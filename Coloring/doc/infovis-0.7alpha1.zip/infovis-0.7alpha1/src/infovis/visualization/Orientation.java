/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.visualization;

import java.awt.geom.Point2D;

/**
 * Class Orientation
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class Orientation implements Orientable {
    private int orientation;
    static String name[] = {
        "invalid",
        "north",
        "south",
        "east",
        "west"
    };
    static Point2D.Float direction[] = {
        new Point2D.Float(0, 0), // no direction
        new Point2D.Float(0, 1),
        new Point2D.Float(0, -1),
        new Point2D.Float(1, 0),
        new Point2D.Float(-1, 0),
    };
    
    public Orientation() {
        this(ORIENTATION_SOUTH);
    }
    
    public Orientation(int orientation) {
        setOrientation(orientation);
    }

    public int getOrientation() {
        return orientation;
    }

    public void setOrientation(int orientation) {
        this.orientation = orientation;
    }
    
    public static int directionOrientation(double dx, double dy) {
        if (dx == 0 && dy == 0)
            return ORIENTATION_INVALID;
        if (dy >= 0) {
            if (dx >= 0) {
                if (dx >= dy)
                    return ORIENTATION_EAST;
                else
                    return ORIENTATION_SOUTH;
            }
            else { // dx < 0
                if (-dx >= dy)
                    return ORIENTATION_WEST;
                else
                    return ORIENTATION_SOUTH;
            }
        }
        else { // dy < 0
            if (dx >= 0) {
                if (dx >= -dy)
                    return ORIENTATION_EAST;
                else
                    return ORIENTATION_NORTH;
            }
            else { // dx < 0
                if (-dx >= -dy)
                    return ORIENTATION_WEST;
                else
                    return ORIENTATION_NORTH;
            }
        }
    }
    
    public static int inverse(int orientation) {
        switch(orientation) {
        case ORIENTATION_EAST:
            return ORIENTATION_WEST;
        case ORIENTATION_WEST:
            return ORIENTATION_EAST;
        case ORIENTATION_NORTH:
            return ORIENTATION_SOUTH;
        case ORIENTATION_SOUTH:
            return ORIENTATION_NORTH;
        }
        return ORIENTATION_INVALID;
    }
    
    public static int turn90(int orientation) {
        switch(orientation) {
        case ORIENTATION_EAST:
            return ORIENTATION_SOUTH;
        case ORIENTATION_WEST:
            return ORIENTATION_NORTH;
        case ORIENTATION_NORTH:
            return ORIENTATION_EAST;
        case ORIENTATION_SOUTH:
            return ORIENTATION_WEST;
        }
        return ORIENTATION_INVALID;
    }

    static String toString(int orientation) {
        int o = orientation+1;
        if (o < 0 || o > name.length)
            return "invalid";
        return name[o];
    }
 
    static Point2D getDirection(int orientation) {
        return direction[orientation+1];
    }
}
