/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.visualization;

import java.awt.Component;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import infovis.Visualization;

/**
 * Class ExcentricLabelVisualization
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.4 $
 */
public class ExcentricLabelVisualization extends VisualizationProxy {
    protected ExcentricLabels excentric;

    public ExcentricLabelVisualization(
        Visualization visualization,
        ExcentricLabels el) {
        super(visualization);
        setExcentric(el);
    }

    public ExcentricLabelVisualization(Visualization visualization) {
        this(visualization, new DefaultExcentricLabels());
    }
    
    public void setParent(Component parent) {
        super.setParent(parent);
        if (excentric != null)
            excentric.setVisualization(visualization);
    }

    public void paint(Graphics2D graphics, Rectangle2D bounds) {
        super.paint(graphics, bounds);
        if (excentric != null)
            excentric.paint(graphics, bounds);
    }
    
    public void setFisheyes(Fisheyes fisheyes) {
        super.setFisheyes(fisheyes);
        if (excentric instanceof DefaultExcentricLabels) {
            DefaultExcentricLabels e = 
                (DefaultExcentricLabels) excentric;
            e.setFisheyes(fisheyes);
        }
    }


    /**
     * Returns the excentric.
     * @return ExcentricLabels
     */
    public ExcentricLabels getExcentric() {
        return excentric;
    }
    
    public void setExcentric(ExcentricLabels el) {
        if (excentric == el)
            return;
        if (excentric != null) {
            excentric.setVisualization(null);
        }
        excentric = el;
        if (excentric != null) {
            excentric.setVisualization(this);
        }
    }
    
    public static ExcentricLabelVisualization find(Visualization vis) {
        return (ExcentricLabelVisualization)vis
            .findVisualization(ExcentricLabelVisualization.class);
    }

}
