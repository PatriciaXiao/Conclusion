/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization;

import infovis.Visualization;
import infovis.utils.StrokedPath;

import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

/**
 * Class StrokingExcentricItem
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class StrokingExcentricItem extends ExcentricItem {
    public StrokingExcentricItem(
        Visualization visualization,
        int index) {
        super(visualization, index);
    }
    
    public Point2D getCenterIn(Rectangle2D focus, Point2D ptOut) {
        Shape s = visualization.getShapeAt(index);
        if (s == null) {
            return null;
        }
        return StrokedPath.pointOnPathIn(s, focus, ptOut);
    }    

}
