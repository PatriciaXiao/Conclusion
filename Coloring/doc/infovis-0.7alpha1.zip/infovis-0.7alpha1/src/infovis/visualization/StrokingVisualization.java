/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.visualization;

import infovis.Table;
import infovis.column.BooleanColumn;
import infovis.column.FilterColumn;
import infovis.utils.StrokedPath;

import java.awt.*;
import java.awt.geom.*;

/**
 * Visualization for shapes considered as strokes and not filled shapes.
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.5 $
 */
public class StrokingVisualization extends DefaultVisualization {
    protected Stroke savedStroke;
    
    public StrokingVisualization(
        Table table,
        BooleanColumn selection,
        FilterColumn filter) {
        super(table, selection, filter);
        setDefaultColor(Color.BLACK);
        setDefaultSize(1);
        setMinSize(0);
        setMaxSize(10);
        setVisualColumnInvalidate(VISUAL_FILTER, false); // size doesn't invalidate links
    }

    public StrokingVisualization(Table table) {
        this(table, null, null);
    }

    public void paintShape(Graphics2D graphics, int row, Shape s) {
        // Do nothing, paintOutline will draw the shape
    }

    /**
     * Install the size before painting a stroke.
     * 
     * Sizes are managed at paint time, not layout time on Stroking visualizations.
     * 
     * @param graphics the Graphics2D
     * @param row the row being painted
     */    
    public void installSize(Graphics2D graphics, int row) {
        savedStroke = graphics.getStroke();
        graphics.setStroke(new BasicStroke((float)getSizeAt(row)));            
    }

    /**
     * Paints the shape after installing the size.
     * 
     * @param graphcs the Graphics2D
     * @param row the row being painted
     * @param s the Shape of the item
     */
    public void paintOutline(Graphics2D graphics, int row, Shape s) {
        if (selection != null
            && (!selection.isValueUndefined(row))
            && selectedColor != null) {
            graphics.setColor(selectedColor);
        }
        installSize(graphics, row);
        graphics.draw(s);
        graphics.setStroke(savedStroke);
    }

    public void paintLabel(Graphics2D graphics, int row, Shape s) {
        if (showingLabel) {
            String label = getLabelAt(row);
            if (label == null)
                return;
            FontMetrics fm = graphics.getFontMetrics();
            Rectangle2D bounds = s.getBounds2D();
            Rectangle2D maxCharBounds = fm.getMaxCharBounds(graphics);
            if (maxCharBounds.getWidth() > bounds.getWidth() * 2
                || maxCharBounds.getHeight() > (bounds.getHeight() * 2))
                return; // no reason to try
            Color c = getColorAt(row);
            int grey = (c.getRed() + c.getGreen() + c.getBlue()) / 3;
            if (grey < 127)
                graphics.setColor(Color.WHITE);
            else
                graphics.setColor(Color.BLACK);
            int w = fm.stringWidth(label);
            graphics.drawString(
                label,
                (float) (bounds.getCenterX() - w / 2),
                (float) (bounds.getCenterY() + fm.getDescent()));
        }
    }
    
    public boolean pickItem(
        Rectangle2D hitBox,
        Rectangle2D bounds,
        Shape s,
        int row) {
        if (s == null) {
            return false;
        }
        Rectangle2D rect = s.getBounds2D();
        if (rect.isEmpty()
            && hitBox.contains(rect.getX(), rect.getY()))
            return true;
        return StrokedPath.intersects(s, hitBox);
    }

    public void computeShapes(Rectangle2D bounds) {
        // Default implementation does nothing.
    }
    
    public LabeledItem createLabelItem(int row) {
        return new StrokingExcentricItem(this, row);
    }
}
