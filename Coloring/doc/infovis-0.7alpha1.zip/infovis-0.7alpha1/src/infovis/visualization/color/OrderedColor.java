/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.visualization.color;

import infovis.Column;
import infovis.column.NumberColumn;
import infovis.visualization.ColorVisualization;

import java.awt.Color;

import javax.swing.event.ChangeEvent;


/**
 * Color BasicVisualization for Ordered values.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.8 $
 */
public class OrderedColor extends ColorVisualization {
    static protected Color defaultStart = Color.WHITE;
    static protected Color defaultEnd = Color.BLACK;
    NumberColumn column;
    double       startRed;
    double       startGreen;
    double       startBlue;
    double       endRed;
    double       endGreen;
    double       endBlue;
    double       scale;
    double       origin;
    transient Color[] cache;
    
    /**
     * Constructor for OrderedColor.
     */
    public OrderedColor(NumberColumn column, Color start, Color end) {
       super(column);
       setColumn(column);
        setStart(start);
        setEnd(end);
    }
    
    public static void setDefaults(Color start, Color end) {
        defaultStart = start;
        defaultEnd = end;
    }

    /**
     * Creates a new OrderedColor object.
     *
     * @param column the managed column.
     */
    public OrderedColor(NumberColumn column) {
        this(column, defaultStart, defaultEnd);
    }

    /**
     * Sets the managed column.
     * @param c the column.
     */
    public void setColumn(Column c) {
        NumberColumn col = (NumberColumn)c;
        if (col == column)
            return;

        if (column != null)
            column.removeChangeListener(this);
        column = col;
        if (column != null) {
            column.addChangeListener(this);
            stateChanged(null);
        }
    }

    /**
     * @see javax.swing.event.ChangeListener#stateChanged(ChangeEvent)
     */
    public void stateChanged(ChangeEvent e) {
        update();
    }
    
    public void update() {
        origin = column.getDoubleMin();
        double range = column.getDoubleMax() - origin;
        scale = range == 0 ? 1 : 1.0 / range;
        if (cache == null) {
            cache = new Color[64];
        }
        double dt = 1 / 63.0;
        
        cache[0] = new Color((float)startRed, (float)startGreen, (float)startBlue); 
        for (int i = 1; i < 63; i++) {
            double t = i * dt;
            double red = (1 - t) * startRed + t * endRed;
            double green = (1 - t) * startGreen + t * endGreen;
            double blue = (1 - t) * startBlue + t * endBlue;
            cache[i] = new Color((float)red, (float)green, (float)blue); 
        }
        cache[63] = new Color((float)endRed, (float)endGreen, (float)endBlue); 
    }

    /**
     * @see infovis.visualization.ColorVisualization#getColumn()
     */
    public Column getColumn() {
        return column;
    }

    /**
     * @see infovis.visualization.ColorVisualization#getColor(int)
     */
    public int getColorValue(int row) {
        if (column.isValueUndefined(row))
            return 0;
        double t = (column.getDoubleAt(row) - origin) * scale;
        double red = (1 - t) * startRed + t * endRed;
        double green = (1 - t) * startGreen + t * endGreen;
        double blue = (1 - t) * startBlue + t * endBlue;

        return computeColor(red, green, blue, 1);
    }
    
    public Color getColor(int row) {
        if (column.isValueUndefined(row))
            return null;
        double t = (column.getDoubleAt(row) - origin) * scale;
        int i = (int)(t * 63 + 0.5);
        return cache[i];
    }

    /**
     * Returns the start Color.
     * 
     * @return the start Color.
     */
    public Color getStart() {
        return cache[0];
    }

    /**
     * Sets the start color.
     *
     * @param start the start Color.
     */
    public void setStart(Color start) {
        startRed = start.getRed() / 255.0;
        startGreen = start.getGreen() / 255.0;
        startBlue = start.getBlue() / 255.0;
        update();
    }
    
    /**
     * Returns the end Color.
     * 
     * @return the end Color.
     */
    public Color getEnd() {
        return cache[63];
    }

    /**
     * Sets the end color.
     *
     * @param end the end Color.
     */
    public void setEnd(Color end) {
        endRed = end.getRed() / 255.0;
        endGreen = end.getGreen() / 255.0;
        endBlue = end.getBlue() / 255.0;
        update();
    }

    public static Color getDefaultEnd() {
        return defaultEnd;
    }

    public static Color getDefaultStart() {
        return defaultStart;
    }

    public static void setDefaultEnd(Color color) {
        defaultEnd = color;
    }

    public static void setDefaultStart(Color color) {
        defaultStart = color;
    }

}
