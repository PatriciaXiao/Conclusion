/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.visualization.color;

import java.awt.color.*;
import java.awt.color.ColorSpace;
import java.awt.color.ICC_ColorSpace;

/**
 * Class Colors
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class Colors {
    public static ColorSpace RGB;
    public static float UprimeWhite;
    public static float VprimeWhite;
    public static Colors instance;
    public static float[] XYZwhite;
    
    protected Colors() {
        RGB =
            new ICC_ColorSpace(ICC_Profile.getInstance(ColorSpace.CS_sRGB));
        float[] RGBwhite = { 0, 0, 0};
        XYZwhite = RGBtoXYZ(RGBwhite);
        UprimeWhite = XYZtoUprime(XYZwhite);
        VprimeWhite = XYZtoVprime(XYZwhite);
    }
    
    public static Colors getInstance() {
        if (instance == null) {
            instance = new Colors();
        }
        return instance;
    }
    public float[] RGBtoXYZ(float[] rgb) {
        return RGB.toCIEXYZ(rgb);
    }
    public float[] XYZtoRGB(float[] xyz) {
        return RGB.fromCIEXYZ(xyz);
    }
    
    public static float YtoL(float y) {
        return (float)(116*Math.pow(y, 1.0/3.0)-16);
    }
    
    public static float XYZtoUprime(float[] xyz) {
        return 4*xyz[0]/(xyz[0]+15*xyz[1]+3*xyz[2]); 
    }
    
    public static float XYZtoVprime(float[] xyz) {
        return 9*xyz[1]/(xyz[0]+15*xyz[1]+3*xyz[2]);
    }
    
    /**
     * Converts XYZ to L*u*v*
     * 
     * @param xyz the values in XYZ colorspace
     * @return the values in L*u*v* colorspace
     */
    public float[] XYZtoLuv(float[] xyz) {
        float uprime = XYZtoUprime(xyz);
        float vprime = XYZtoVprime(xyz);
        float Lstar = YtoL(xyz[1]);        
        float ustar = 13*Lstar*(uprime-UprimeWhite);
        float vstar = 13*Lstar*(vprime-VprimeWhite);        
        float[] ret = new float[3];
        
        ret[0] = Lstar;
        ret[1] = ustar;
        ret[2] = vstar;
        return ret;
    }
    
    /**
     * Converts XYZ to L*a*b*
     * 
     * @param xyz the values in XYZ colorspace
     * @return the values in L*a*b* colorspace
     */
    public float[] XYZtoLab(float[] xyz) {
        float Lstar = YtoL(xyz[1]);
        float[] ret = new float[3];
        double Y13 = Math.pow(xyz[1], 1/3.0);
        
        ret[0] = Lstar;
        ret[1] = 500 * 
            (float)(Math.pow(xyz[0]/XYZwhite[0],1/3.0)-Y13);
        ret[2] = 200 *
            (float)(Y13 - Math.pow(xyz[2]/XYZwhite[2],1/3.0));
        
        return ret;
    }
}
