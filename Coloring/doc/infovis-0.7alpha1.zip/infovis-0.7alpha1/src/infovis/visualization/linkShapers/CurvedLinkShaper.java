/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.linkShapers;

import infovis.Visualization;
import infovis.column.ObjectColumn;

import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.QuadCurve2D;

/**
 * Class CurvedLinkShaper
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.3 $
 */
public class CurvedLinkShaper extends DefaultLinkShaper {
    protected double angle;
    protected double sin;
    protected double cos;

    public CurvedLinkShaper(
        Visualization visualization,
        ObjectColumn nodeShapes,
        double angle) {
        super(visualization, nodeShapes);
        setAngle(angle);
    }
    
    public CurvedLinkShaper(
        Visualization visualization,
        ObjectColumn nodeShapes) {
        this(visualization, nodeShapes, Math.PI/2);
    }
    
    public String getName() {
        return "Curved";
    }

    /**
     * Change the starting angle in radians.
     * 
     * @param angle the starting angle.
     */
    public void setAngle(double angle) {
        this.angle = angle;
        sin = Math.sin(angle);
        cos = Math.cos(angle);        
    }
    
    /**
     * Returns the starting angle.
     * 
     * @return the starting angle.
     */
    public double getAngle() {
        return angle;
    }
    
    public Shape createLink(
        Point2D startPos,
        int startOrientation,
        Point2D endPos,
        int endOrientation,
        Shape prevShape) {
        QuadCurve2D.Double quad;
        if (prevShape instanceof QuadCurve2D.Double) {
            quad = (QuadCurve2D.Double) prevShape;
        }
        else {
            quad = new QuadCurve2D.Double();
        }

        quad.x1 = startPos.getX();
        quad.y1 = startPos.getY();
        quad.x2 = endPos.getX();
        quad.y2 = endPos.getY();

        double x = (quad.x2 - quad.x1)/2;
        double y = (quad.y2 - quad.y1)/2;
        quad.ctrlx = quad.x1 + x*cos - y*sin;
        quad.ctrly = quad.y1 + x*sin + y*cos;

        return quad;
    }
}
