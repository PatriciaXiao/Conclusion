/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization;

import infovis.Visualization;

import javax.swing.JComponent;

/**
 * Class VisualizationInteractor
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public interface VisualizationInteractor {
    public abstract void install(JComponent comp);
    public abstract void uninstall(JComponent comp);
    public abstract Visualization getVisualization();
    public abstract void setVisualization(Visualization vis);
    public abstract JComponent getJComponent();
}