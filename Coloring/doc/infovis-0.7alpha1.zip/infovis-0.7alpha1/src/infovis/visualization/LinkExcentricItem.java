/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization;

import infovis.Visualization;

/**
 * Class LinkExcentricItem
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class LinkExcentricItem extends StrokingExcentricItem {
    LinkVisualization linkVisualization;

    public LinkExcentricItem(Visualization visualization, int index) {
        super(visualization, index);
        linkVisualization = (LinkVisualization) visualization;
    }

    public String getLabel() {
        String lab = super.getLabel();
        if (lab != null)
            return lab;

        NodeAccessor accessor = linkVisualization.getNodeAccessor();
        int start = accessor.getStartNode(index);
        int end = accessor.getEndNode(index);
        if (start == -1 || end == -1)
            return null;
        String startLabel =
            linkVisualization.getNodeVisualization().getLabelAt(start);
        if (startLabel == null) {
            startLabel = "node" + start;
        }
        String endLabel =
            linkVisualization.getNodeVisualization().getLabelAt(end);
        if (endLabel == null) {
            endLabel = "node" + end;
        }

        return startLabel + "->" + endLabel;
    }
}
