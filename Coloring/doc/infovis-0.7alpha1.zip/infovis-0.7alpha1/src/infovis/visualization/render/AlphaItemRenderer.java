/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.render;

import infovis.column.NumberColumn;
import infovis.visualization.DefaultVisualization;
import infovis.visualization.VisualColumnDescriptor;

import java.awt.*;
import java.awt.Graphics2D;
import java.awt.Shape;

/**
 * Class AlphaItemRenderer
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class AlphaItemRenderer extends AbstractItemRenderer {
    protected double defaultAlpha = 1.0;
    protected NumberColumn alphaColumn;
    protected double amin;
    protected double amax;
    protected double scale;
                
    public AlphaItemRenderer(
        DefaultVisualization visualization,
        VisualColumnDescriptor desc) {
        super("Alpha", visualization, desc);
    }

    public double getRank() {
        return RANK_BACKGROUND;
    }

    public boolean install(Graphics2D graphics) {
        alphaColumn = (NumberColumn)desc.getColumn();

        if (alphaColumn == null) {
            scale = 0;
        }
        else {
            amin = alphaColumn.getDoubleMin();
            amax = alphaColumn.getDoubleMax();
            if (amin == amax)
                scale = 0;
            else
                scale = 1.0 / (amax - amin);
        }        
        return true;
    }

    public double getAlphaAt(int row) {
        if (alphaColumn == null)
            return defaultAlpha;
        else
            return (alphaColumn.getDoubleAt(row) - amin) * scale;
    }

    public double getDefaultAlpha() {
        return defaultAlpha;
    }

    public void setDefaultAlpha(double alpha) {
        defaultAlpha = alpha;
        invalidate();
    }
    
    public boolean paint(Graphics2D graphics, int row, Shape shape) {
        if (alphaColumn == null) {
            graphics.setComposite(
                AlphaComposite.getInstance(
                    AlphaComposite.SRC_OVER,
                    (float) defaultAlpha));
        }
        else {
            graphics.setComposite(
                AlphaComposite.getInstance(
                    AlphaComposite.SRC_OVER,
                    (float) getAlphaAt(row)));
        }
        return true;
    }

}
