/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.render;

import infovis.Visualization;
import infovis.column.BooleanColumn;
import infovis.visualization.DefaultVisualization;
import infovis.visualization.VisualColumnDescriptor;

import java.awt.*;
import java.awt.Graphics2D;
import java.awt.Shape;

/**
 * Class SelectionItemRenderer
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class SelectionItemRenderer extends AbstractItemRenderer {
    /** The color of selected items */
    public static Color defaultSelectedColor = Color.RED;
    /** The color of unselected items */
    protected static Color defaultUnselectedColor = Color.BLACK;

    /** The color of selected items */
    protected Color selectedColor;
    /** The color of unselected items */
    protected Color unselectedColor;
    
    /** The boolean column containing and managing the selection */
    protected transient BooleanColumn selection;
    
    public SelectionItemRenderer(
        DefaultVisualization visualization,
        VisualColumnDescriptor desc) {
        super(Visualization.VISUAL_SELECTION, visualization, desc);
        selectedColor = defaultSelectedColor;
        unselectedColor = defaultUnselectedColor;
    }

    public double getRank() {
        return RANK_OUTLINE;
    }
    
    public Color getColorAt(int row) {
        if (selection == null) {
            return unselectedColor;
        }
        return selection.isValueUndefined(row) ? unselectedColor : selectedColor;
    }

    public boolean install(Graphics2D graphics) {
        selection = (BooleanColumn)visualization.getVisualColumn(getName());
        return true;
    }

    public boolean paint(Graphics2D graphics, int row, Shape shape) {
        graphics.setColor(getColorAt(row));
        return false;
    }

    /**
     * Returns the selectedColor.
     *
     * @return Color
     */
    public Color getSelectedColor() {
        return selectedColor;
    }

    /**
     * Sets the selectedColor.
     *
     * @param selectedColor The selectedColor to set
     */
    public void setSelectedColor(Color selectedColor) {
        this.selectedColor = selectedColor;
        invalidate();
    }

    /**
     * Returns the unselectedColor.
     *
     * @return Color
     */
    public Color getUnselectedColor() {
        return unselectedColor;
    }

    /**
     * Sets the unselectedColor.
     *
     * @param unselectedColor The unselectedColor to set
     */
    public void setUnselectedColor(Color unselectedColor) {
        this.unselectedColor = unselectedColor;
        invalidate();
    }
}
