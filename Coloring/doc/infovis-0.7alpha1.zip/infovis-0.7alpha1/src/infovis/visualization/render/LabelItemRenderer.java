/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.render;

import infovis.Column;
import infovis.Visualization;
import infovis.visualization.DefaultVisualization;
import infovis.visualization.VisualColumnDescriptor;

import java.awt.*;
import java.awt.geom.Rectangle2D;

/**
 * Class LabelItemRenderer
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class LabelItemRenderer extends AbstractItemRenderer {
    /** The column used for labeling */
    protected transient Column labelColumn;
    /** The default font */
    protected Font defaultFont;
    /** True when painting labels */
    protected boolean showingLabel = true;

    protected transient ColorItemRenderer colorRenderer;

    public LabelItemRenderer(
        DefaultVisualization visualization,
        VisualColumnDescriptor desc) {
        super(Visualization.VISUAL_LABEL, visualization, desc);
    }

    public double getRank() {
        return RANK_LABEL;
    }

    public boolean install(Graphics2D graphics) {
        labelColumn = visualization.getVisualColumn(getName());
        colorRenderer =
            (ColorItemRenderer) visualization.getItemRenderer(
                Visualization.VISUAL_COLOR);
        return false;
    }

    public Color getColorAt(int row) {
        if (colorRenderer == null) {
            return Color.WHITE;
        }
        return colorRenderer.getColorAt(row);
    }

    /**
     * Returns the label associated with the specified row.
     *
     * @param row the row.
     *
     * @return the label associated with the specified row.
     */
    public String getLabelAt(int row) {
        if (labelColumn == null)
            return null;
        return labelColumn.getValueAt(row);
    }

    public boolean paint(Graphics2D graphics, int row, Shape shape) {
        if (!showingLabel) {
            return false;
        }
        String label = getLabelAt(row);
        if (label == null)
            return false;
        FontMetrics fm = graphics.getFontMetrics();
        Rectangle2D bounds = shape.getBounds2D();

        Rectangle2D maxCharBounds = fm.getMaxCharBounds(graphics);
        if (maxCharBounds.getWidth() > bounds.getWidth() * 2
            || maxCharBounds.getHeight() > (bounds.getHeight() * 2))
            return false; // no reason to try
        Color c = getColorAt(row);
        int grey = (c.getRed() + c.getGreen() + c.getBlue()) / 3;
        if (grey < 127)
            graphics.setColor(Color.WHITE);
        else
            graphics.setColor(Color.BLACK);

        int w = fm.stringWidth(label);
        Shape clip = null;
        if (w > bounds.getWidth()) {
            clip = graphics.getClip();
            graphics.clip(shape);
        }

        graphics.drawString(
            label,
            (float) (bounds.getCenterX() - w / 2),
            (float) (bounds.getCenterY() + fm.getDescent()));
        if (clip != null) {
            graphics.setClip(clip);
        }

        return true;
    }

    /**
     * Returns the defaultFont.
     *
     * @return Font
     */
    public Font getDefaultFont() {
        if (defaultFont == null && visualization.getParent() != null)
            return visualization.getParent().getFont();
        return defaultFont;
    }

    /**
     * Sets the defaultFont.
     *
     * @param defaultFont The defaultFont to set
     */
    public void setDefaultFont(Font defaultFont) {
        this.defaultFont = defaultFont;
        invalidate();
    }

    /**
     * Returns the showingLabel.
     * @return boolean
     */
    public boolean isShowingLabel() {
        return showingLabel;
    }

    /**
     * Sets the showingLabel.
     * @param showingLabel The showingLabel to set
     */
    public void setShowingLabel(boolean showingLabel) {
        this.showingLabel = showingLabel;
        invalidate();
    }

}
