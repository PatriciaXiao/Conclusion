/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.render;

import infovis.visualization.DefaultVisualization;
import infovis.visualization.VisualColumnDescriptor;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import javax.swing.CellRendererPane;
import javax.swing.JTextArea;

/**
 * Class WrappingLabelItemRenderer
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class WrappingLabelItemRenderer extends LabelItemRenderer {
    
    
    public WrappingLabelItemRenderer(
        DefaultVisualization visualization,
        VisualColumnDescriptor desc) {
        super(visualization, desc);
    }

    public static ArrayList computeLines(String s, final FontMetrics fm, double width) {
        ArrayList lines = new ArrayList();
        int start = 0;
        int lastWord = 0;
        int i;
        //float sw = fm.charWidth(' ');
        lines.add(null);
        
        for(i = 0; i < s.length(); i++) {
            if (Character.isWhitespace(s.charAt(i))) {
                if ((i - start) < 1) {
                    start = i;
                    continue;
                }
                String line = s.substring(start, i);
                if (fm.stringWidth(line) >= width && start != lastWord) {
                    start = lastWord;
                    lastWord = start;
                    i = start;
                    lines.add(null);
                }
                else {
                    lines.set(lines.size()-1, line);
                    lastWord = i+1;
                }
            }
        }
        if (i < s.length()) {
            lines.set(lines.size()-1, s.substring(i));   
        }
        else {
            lines.remove(lines.size()-1);
        }
        
        return lines;
    }
    


    public boolean paint(Graphics2D graphics, int row, Shape s) {
        if (showingLabel) {
            String label = getLabelAt(row);
            if (label == null)
                return false;
            FontMetrics fm = graphics.getFontMetrics();
            Rectangle2D bounds = s.getBounds2D();

            Rectangle2D maxCharBounds = fm.getMaxCharBounds(graphics);
            if (maxCharBounds.getWidth() > bounds.getWidth() * 2
                || maxCharBounds.getHeight() > (bounds.getHeight() * 2))
                return false; // no reason to try
            Color c = getColorAt(row);
            int grey =
                (c.getRed() + c.getGreen() + c.getBlue()) / 3;
            if (grey < 127)
                graphics.setColor(Color.WHITE);
            else
                graphics.setColor(Color.BLACK);

            int w = fm.stringWidth(label);                
            if (w > bounds.getWidth()) {
                ArrayList lines = computeLines(label, fm, bounds.getWidth());
                Rectangle rect = s.getBounds();
                JTextArea area = new JTextArea(label);
                area.setWrapStyleWord(true);
                area.setSize(rect.width, rect.height);
                area.setOpaque(false);
                CellRendererPane pane = new CellRendererPane();
                pane.add(area);

                pane.paintComponent(
                    graphics,
                    area,
                    null,
                    rect.x + 1,
                    rect.y + 1,
                    rect.width - 1,
                    rect.height - 1,
                    true);
            }
            else {
//                Shape clip = graphics.getClip();
//                graphics.clip(s);

                
                graphics.drawString(
                    label,
                    (float) (bounds.getCenterX() - w / 2),
                    (float) (bounds.getCenterY() + fm.getDescent()));
//                graphics.setClip(clip);
            }
        }
        return true;
    }
}
