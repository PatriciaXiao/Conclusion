/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.render;

import infovis.Visualization;
import infovis.column.NumberColumn;
import infovis.visualization.DefaultVisualization;
import infovis.visualization.VisualColumnDescriptor;

import java.awt.Graphics2D;
import java.awt.Shape;

/**
 * Class SizeItemRenderer
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class SizeItemRenderer extends AbstractItemRenderer {
    public static double defaultMinSize = 1;
    public static double defaultMaxSize = 50;
    public static double defaultDefaultSize = 30;
    
    protected double minSize;
    protected double maxSize;
    protected double defaultSize;
    protected NumberColumn sizeColumn;
    
    protected transient double smin;
    protected transient double smax;
    protected transient double sscale;

    public SizeItemRenderer(
        DefaultVisualization visualization,
        VisualColumnDescriptor desc) {
        super(Visualization.VISUAL_SIZE, visualization, desc);
    }
    
    public double getRank() {
        return RANK_ITEM;
    }

    public boolean install(Graphics2D graphics) {
        sizeColumn = (NumberColumn)visualization.getVisualColumn(getName());
        if (sizeColumn != null) {
            smin = sizeColumn.getDoubleMin();
            smax = sizeColumn.getDoubleMax();
            if (smin == smax)
                sscale = 0;
            else
                sscale = (maxSize - minSize) / (smax - smin);
        }        
        return true;
    }

    public boolean paint(Graphics2D graphics, int row, Shape shape) {
        return false;
    }


    /**
     * Returns the size associated with the specified row.
     *
     * @param row the row.
     *
     * @return the size associated with the specified row.
     */
    public double getSizeAt(int row) {
        if (sizeColumn == null)
            return defaultSize;
        double smin = sizeColumn.getDoubleMin();
        double smax = sizeColumn.getDoubleMax();
        if (smin == smax)
            return maxSize;
        double sscale = (maxSize - minSize) / (smax - smin);
        return (sizeColumn.getDoubleAt(row) - smin) * sscale + minSize;
    }

    /**
     * Returns the maxSize.
     *
     * @return double
     */
    public double getMaxSize() {
        return maxSize;
    }

    /**
     * Returns the minSize.
     *
     * @return double
     */
    public double getMinSize() {
        return minSize;
    }

    /**
     * Returns the defaultSize.
     *
     * @return double
     */
    public double getDefaultSize() {
        return defaultSize;
    }

    /**
     * Sets the maxSize.
     *
     * @param maxSize The maxSize to set
     */
    public void setMaxSize(double maxSize) {
        this.maxSize = maxSize;
        visualization.invalidate(sizeColumn);
    }

    /**
     * Sets the minSize.
     *
     * @param minSize The minSize to set
     */
    public void setMinSize(double minSize) {
        this.minSize = minSize;
        visualization.invalidate(sizeColumn);
    }

    /**
     * Sets the defaultSize.
     *
     * @param defaultSize The defaultSize to set
     */
    public void setDefaultSize(double defaultSize) {
        this.defaultSize = defaultSize;
        visualization.invalidate(sizeColumn);
    }

}
