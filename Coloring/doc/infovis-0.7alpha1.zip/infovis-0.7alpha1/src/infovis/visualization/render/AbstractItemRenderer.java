/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.render;

import infovis.visualization.*;
import infovis.visualization.DefaultVisualization;
import infovis.visualization.VisualColumnDescriptor;

/**
 * Class AbstractItemRenderer
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public abstract class AbstractItemRenderer implements ItemRenderer {
    protected String name;
    protected DefaultVisualization visualization;
    protected VisualColumnDescriptor desc;

    public AbstractItemRenderer(
        String name,
        DefaultVisualization visualization,
        VisualColumnDescriptor desc) {
        this.name = name;
        this.visualization = visualization;
        this.desc = desc;
    }
    
    public DefaultVisualization getDefaultVisualization() {
        return visualization;
    }

    public String getName() {
        return name;
    }

    public VisualColumnDescriptor getVisualColumnDescriptor() {
        return desc;
    }
    
    public void invalidate() {
        if (visualization.getVisualColumnDescriptor(getName()).isInvalidate()) {
            visualization.invalidate();
        }
        else {
            visualization.repaint();
        }
    }

}
