/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.render;

import java.lang.reflect.Constructor;
import java.util.ArrayList;

import infovis.visualization.*;
import infovis.visualization.DefaultVisualization;
import infovis.visualization.VisualColumnDescriptor;

/**
 * Class ItemRendererFactory
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class ItemRendererFactory {
    private static ItemRendererFactory instance;
    
    protected ArrayList creators = new ArrayList();
    
    public static ItemRendererFactory getInstance() {
        if (instance == null) {
            instance = new ItemRendererFactory();            
        }
        return instance;
    }
    
    public static ItemRendererFactory setInstance(ItemRendererFactory factory) {
        ItemRendererFactory old = instance;
        instance = factory;
        return old;
    }
    
    public ItemRendererFactory() {
        createDefaults();
    }
    
    protected void createDefaults() {
        Class[] defaultRenderers = {
            AlphaItemRenderer.class,
            ColorItemRenderer.class,
            LabelItemRenderer.class,
            SelectionItemRenderer.class
        };
        add(new DefaultCreator(
            DefaultVisualization.class,
            defaultRenderers));
    }

    public void create(DefaultVisualization visualization, VisualColumnDescriptor desc) {
        for (int i = 0; i < size(); i++) {
            Creator c = getCreator(i);
            if (c.isCompatible(visualization, desc)) {
                c.install(visualization, desc);
            }
        }
    }

    public void add(Creator c) {
        creators.add(c);    
    }
    
    public boolean remove(Creator c) {
        return creators.remove(c);
    }
    
    public int size() {
        return creators.size();
    }
    
    public Creator getCreator(int index) {
        return (Creator)creators.get(index);
    }
    
    public static interface Creator {
        public abstract boolean isCompatible(DefaultVisualization visualization, VisualColumnDescriptor desc);
        public abstract boolean isWeaklyCompatible(DefaultVisualization visualization, VisualColumnDescriptor desc);
        public abstract boolean install(DefaultVisualization visualization, VisualColumnDescriptor desc);
    }
    
    public static class DefaultCreator implements Creator {
        protected Class exactClass;
        protected Class renderers[];
        
        public DefaultCreator(Class exactClass, Class[] renderers) {
            this.exactClass = exactClass;
            this.renderers = renderers;
        }
        
        public boolean isCompatible(
            DefaultVisualization visualization,
            VisualColumnDescriptor desc) {
            return visualization.getClass().equals(exactClass);
        }

        public boolean isWeaklyCompatible(
            DefaultVisualization visualization,
            VisualColumnDescriptor desc) {
            return exactClass.isAssignableFrom(visualization.getClass());
        }

        public boolean install(
            DefaultVisualization visualization,
            VisualColumnDescriptor desc) {
            Class[] parameterTypes = { 
                DefaultVisualization.class,
                VisualColumnDescriptor.class
            };
            Object[] initargs = {
                visualization,
                desc
            };
            for (int i = 0; i < renderers.length; i++) {
                Class rend = renderers[i];
                try {
                    Constructor c = rend.getConstructor(parameterTypes);
                    ItemRenderer ir = (ItemRenderer) c.newInstance(initargs);
                    visualization.insertItemRendererSorted(ir);
                }
                catch(Exception e) {
                }
            }
            return true;
        }

    }
}
