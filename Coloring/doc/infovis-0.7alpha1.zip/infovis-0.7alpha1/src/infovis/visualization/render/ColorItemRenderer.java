/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization.render;

import java.awt.*;
import java.awt.Graphics2D;
import java.awt.Shape;

import infovis.Column;
import infovis.visualization.*;
import infovis.visualization.VisualColumnDescriptor;

/**
 * Class ColorItemRenderer
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class ColorItemRenderer extends AbstractItemRenderer {
    /** The column used for color */
    protected Column colorColumn;
    /** The ColorVisualization */
    protected ColorVisualization colorVisualization;
    /** The default color */
    protected Color defaultColor = new Color(0, 0, 0.6f);
    
    public ColorItemRenderer(
        DefaultVisualization visualization,
        VisualColumnDescriptor desc) {
        super("Color", visualization, desc);
    }

    public double getRank() {
        return RANK_BACKGROUND;
    }
    
    public boolean install(Graphics2D graphics) {
        colorVisualization = visualization.getColorVisualization();
        return true;
    }

    /**
     * DOCUMENT ME!
     *
     * @param row DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public Color getColorAt(int row) {
        if (colorVisualization == null) {
            return defaultColor;
        }
        else {
            return colorVisualization.getColor(row);
        }
    }
    
    public boolean paint(Graphics2D graphics, int row, Shape shape) {
        graphics.setColor(getColorAt(row));
        return true;
    }

    public ColorVisualization getColorVisualization() {
        return colorVisualization;
    }

    public Color getDefaultColor() {
        return defaultColor;
    }

    public void setColorVisualization(ColorVisualization cv) {
        colorVisualization = cv;
        invalidate();
    }

    public void setDefaultColor(Color color) {
        defaultColor = color;
        invalidate();
    }

}
