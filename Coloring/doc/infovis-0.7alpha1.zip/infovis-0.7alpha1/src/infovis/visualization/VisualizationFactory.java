/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.visualization;

import infovis.*;

import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * A VisualizationFactory is used to keep track of all the visualizations
 * compatible with a specified data structure and to create the visualizations
 * from the data structures.
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.6 $
 */
public class VisualizationFactory {
    static VisualizationFactory instance;
    
    Map creators = new HashMap();
    
    public VisualizationFactory(){
        createDefaults();
    }
    
    protected void createDefaults() {
        InputStream in = 
            ClassLoader.getSystemResourceAsStream("infovis/visualizations.properties");
        if (in != null)
            try {
            Properties props = new Properties();
            props.load(in);
            for (int i = 0; i < 1000; i++) {
                String suffix = "."+i;
                String name = props.getProperty("name"+suffix);
                if (name == null) {
                    break;
                }
                String data= props.getProperty("data"+suffix);
                if (data== null) {
                    break;
                }
                String visualization = props.getProperty("visualization"+suffix);
                if (visualization == null) {
                    break;
                }
                try {
                    Class dataClass = Class.forName(data);
                    setDefault(name, dataClass, visualization);
                }
                catch(ClassNotFoundException e) {                
                }
            }
            return;
        }
        catch(FileNotFoundException e) {
        }
        catch(IOException e) {
        }
        // avoid loading all the visualization classes at startup
//        setDefault("Scatter Plot", Table.class,
//            "infovis.table.visualization.ScatterPlotVisualization");
//        setDefault("Time Series", Table.class,
//            "infovis.table.visualization.TimeSeriesVisualization");
    }
    
    public static VisualizationFactory getInstance() {
        if (instance == null) {
            instance = new VisualizationFactory();
        }
        return instance;
    }
    
    public static void setInstance(VisualizationFactory shared) {
        instance = shared;
    }
    
    public void add(Creator creator) {
        creators.put(creator.getName(), creator);
    }
    
    public static void addVisualizationFactory(Creator c){
    	getInstance().add(c);
    }
    
    
    public void setDefault(String name, Class tableClass, String visualizationClass) {
        add(new DefaultCreator(name, tableClass, visualizationClass));
    }
    
    public Creator[] getCompatibleCreators(Table table) {
        ArrayList list = new ArrayList();
        for (Iterator iter = iterator(table); iter.hasNext(); ) {
            Creator c = (Creator)iter.next();
            list.add(c);
        }
        Creator[] creators = new Creator[list.size()];
        list.toArray(creators);
        return creators;
    }
    
    /**
     * Returns an iterator over the visualization creators 
     * compatible with the specified table.
     * 
     * @param table the table
     * @return an iterator over the visualization creators
     * compatible with the specified table.
     */    
    public Iterator iterator(Table table) {
        return new VisualizationIterator(table); 
    }
    
    class VisualizationIterator implements Iterator {
        Iterator entriesIterator;
        Table table;
        Creator current;
        
        public VisualizationIterator(Table table) {
            this.table = table;
            entriesIterator = creators.entrySet().iterator();
            skipIncompatible();
        }
        
        void skipIncompatible() {
            while (entriesIterator.hasNext()) {
                Map.Entry entry = (Map.Entry)entriesIterator.next();
                current = (Creator)entry.getValue();
                if (current.isCompatible(table))
                    return;                 
            }
            current = null;
        }
        
        public boolean hasNext() {
            return current != null;
        }
        
        public Object next() {
            Creator ret = current;
            current = null;
            skipIncompatible();
            return ret;
        }
        public void remove() {
        }

    }

    public interface Creator {
         Visualization create(Table table);
         String getName();
         boolean isCompatible(Table table);
    }
    
    public static class DefaultCreator implements Creator {
        String name;
        Class tableClass;
        String visualizationClass;
        
        public DefaultCreator(String name, Class tableClass, String visualizationClass) {
            this.name = name;
            this.tableClass = tableClass;
            this.visualizationClass = visualizationClass; 
        }
        
        public String getName() {
            return name;
        }
        
        public boolean isCompatible(Table table) {
            return tableClass.isAssignableFrom(table.getClass());
        }
        
        public Visualization create(Table table) {
            Class c;
            try {
                c = Class.forName(visualizationClass);
            }
            catch(ClassNotFoundException e) {
                return null;
            }
            Class[] parameterTypes = { tableClass };
            
            Constructor cons;
            try {
                cons = c.getConstructor(parameterTypes);
            }
            catch (NoSuchMethodException e) {
                return null;
            }
            if (cons != null) {
                Object[] args = { table };
                try {
                    return (Visualization)cons.newInstance(args);
                }
                catch (InstantiationException e) {
                }
                catch (IllegalAccessException e) {
                }
                catch (InvocationTargetException e) {
                }
            }
            return null;
        }
    }
}
