/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.visualization;

import java.awt.Graphics2D;
import java.awt.Shape;

/**
 * A ItemRenderer performs one or several stage of painting
 * for each item of a Visualization.
 * 
 * An item pipeline object performs one or several stage for painting a visualization
 * item.  Several pipeline objects are used to perform the whole rendering of one
 * item.  Each pipeline object is ranked so that it can be called in the right order
 * by default.  DefaultVisualization allows for an explicit reordering of these
 * objects. 
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public interface ItemRenderer {
    /** Rank for background painting, in the range [RANK_BACKGROUND,RANK_BACKGROUND+1[ */
    public static final double RANK_BACKGROUND = 0.0;
    
    /** Rank for item painting, in the range [RANK_ITEM,RANK_ITEM+1[ */
    public static final double RANK_ITEM = 1.0;
    
    /** Rank for painting an outline, in the range [RANK_OUTLINE,RANK_OUTLINE+1[ */
    public static final double RANK_OUTLINE = 2.0;
    
    /** Rank for painting an overlay, in the range [RANK_OVERLAY,RANK_OVERLAY+1[ */
    public static final double RANK_OVERLAY = 3.0;
    
    /** Rank for painting a label, in the range [RANK_LABEL,RANK_LABEL+1[ */
    public static final double RANK_LABEL= 4.0;
    
    /**
     * Returns the default rank of this pipeline object.
     * 
     * @return the default rank.
     */
    public abstract double getRank();
    
    /**
     * Returns the name of this pipeline object.
     * 
     * @return the name.
     */
    public abstract String getName();
    
    public abstract VisualColumnDescriptor getVisualColumnDescriptor();
    public abstract DefaultVisualization getDefaultVisualization();

    public abstract boolean install(Graphics2D graphics);

    
    public abstract boolean paint(
        Graphics2D graphics,
        int row,
        Shape shape);
}
