/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.graph;

import javax.swing.event.EventListenerList;

import infovis.Graph;
import infovis.Table;
import infovis.column.IntColumn;
import infovis.table.DefaultTable;
import infovis.table.TableProxy;
import infovis.utils.*;
import infovis.utils.RowIterator;
import infovis.utils.TableIterator;

/**
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.15 $
 */
public class DefaultGraph extends TableProxy implements Graph {
    /** Name of the column containing the index of the first out edge. */
    public static final String FIRSTEDGE_COLUMN = "#FirstEdge";
    /** Name of the column containing the index of the last out edge. */
    public static final String LASTEDGE_COLUMN = "#LastEdge";
    /** Name of the column containing the "in" vertex in the edge table. */
    public static final String INVERTEX_COLUMN = "#InVertex";
    /** Name of the column containing the "out" vertex in the edge table. */
    public static final String OUTVERTEX_COLUMN = "#OutVertex";
    /** Name of the column containing the next edge in the edge table. */
    public static final String NEXTEDGE_COLUMN = "#NextEdge";
    /** Name of the column containing the previous edge in the edge table. */
    public static final String PREVEDGE_COLUMN = "#PrevEdge";
//    /** The Metadata key of the out vertex table in the underlying table. */
//    public static final String OUT_VERTEX_TABLE_METADATA = "OUT_VERTEX_TABLE_METADATA";
//    /** The Metadata key of the in vertex table in the underlying table. */
//    public static final String IN_VERTEX_TABLE_METADATA = "IN_VERTEX_TABLE_METADATA";
    /** The Metadata key of the vertex table in the underlying table. */
    public static final String VERTEX_TABLE_METADATA = "VERTEX_TABLE_METADATA";
    /** Name of the column containing the index of the first int edge. */
    public static final String OUT_FIRSTEDGE_COLUMN = "#outFirstEdge";
    /** Name of the column containing the index of the last out edge. */
    public static final String OUT_LASTEDGE_COLUMN = "#outLastEdge";
    /** Name of the column containing the next out edge in the edge table. */
    public static final String OUT_NEXTEDGE_COLUMN = "#outNextEdge";
    /** Name of the column containing the previous out edge in the edge table. */
    public static final String OUT_PREVEDGE_COLUMN = "#outPrevEdge";
    
    /** The vertex table */
    protected Table vertexTable;

    /** The first edge of each "in" vertex stored in the vertexTable. */
    protected IntColumn vertexFirstEdge;
    /** The last edge of each "in" vertex stored in the vertexTable */
    protected IntColumn vertexLastEdge;
    /** The first edge of each "out" vertex stored in the vertexTable. */
    protected IntColumn outVertexFirstEdge;
    /** The last edge of each "out" vertex stored in the vertexTable */
    protected IntColumn outVertexLastEdge;
    

    /** The in vertex of each edge stored in the edgeTable */
    protected IntColumn edgeInVertex;
    /** The out vertex of each edge stored in the edgeTable */
    protected IntColumn edgeOutVertex;
    
    /** The next edge in the list of the "in" vertex, stored in the edgeTable */
    protected IntColumn nextEdge;
    /** The prev edge in the list of the "in" vertex, stored in the edgeTable */
    protected IntColumn prevEdge;
    /** The next edge in the list of the "out" vertex, stored in the edgeTable */
    protected IntColumn outNextEdge;
    /** The prev edge in the list of the "out" vertex, stored in the edgeTable */
    protected IntColumn outPrevEdge;
    
    protected EventListenerList listeners;    

    protected IdManager vertexIdManager;
    protected IdManager edgeIdManager;

    public DefaultGraph(
        Table edgeTable,
        Table vertexTable) {
        super(edgeTable);
        if (vertexTable == null) {
            vertexTable =
                (Table) getMetadata().get(VERTEX_TABLE_METADATA);
            if (vertexTable == null) {
                vertexTable = new DefaultTable();
                getMetadata().put(VERTEX_TABLE_METADATA, vertexTable);
            }
        }
        this.vertexTable = vertexTable;
        vertexFirstEdge =
            IntColumn.findColumn(vertexTable, FIRSTEDGE_COLUMN);
        vertexLastEdge =
            IntColumn.findColumn(vertexTable, LASTEDGE_COLUMN);
        outVertexFirstEdge =
            IntColumn.findColumn(vertexTable, OUT_FIRSTEDGE_COLUMN);
        outVertexLastEdge =
            IntColumn.findColumn(vertexTable, OUT_LASTEDGE_COLUMN);
        
        edgeInVertex = IntColumn.findColumn(this, INVERTEX_COLUMN);
        edgeOutVertex = IntColumn.findColumn(this, OUTVERTEX_COLUMN);

        nextEdge = IntColumn.findColumn(this, NEXTEDGE_COLUMN);
        prevEdge = IntColumn.findColumn(this, PREVEDGE_COLUMN);
        outNextEdge = IntColumn.findColumn(this, OUT_NEXTEDGE_COLUMN);
        outPrevEdge = IntColumn.findColumn(this, OUT_PREVEDGE_COLUMN);
        setDirected(true);
        vertexIdManager = new IdManager();
        edgeIdManager = new IdManager();
    }

    /**
     * Constructor for Graph.
     *
     * @param table the underlying <code>Table</code>
     */
    public DefaultGraph(Table table) {
        this(table, null);
    }

    /**
     * Constructor for Graph.
     */
    public DefaultGraph() {
        this(new DefaultTable());
    }

    public void clear() {
        try {
            disableNotify();
            super.clear();
            vertexTable.clear();
            vertexIdManager.clear();
            edgeIdManager.clear();
        }
        finally {
            enableNotify();
        }
    }

    public boolean isDirected() {
        String graphType = (String) getMetadata().get(GRAPH_TYPE);
        if (graphType == null)
            return true;
        return graphType.equals(GRAPH_TYPE_DIRECTED);
    }

    public void setDirected(boolean directed) {
        getMetadata().put(GRAPH_TYPE, GRAPH_TYPE_DIRECTED);
    }

    /**
     * Returns the number of vertices in the graph
     *
     * @return        The number of vertices in the graph.
     */
    public int getVerticesCount() {
        return vertexIdManager.getIdCount();
    }

    /**
     * Adds a new vertex to the graph.
     *
     * @return the vertex number.
     */
    public int addVertex() {
        int v = vertexIdManager.newId();
        try {
            disableNotify();
            vertexFirstEdge.setExtend(v, Graph.NIL);
            vertexLastEdge.setExtend(v, Graph.NIL);
            outVertexFirstEdge.setExtend(v, Graph.NIL);
            outVertexLastEdge.setExtend(v, Graph.NIL);
        }
        finally {
            enableNotify();
        }
        fireGraphChangedListeners(v, GraphChangedEvent.GRAPH_VERTEX_ADDED);
        return v;
    }
    
    public void removeVertex(int vertex) {
        checkVertex(vertex);
        try {
            disableNotify();    // prevent notification before the graph is coherent
            for (int e = getFirstEdge(vertex); e != NIL; e = getNextEdge(e)) {
                removeEdge(e);
            }
            vertexIdManager.free(vertex);
        }
        finally {
            enableNotify();
        }
        fireGraphChangedListeners(vertex, GraphChangedEvent.GRAPH_VERTEX_REMOVED);
    }

    /**
     * Returns the number of edges in the graph.
     *
     * @return the number of edges in the graph.
     */
    public int getEdgesCount() {
        return edgeIdManager.getIdCount();
    }
    
    /**
     * Adds a new edge between two vertices.
     *
     * @param v1 the first vertex.
     * @param v2 the second vertex.
     *
     * @return the new edge index.
     */
    public int addEdge(int v1, int v2) {
        checkVertex(v1);
        checkVertex(v2);
        int edge = edgeIdManager.newId();
        try {            
            disableNotify(); // prevents notification before the graph is coherent
            edgeInVertex.setExtend(edge, v1);
            edgeOutVertex.setExtend(edge, v2);
    
            // insert edge in the edge list associated with v1            
            int last = vertexLastEdge.get(v1);
            vertexLastEdge.set(v1, edge);
            if (last == NIL) {
                vertexFirstEdge.set(v1, edge);
            }
            else {
                nextEdge.setExtend(last, edge);
            }
            nextEdge.setExtend(edge, NIL);
            prevEdge.setExtend(edge, last);
            
            // insert edge in the edge list associated with v2
            last = outVertexLastEdge.get(v2);
            outVertexLastEdge.set(v1, edge);
            if (last == NIL) {
                outVertexFirstEdge.set(v2, edge);
            }
            else {
                outNextEdge.setExtend(edge, last);
            }
            outNextEdge.setExtend(edge, NIL);
            outPrevEdge.setExtend(edge, last);
    
        }
        finally {
            enableNotify();
        }
        fireGraphChangedListeners(edge, GraphChangedEvent.GRAPH_EDGE_ADDED);
        return edge;
    }
    
    protected void quickRemoveEdge(int edge) {
        checkEdge(edge);
        int v1 = getInVertex(edge);
        int v2 = getOutVertex(edge);
        removeEdgeIn(edge, v1, vertexFirstEdge, vertexLastEdge, nextEdge, prevEdge);
        removeEdgeIn(edge, v2, outVertexFirstEdge, outVertexLastEdge, outNextEdge, outPrevEdge);
        fireGraphChangedListeners(edge, GraphChangedEvent.GRAPH_EDGE_REMOVED);
    }
    
    public void removeEdge(int edge) {
        try {
            disableNotify();
            quickRemoveEdge(edge);
        }
        finally {
            enableNotify();
        }
    }
    
    protected void removeEdgeIn(
        int edge,
        int v,
        IntColumn first,
        IntColumn last,
        IntColumn next,
        IntColumn prev) {
        int n = next.get(edge);
        int p = prev.get(edge);
        if (n == NIL) { // last edge
            last.set(v, p);
        }
        else {
            prev.set(n, p);
        }
        if (p == NIL) { // first edge
            last.set(v, n);
        }
        else {
            next.set(p, n);
        }
    }


    /**
     * Returns the "in" vertex of an edge.
     *
     * @param edge the edge.
     *
     * @return the "in" vertex of an edge or NIL.
     */
    public int getInVertex(int edge) {
        return edgeInVertex.get(edge);
    }

    /**
     * Returns the "out" vertex of an edge.
     *
     * @param edge the edge.
     *
     * @return the "out" vertex of an edge.
     */
    public int getOutVertex(int edge) {
        return edgeOutVertex.get(edge);
    }
    
    public int getEdgeAt(int vertex, int index) {
        int e;
        
        for (e = getFirstEdge(vertex); e != NIL && index != 0; e = getNextEdge(e))
            ;
        
        return e;
    }
    
    public int getInEdgeAt(int vertex, int index) {
        int e;
        
        for (e = outVertexFirstEdge.get(vertex);
            e != NIL && index != 0;
            e = outNextEdge.get(e))
            ;
        
        return e;

    }
    
    /**
     * Returns the first edge of a specified vertex.
     *
     * @param vertex the vertex,
     *
     * @return the first edge of the specified vertex or NIL if none exists.
     */
    public int getFirstEdge(int vertex) {
        return vertexFirstEdge.get(vertex);
    }

    /**
     * Returns the last edge of a specified vertex.
     *
     * @param vertex the vertex,
     *
     * @return the last edge of the specified vertex or NIL if none exists.
     */
    public int getLastEdge(int vertex) {
        return vertexLastEdge.get(vertex);
    }

    /**
     * Returns the edge following a specified edge starting at a vertex.
     *
     * @param edge the edge.
     *
     * @return the edge following a given edge starting at the vertex
     *  or NIL if the specified edge is the last of the "in" vertex.
     */
    public int getNextEdge(int edge) {
        return nextEdge.get(edge);
    }

    /**
     * Returns an edge between two specified vertices.
     *
     * @param v1 the first vertex.
     * @param v2 the second vertex.
     *
     * @return an edge between two specified vertices
     *  or NIL if none exists.
     */
    public int getEdge(int v1, int v2) {
        for (int e = getFirstEdge(v1);
            e != Graph.NIL;
            e = getNextEdge(e)) {
            if (getOutVertex(e) == v2) {
                return e;
            }
        }
        return NIL;
    }

    /**
     * Returns an edge between two specified vertices.
     *
     * @param v1 the first vertex.
     * @param v2 the second vertex.
     *
     * @return an edge between two specified vertices
     *  creating one if none exists.
     */
    public int findEdge(int v1, int v2) {
        int e = getEdge(v1, v2);
        if (e == NIL)
            return addEdge(v1, v2);
        return e;
    }

    /**
     * Returns the degree of the vertex, which is simply the number of edges
     * of the vertex.
     *
     * @param vertex the vertex.
     * @return  The degree of the vertex.
     */
    public int getDegree(int vertex) {
        int cnt = 0;
        for (int edge = vertexFirstEdge.get(vertex);
            edge != -1;
            edge = nextEdge.get(edge)) {
            cnt++;
        }
        return cnt;
    }
    
    public int getInDegree(int vertex) {
        int cnt = 0;
        for (int edge = outVertexFirstEdge.get(vertex);
            edge != -1;
            edge = outNextEdge.get(edge)) {
            cnt++;
        }
        return cnt;
    }


    /**
     * Returns an iterator over the edges of a specified vertex.
     *
     * @param vertex the vertex.
     *
     * @return the iterator over the edges of the vertex.
     */
    public RowIterator edgeIterator(int vertex) {
        return new TableIterator(
            vertexFirstEdge.get(vertex),
            getRowCount(),
            true) {
            public int nextRow() {
                int ret = row;
                row = nextEdge.get(row);
                return ret;
            }

            /**
             * @see infovis.Table.Iterator#hasNext()
             */
            public boolean hasNext() {
                return row != NIL;
            }
        };
    }

    public RowIterator inEdgeIterator(int vertex) {
        return new TableIterator(
            outVertexFirstEdge.get(vertex),
            getRowCount(),
            true) {
            public int nextRow() {
                int ret = row;
                row = outNextEdge.get(row);
                return ret;
            }

            /**
             * @see infovis.Table.Iterator#hasNext()
             */
            public boolean hasNext() {
                return row != NIL;
            }
        };
    }

    public RowIterator vertexIterator() {
        return vertexIdManager.iterator();
    }
    
    public RowIterator edgeIterator() {
        return edgeIdManager.iterator();
    }

    /**
     * Returns the edgeTable.
     * @return DefaultTable
     */
    public Table getEdgeTable() {
        return this;
    }

    public Table getVertexTable() {
        return vertexTable;
    }
    
    public void addGraphChangedListener(GraphChangedListener l) {
        getListeners().add(GraphChangedListener.class, l);
    }
    
    public void removeGraphChangedListener(GraphChangedListener l) {
        getListeners().remove(GraphChangedListener.class, l);
    }
    
    protected void fireGraphChangedListeners(GraphChangedEvent e) {
        if (listeners == null) return;
        Object[] ll = listeners.getListeners(GraphChangedListener.class);
        for (int i = 0; i < ll.length; i++) {
            GraphChangedListener l = (GraphChangedListener)ll[i];
            l.graphChanged(e);
        }
    }
    
    protected void fireGraphChangedListeners(int detail, short type) {
        if (listeners == null) return;
        fireGraphChangedListeners(new GraphChangedEvent(this, detail, type));
    }

    protected EventListenerList getListeners() {
        if (listeners == null) {
            listeners = new EventListenerList();
        }
        return listeners;
    }

    protected void checkVertex(int v) {
        if (vertexIdManager.isFree(v)) {
            throw new GraphException("invalid vertex", v, NIL);
        }
    }
    
    protected void checkEdge(int e) {
        if (edgeIdManager.isFree(e)) {
            throw new GraphException("invalid edge", NIL, e);
        }
    }
    
    protected void disableNotify() {
        vertexFirstEdge.disableNotify();
        vertexLastEdge.disableNotify();
        outVertexFirstEdge.disableNotify();
        outVertexLastEdge.disableNotify();
        nextEdge.disableNotify();
        prevEdge.disableNotify();
        outNextEdge.disableNotify();
        outPrevEdge.disableNotify();
        edgeInVertex.disableNotify();
        edgeOutVertex.disableNotify();
    }
    
    protected void enableNotify() {
        vertexFirstEdge.enableNotify();
        vertexLastEdge.enableNotify();
        outVertexFirstEdge.enableNotify();
        outVertexLastEdge.enableNotify();
        nextEdge.enableNotify();
        prevEdge.enableNotify();
        outNextEdge.enableNotify();
        outPrevEdge.enableNotify();
        edgeInVertex.enableNotify();
        edgeOutVertex.enableNotify();
    }

}
