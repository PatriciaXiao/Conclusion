/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.graph;

/**
 * Class GraphException
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class GraphException extends RuntimeException {
    protected int vertex;
    protected int edge;
    public GraphException(String msg, int vertex, int edge) {
        super(msg);
        this.vertex = vertex;
        this.edge = edge;
    }


    public int getEdge() {
        return edge;
    }

    public int getVertex() {
        return vertex;
    }

}
