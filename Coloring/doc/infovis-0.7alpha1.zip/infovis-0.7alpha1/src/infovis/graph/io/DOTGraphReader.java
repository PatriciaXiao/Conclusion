/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.graph.io;

import infovis.Graph;
import infovis.io.WrongFormatException;

import java.awt.geom.Rectangle2D;
import java.io.BufferedReader;
import java.io.IOException;

import antlr.RecognitionException;
import antlr.TokenStreamException;

/**
 * Class DOTGraphReader
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.5 $
 */
public class DOTGraphReader extends AbstractGraphReader {
    protected DOTLexer lexer;
    protected DOTParser parser;

    public DOTGraphReader(
        BufferedReader in,
        String name,
        Graph graph) {
        super(in, name, graph);
    }
    
    public Rectangle2D.Float getBbox() {
        return parser.getBbox();
    }

    public boolean load() throws WrongFormatException {
        lexer = new DOTLexer(in);
        parser = new DOTParser(lexer);
        parser.setGraphReader(this);
        try {
            parser.graph();
        }
        catch (TokenStreamException e) {
            e.printStackTrace();
            return false;
        }
        catch (RecognitionException e) {
            e.printStackTrace();
            return false;
        }
        finally {
            try {
                in.close();
            }
            catch (IOException e) {
            }
        }
        return true;
    }

}
