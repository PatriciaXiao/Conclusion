/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.graph.io;

import java.awt.Shape;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.io.BufferedReader;

import infovis.Graph;
import infovis.column.ObjectColumn;
import infovis.table.io.AbstractTableReader;

/**
 * Base class for Graph readers, except for formats based on XML.
 * 
 * Graph readers hold a graph and can also maintain
 * the shapes of the nodes and the shapes of the links.
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public abstract class AbstractGraphReader extends AbstractTableReader {
    protected Graph graph;
    protected ObjectColumn nodeShapes;
    protected ObjectColumn linkShapes;    
 
     /**
      * Creates an AbstractGraphReader from a BufferedReader, a name and a Graph.
      * 
      * @param in the BufferedReader
      * @param name the file/input name
      * @param graph the Graph
      */   
    public AbstractGraphReader(
        BufferedReader in,
        String name,
        Graph graph) {
        super(in, name, graph.getEdgeTable());
        this.graph = graph;
    }

    /**
     * Returns the Graph
     * @return the Graph
     */    
    public Graph getGraph() {
        return graph;
    }
    
    /**
     * Returns the rectangle containing the layed-out graph
     * @return the rectangle containing the layed-out graph
     *  or null if it is not computed.
     */
    public abstract Rectangle2D.Float getBbox();
    
    public ObjectColumn findNodeShapes() {
        if (nodeShapes == null) {
            nodeShapes = new ObjectColumn("#nodeShapes");
        }
        return nodeShapes;
    }
    
    public ObjectColumn getNodeShapes() {
        return nodeShapes;
    }
    
    public Shape getNodeShape(int node) {
        return (Shape)findNodeShapes().getObjectAt(node); 
    }
    
    public void setNodeShape(int node, Shape s) {
        findNodeShapes().setExtend(node, s);
    }
    
     public Shape findNodeShape(int node) {
        if (findNodeShapes().isValueUndefined(node)) {
            Shape rect = new Rectangle2D.Float();
            setNodeShape(node, rect);
            return rect;            
        }
        return getNodeShape(node);
    }
    
    public ObjectColumn findLinkShapes() {
        if (linkShapes == null) {
            linkShapes = new ObjectColumn("#linkShapes");
        }
        return linkShapes;
    }
    
    public ObjectColumn getLinkShapes() {
        return linkShapes;
    }
    
    public Shape getLinkShape(int edge) {
        return (Shape)findLinkShapes().getObjectAt(edge);
    }
    
    public void setLinkShape(int edge, Shape s) {
        findLinkShapes().setExtend(edge, s);
    }
    
    public Shape findLinkShape(int edge) {
        if (findLinkShapes().isValueUndefined(edge)) {
            GeneralPath p = new GeneralPath();
            setLinkShape(edge, p);
            return p;
        }
        return getLinkShape(edge);
    }
}
