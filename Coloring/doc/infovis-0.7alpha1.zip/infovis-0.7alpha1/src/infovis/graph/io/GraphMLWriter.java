/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/

package infovis.graph.io;

import infovis.*;
import infovis.io.AbstractXMLWriter;
import infovis.utils.RowIterator;

import java.io.Writer;
import java.util.ArrayList;

import org.xml.sax.SAXException;
import org.xml.sax.helpers.AttributesImpl;

/**
 * Writer for the GraphML format.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.14 $
 */
public class GraphMLWriter extends AbstractXMLWriter {
    protected Graph graph;
    /** DefaultTable of edge labels */
    protected ArrayList edgeLabels;
    protected AttributesImpl attrs = new AttributesImpl();
    protected boolean interlaced;
	
    public GraphMLWriter(Writer out, Graph graph) {
	super(out, graph.getEdgeTable());
	this.graph = graph;
    }

    public void addEdgeLabel(String name) {
	if (edgeLabels == null) {
	    edgeLabels = new ArrayList();
	}

	edgeLabels.add(name);
    }
	
    public void addAllEdgeLabels() {
	int col;
	Table edges = graph.getEdgeTable();
		
	for (col = 0; col < edges.getColumnCount(); col++) {
	    Column c = edges.getColumnAt(col);

	    if (c.isInternal() || namedType(c.getValueClass()) == null) {
		continue;
	    }

	    addEdgeLabel(c.getName());
	}
    }
    
    public void addAllColumnLabels() {
       int col;
       Table vertices = graph.getVertexTable();
        
       for (col = 0; col < vertices.getColumnCount(); col++) {
           Column c = vertices.getColumnAt(col);

           if (c.isInternal() || namedType(c.getValueClass()) == null) {
           continue;
           }

           addColumnLabel(c.getName());
       }
    }
	
    public String getEdgeLabelAt(int col) {
	return (String)edgeLabels.get(col);
    }
	
    public ArrayList getEdgeLabels() {
	return edgeLabels;
    }
	
    /**
     * Writes the data associated with a specified edge.
     *
     * @param edge the edge.
     *
     * @exception SAXException passed from the underlying XMLWriter.
     */
    protected void writeEdge(int edge) throws SAXException {
	Table edgeTable = graph.getEdgeTable();
		
	indent(writer);
	attrs.clear();
	attrs.addAttribute("", "id", "id", "ID", "e"+edge);
	attrs.addAttribute("", "source", "source",
			   "IDREF", "n"+graph.getInVertex(edge));
	attrs.addAttribute("", "target", "tager",
			   "IDREF", "n"+graph.getOutVertex(edge));
	writer.startElement("", "edge", "", attrs);
	depth++;
	for (int col = 0; edgeLabels != null && col < edgeLabels.size(); col++) {
	    String label = getEdgeLabelAt(col);
	    Column c = edgeTable.getColumn(label);
			
	    if (! c.isValueUndefined(edge)) {
		indent(writer);
		attrs.clear();
		attrs.addAttribute("", "key", "key", "IDREF", c.getName());
		writer.startElement("", "data", "", attrs);
		writer.characters(c.getValueAt(edge));
		writer.endElement("data");
	    }
	}
		
	depth--;
	indent(writer);
	writer.endElement("edge");	
    }

    /**
     * Writes the data associated with a specified vertex.
     *
     * @param vertex the vertex.
     *
     * @exception SAXException passed from the underlying XMLWriter.
     */
    protected void writeVertex(int vertex) throws SAXException {
	ArrayList columnLabels = getColumnLabels();
	indent(writer);
	attrs.clear();
	attrs.addAttribute("", "id", "id", "ID", "n"+vertex);
	writer.startElement("", "node", "", attrs);
	depth++;
	for (int col = 0; columnLabels != null && col < columnLabels.size(); col++) {
	    String label = getColumnLabelAt(col);
	    Column c = graph.getVertexTable().getColumn(label);
			
	    if (! c.isValueUndefined(vertex)) {
		indent(writer);
		attrs.clear();
		attrs.addAttribute("", "key", "key", "IDREF", c.getName());
		writer.startElement("", "data", "", attrs);
		writer.characters(c.getValueAt(vertex));
		writer.endElement("data");
	    }
	}		
	depth--;
	indent(writer);
	writer.endElement("node");	
	if (interlaced) {
	    for (RowIterator iter = graph.edgeIterator(vertex); iter.hasNext(); ) {
                int edge = iter.nextRow();
		writeEdge(edge);
	    }
	}
    }
	
    /**
     * @see infovis.io.AbstractWriter#write()
     */
    public boolean write() {
	ArrayList columnLabels = getColumnLabels();
	ArrayList edgeLabels = getEdgeLabels();

	int col;
		
	if (columnLabels == null) {
	    addAllColumnLabels();
	    columnLabels = getColumnLabels();
	}
		
	if (edgeLabels == null) {
	    addAllEdgeLabels();
	    edgeLabels = getEdgeLabels();
	}
	depth = 0;
	try {
	    writer.startDocument();
	    writer.flush();
	    out.write("<!DOCTYPE graphml SYSTEM 'http://graphml.graphdrawing.org/dtds/1.0rc/graphml.dtd'>\n");
	    writer.startElement("graphml");
	    depth++;
	    indent(writer);
	    attrs.addAttribute("", "edgedefault", "edgedefault", "CDATA", "directed");
	    writer.startElement("", "graph", "", attrs);
	    attrs.clear();
	    depth++;
	    attrs.addAttribute("", "id", "id", "ID", "0");
	    attrs.addAttribute("", "for", "for", "CDATA", "node");
		
	    for (col = 0; columnLabels != null && col < columnLabels.size(); col++) {
		String label = getColumnLabelAt(col);
		Column c = graph.getVertexTable().getColumn(label);
			
		indent(writer);
		attrs.setAttribute(0, "", "id", "id", "ID", c.getName());
		writer.startElement("", "key", "", attrs);
		writer.characters(namedType(c.getValueClass()));
		writer.endElement("key");
	    }
		
	    attrs.setAttribute(1, "", "for", "for", "CDATA", "edge");
	    Table edgeTable = graph.getEdgeTable();
	    for (col = 0; edgeLabels != null && col < edgeLabels.size(); col++) {
		String label = getEdgeLabelAt(col);
		Column c = edgeTable.getColumn(label);
			
		indent(writer);
		//attNameFor[0] = "id";	
		//attName[1] = c.getName();
		attrs.setAttribute(0, "", "id", "id", "ID", c.getName());
		writer.startElement("", "key", "", attrs);
		writer.characters(namedType(c.getValueClass()));
		writer.endElement("key");
	    }
		
	    for (int vertex = 0; vertex < graph.getVerticesCount(); vertex++) {
		writeVertex(vertex);
	    }
		
	    if (! interlaced) {
		for (int edge = 0; edge < graph.getEdgesCount(); edge++) {
		    writeEdge(edge);
		}
	    }
		
	    depth--;
	    indent(writer);
	    writer.endElement("graph");
	    depth--;
	    indent(writer);
	    writer.endElement("graphml");
	    writer.endDocument();
	}
	catch(Exception e) {
	    e.printStackTrace();
	    return false;
	}
	return true;
    }

    /**
     * Returns the interlaced.
     * @return boolean
     */
    public boolean isInterlaced() {
	return interlaced;
    }

    /**
     * Sets the interlaced.
     * @param interlaced The interlaced to set
     */
    public void setInterlaced(boolean interlaced) {
	this.interlaced = interlaced;
    }

}
