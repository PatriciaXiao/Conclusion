/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.graph.visualization;

import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.JComboBox;
import javax.swing.event.ListDataEvent;

import infovis.*;
import infovis.column.ColumnFilter;
import infovis.panel.DefaultVisualPanel;

/**
 * Class NodeLinkGraphVisualPanel
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.8 $
 */
public class NodeLinkGraphVisualPanel extends DefaultVisualPanel {
    protected JComboBox layoutProgramCombo;
    protected JComboBox layoutRatioCombo;
    protected JCheckBox paintLinksButton;
    //protected ColorPanel edgeColorPanel;
    
    public NodeLinkGraphVisualPanel(Visualization visualization, ColumnFilter filter) {
        super(visualization, filter);
    }
    
    public NodeLinkGraphVisualization getNodeLinkGraphVisualization() {
        return (NodeLinkGraphVisualization)getVisualization()
            .findVisualization(NodeLinkGraphVisualization.class);
    }
    
    protected void createAll() {
        super.createAll();
        addOrientationButtons();
        //addEdgeAttributes();
        addVisibilityButtons();
        addLayoutControls();
    }
    
    public Object[] getLayoutPrograms() {
        Object[] programs = {
            "dot",
            "dot:neato",
            "dot:twopi",
            "vcg"
        };
        return programs;
    }
//    
//    protected void addEdgeAttributes() {
//        edgeColorPanel = new ColorPanel(
//            getVisualization(),
//            NodeLinkGraphVisualization.VISUAL_EDGE_COLOR, "Color edge by");
//        add(edgeColorPanel);
//    }
    
    protected void addVisibilityButtons() {
        paintLinksButton = new JCheckBox("Paint Links");
        paintLinksButton.setSelected(
            getNodeLinkGraphVisualization().isPaintingLinks());
        paintLinksButton.addActionListener(this);
        add(paintLinksButton);
    }
    
    protected void addLayoutControls() {
        layoutProgramCombo = new JComboBox(getLayoutPrograms());
        layoutProgramCombo.setEditable(true);
        layoutProgramCombo.setSelectedItem(
            getNodeLinkGraphVisualization().getLayoutProgram());
        addJCombo("Layout program", layoutProgramCombo);
        Object[] ratios = {
            null,
            "fill",
            "compress",
            "auto"
        };
        layoutRatioCombo = new JComboBox(ratios);
        layoutRatioCombo.setEditable(true);
        layoutRatioCombo.setSelectedItem(
            getNodeLinkGraphVisualization().getLayoutRatio());
        addJCombo("Ratio options", layoutRatioCombo);
    }
    
    public void contentsChanged(ListDataEvent e) {
    	if (e.getSource() == layoutProgramCombo.getModel()) {
            getNodeLinkGraphVisualization().setLayoutProgram(
                (String)layoutProgramCombo.getSelectedItem());
        }
        else if (e.getSource() == layoutRatioCombo.getModel()) {
            getNodeLinkGraphVisualization().setLayoutRatio(
                (String)layoutRatioCombo.getSelectedItem());
        }
        else
            super.contentsChanged(e);
    }
    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == paintLinksButton) {
            getNodeLinkGraphVisualization().setPaintingLinks(
                paintLinksButton.isSelected());
            getVisualization().repaint();
        }
        else
            super.actionPerformed(e);
    }
    
}
