/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.graph.visualization;

import infovis.*;
import infovis.Column;
import infovis.column.ColumnFilter;
import infovis.panel.FilteredColumnListModel;
import infovis.panel.DefaultVisualPanel;

import javax.swing.JComboBox;
import javax.swing.event.ListDataEvent;

/**
 * Panel for Visual Controls on Treemaps.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.9 $
 */
public class MatrixVisualPanel extends DefaultVisualPanel {
    protected FilteredColumnListModel vertexLabelModel;
    protected JComboBox               vertexLabelCombo;
    protected FilteredColumnListModel sortRowModel;
    protected JComboBox               sortRowCombo;
    protected FilteredColumnListModel sortColumnModel;
    protected JComboBox               sortColumnCombo;

    public MatrixVisualization getMatrix() {
        return (MatrixVisualization)getVisualization()
            .findVisualization(MatrixVisualization.class);
    }

    /**
     * Constructor for MatrixVisualPanel.
     * @param visualization
     */
    public MatrixVisualPanel(MatrixVisualization visualization, ColumnFilter filter) {
        super(visualization, filter);
    }
    
    /**
     * @see infovis.panel.DefaultVisualPanel#createAll(Visualization)
     */
    protected void createAll() {
        addColor(getVisualization());
        addLabel(getVisualization());
        addVertexLabel(getVisualization());
        addSortRow(getVisualization());
        addSortColumn(getVisualization());
    }
    
    /**
     * Adds a JComboBox to change the column used for labeling vertices.
     *
     * param visualization the Visualization.
     */
    protected void addVertexLabel(Visualization visualization) {        
        MatrixVisualization matrix = getMatrix();
        vertexLabelModel = new FilteredColumnListModel(matrix.getGraph().getVertexTable(), filter);
        vertexLabelCombo = createJCombo(vertexLabelModel, matrix.getVertexLabelColumn(),
                                  "Label Vertex by");
        
    }

    /**
     * Adds a JComboBox to change the column used for sorting rows.
     *
     * param visualization the Visualization.
     */
    protected void addSortRow(Visualization visualization) {       
        MatrixVisualization matrix = getMatrix();
        sortRowModel = new FilteredColumnListModel(matrix.getGraph().getVertexTable(), filter);
        sortRowCombo = createJCombo(sortRowModel, null, "Sort Row by");
    }
    
    /**
     * Adds a JComboBox to change the column used for sorting columns.
     *
     * param visualization the Visualization.
     */
    protected void addSortColumn(Visualization visualization) {       
        MatrixVisualization matrix = getMatrix();
        sortColumnModel = new FilteredColumnListModel(matrix.getGraph().getVertexTable(), filter);
        sortColumnCombo = createJCombo(sortColumnModel, null, "Sort Column by");
    }
    
    /**
     * @see infovis.panel.DefaultVisualPanel#contentsChanged(ListDataEvent)
     */
    public void contentsChanged(ListDataEvent e) {
        if (e.getSource() == null)
            return;
        if (e.getSource() == vertexLabelModel) {
            Column col = (Column)vertexLabelCombo.getSelectedItem();
            getMatrix().setVertexLabelColumn(col);
        }
        else if (e.getSource() == sortRowModel) {
            Column col = (Column)sortRowCombo.getSelectedItem();
            getMatrix().setRowSortColumn(col);
        }
        else if (e.getSource() == sortColumnModel) {
            Column col = (Column)sortColumnCombo.getSelectedItem();
            getMatrix().setColumnSortColumn(col);
        }
        else
            super.contentsChanged(e);
    }

}
