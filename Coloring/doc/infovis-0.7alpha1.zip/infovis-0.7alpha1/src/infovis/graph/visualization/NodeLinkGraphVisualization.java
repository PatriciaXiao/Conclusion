/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.graph.visualization;

import infovis.Graph;
import infovis.Visualization;
import infovis.column.ObjectColumn;
import infovis.graph.io.*;
import infovis.io.AbstractReaderFactory;
import infovis.io.AbstractWriterFactory;
import infovis.panel.ControlPanelFactory;
import infovis.utils.RowIterator;
import infovis.visualization.*;

import java.awt.*;
import java.awt.geom.*;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;

import javax.swing.JComponent;

/**
 * Class NodeLinkGraphVisualization
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.14 $
 */
public class NodeLinkGraphVisualization extends GraphVisualization
    implements NodeAccessor, LinkShaper {
    static HashMap programLine = new HashMap();

    protected String layoutProgram = "dot:twopi";
    protected String layoutRatio = null;
    protected boolean paintingLinks = true;
    protected boolean debugging = true;
    protected transient Rectangle2D.Float bbox;
    protected transient float scale;
    protected ObjectColumn linkShapes;
    protected LinkVisualization linkVisualization;

    static {
        ControlPanelFactory.getInstance().setDefault(
            NodeLinkGraphVisualization.class,
            NodeLinkGraphControlPanel.class);
        programLine.put("dot", "dot");
        programLine.put("neato", "neato");
        programLine.put("twopi", "twopi");
        programLine.put("vcg", "vcg -silent -vcgoutput - -");
    }

    public NodeLinkGraphVisualization(Graph graph) {
        super(graph, graph.getVertexTable());
        linkShapes = new ObjectColumn("#linkShapes");
        linkVisualization = new LinkVisualization(graph.getEdgeTable(), this, this);
        linkVisualization.setOrientation(ORIENTATION_INVALID);
        linkVisualization.setLinkShaper(this);
    }
    
    // NodeAccessor interface    
    public int getStartNode(int link) {
        return getGraph().getInVertex(link);
    }

    public int getEndNode(int link) {
        return getGraph().getOutVertex(link);
    }
    
    // LinkShaped interface
    public Shape computeLinkShape(
        int link,
        NodeAccessor accessor,
        Shape s) {
        return (Shape)linkShapes.get(link);
    }

    
    public void paintItems(Graphics2D graphics, Rectangle2D bounds) {
        if (isPaintingLinks())
            linkVisualization.paint(graphics, bounds);
        super.paintItems(graphics, bounds);
    }
    
    public void setParent(JComponent parent) {
        super.setParent(parent);
        linkVisualization.setParent(parent);
    }

    public void dispose() {
        super.dispose();
        linkVisualization.dispose();
    }

    public void setFisheyes(Fisheyes fisheyes) {
        super.setFisheyes(fisheyes);
        linkVisualization.setFisheyes(fisheyes);
    }
    
    public Visualization getVisualization(int index) {
        if (index == 0)
            return linkVisualization;
        return null;
    }

    public void computeShapes(Rectangle2D bounds) {
        recomputeSizes();
        bbox = callLayoutProgram();
        if (bbox == null)
            return;
        computeScale(bounds);
        AffineTransform a = new AffineTransform();
        a.translate(-bbox.x, -bbox.y);
        a.scale(scale, scale);
        //        vertexPosition = StringColumn.findColumn(getVertexTable(), DOTGraphReader.DOT_POS_COLUMN);
        //        vertexWidth = FloatColumn.findColumn(getVertexTable(), DOTGraphReader.DOT_WIDTH_COLUMN);
        //        vertexHeight = FloatColumn.findColumn(getVertexTable(), DOTGraphReader.DOT_HEIGHT_COLUMN);
        //        edgePosition = StringColumn.findColumn(getEdgeTable(), DOTGraphReader.DOT_POS_COLUMN);
        for (RowIterator iter = getVertexTable().iterator();
            iter.hasNext();
            ) {
            int v = iter.nextRow();
            rescaleVertex(v);
            for (RowIterator eiter = edgeIterator(v);
                eiter.hasNext();
                ) {
                int e = eiter.nextRow();
                rescaleEdge(e, a);
            }
        }
        bbox = null;
    }

    public String getLayoutProgram() {
        return layoutProgram;
    }

    public void setLayoutProgram(String program) {
        if (!layoutProgram.equals(program)) {
            layoutProgram = program;
            invalidate();
        }
    }

    public String getLayoutRatio() {
        return layoutRatio;
    }

    public void setLayoutRatio(String string) {
        if (layoutRatio != string
            && (layoutRatio == null || !layoutRatio.equals(string))) {
            layoutRatio = string;
            invalidate();
        }
    }

    public boolean isPaintingLinks() {
        return paintingLinks;
    }

    public void setPaintingLinks(boolean b) {
        if (paintingLinks != b) {
            paintingLinks = b;
            repaint();
        }
    }

    protected void computeScale(Rectangle2D bounds) {
        double sx = bounds.getWidth() / bbox.getWidth();
        double sy = bounds.getHeight() / bbox.getHeight();

        scale = (float) Math.min(sx, sy);
    }

    protected float transformX(float x) {
        return (x - bbox.x) * scale;
    }

    protected float transformY(float y) {
        return (y - bbox.y) * scale;
    }

    protected void recomputeSizes() {
        for (RowIterator iter = iterator(); iter.hasNext();) {
            int v = iter.nextRow();

            Rectangle2D.Float rect = (Rectangle2D.Float) getShapeAt(v);
            if (rect == null) {
                rect = new Rectangle2D.Float();
                setShapeAt(v, rect);
            }
            double s = getSizeAt(v);
            rect.width = (float) s;
            rect.height = (float) s;
        }
    }

    protected Rectangle2D.Float callLayoutProgram() {
        OutputStream out = null;
        InputStream in = null;
        String format;
        String program;
        int cindex = layoutProgram.indexOf(':');
        if (cindex == -1) {
            format = layoutProgram;
            program = layoutProgram;
        }
        else {
            format = layoutProgram.substring(0, cindex);
            program = layoutProgram.substring(cindex + 1);
        }
        
        StringWriter wout = new StringWriter();
        AbstractWriterFactory.Creator c = GraphWriterFactory.sharedInstance().getCreatorNamed(format);
        if (c == null)
            return null;
        
        AbstractReaderFactory.Creator rc = GraphReaderFactory.getInstance().getCreatorNamed(format);
        if (rc == null)
            return null;
            
        DOTGraphWriter writer =
            (DOTGraphWriter)c.create(wout, graph);
        if (writer == null) {
            System.err.println("Cannot create a graph writer for foramt "+format);
            return null;
        }

        String cmdLine = program;
        if (programLine.containsKey(program)) {
            cmdLine = (String)programLine.get(program);
        }
        else {
            System.err.println("Unspecified command line for program "+program);             
        }
        try {
            Process proc = Runtime.getRuntime().exec(cmdLine);
            out = proc.getOutputStream();
            in = proc.getInputStream();
        }
        catch (Exception ex) {
            System.err.println(
                "Exception while setting up Process: "
                    + ex.getMessage()
                    + "\nTrying URLConnection...");
            out = null;
            in = null;
        }

        if (out == null && format.equals("dot")) {
            try {
                URLConnection urlConn =
                    (
                        new URL("http://www.research.att.com/~john/cgi-bin/format-graph"))
                        .openConnection();

                urlConn.setDoInput(true);
                urlConn.setDoOutput(true);
                urlConn.setUseCaches(false);
                urlConn.setRequestProperty(
                    "Content-Type",
                    "application/x-www-form-urlencoded");
                out = urlConn.getOutputStream();
                in = urlConn.getInputStream();
            }
            catch (Exception ex) {
                System.err.println(
                    "Exception while setting up URLConnection: "
                        + ex.getMessage()
                        + "\nLayout not performed.");
                out = null;
                in = null;
            }
        }

        if (out == null || in == null)
            return null;
        Cursor saved = getParent().getCursor();
        getParent().setCursor(
            Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        try {
            
            writer.setShapes(getShapes());
            writer.setSize(
                new Dimension(
                    (int) getBounds().getWidth(),
                    (int) getBounds().getHeight()));
            writer.setOrientation(getOrientation());
            writer.setLayoutRatio(layoutRatio);
            if (!writer.write())
                return null;
            wout.flush();
            String content = wout.toString();
            wout.close();
            wout = null;
            writer = null;
            BufferedWriter bout;
            
            if (debugging) {
                bout = new BufferedWriter(new FileWriter("debug.out"));
                bout.write(content);
                bout.flush();
                bout.close();
                bout = null;
            }

            bout = new BufferedWriter(new OutputStreamWriter(out));
            bout.write(content);
            bout.flush();
            bout.close();
            bout = null;

            BufferedReader bin =
                new BufferedReader(new InputStreamReader(in));
            
            AbstractGraphReader reader = (AbstractGraphReader)rc.create(bin, getName(), this);
            //    new DOTGraphReader(bin, layoutProgram, this);
            if (reader == null || !reader.load())
                return null;
            ObjectColumn shapes;
            shapes = reader.getNodeShapes();
            if (shapes != null) {
                // No reason to disable the notifications on shapes since
                // the method should be called from updateShapes
                for (int i = 0; i < shapes.getRowCount(); i++) {
                    setShapeAt(i, (Shape) shapes.get(i));
                }
            }
            shapes = reader.getLinkShapes();
            if (shapes != null) {
                linkShapes.clear();
                for (int i = 0; i < shapes.getRowCount(); i++) {
                    linkShapes.setExtend(i, (Shape) shapes.get(i));
                }
            }
            return reader.getBbox();
        }
        catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        finally {
            getParent().setCursor(saved);
        }
    }

    protected void rescaleVertex(int v) {
        Rectangle2D.Float rect = (Rectangle2D.Float) getShapeAt(v);
        if (rect == null) {
            return;
        }
        rect.width *= scale;
        rect.height *= scale;
        rect.x = transformX(rect.x);
        rect.y = transformY(rect.y);
    }

    protected void rescaleEdge(int e, AffineTransform a) {
        if (linkShapes.isValueUndefined(e))
            return;
        GeneralPath p = (GeneralPath) linkShapes.get(e);
        p.transform(a);
    }
}
