/**
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France
 * -------------------------------------------------------------------------
 * This software is published under the terms of the QPL Software License a
 * copy of which has been included with this distribution in the
 * license-infovis.txt file.
 */
package infovis.graph.visualization;

import infovis.Column;
import infovis.Graph;
import infovis.column.*;
import infovis.column.filter.NotTypedFilter;
import infovis.graph.InDegree;
import infovis.graph.OutDegree;
import infovis.panel.ControlPanelFactory;
import infovis.utils.*;
import infovis.visualization.DefaultVisualColumn;

import java.awt.geom.Rectangle2D;

import javax.swing.event.ChangeEvent;


/**
 * Graph Visualization using Adjacency Matrix representation.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.30 $
 */
public class MatrixVisualization extends GraphVisualization {
    public static final String VISUAL_VERTEX_LABEL = "vertexLabel";
    public static final String VISUAL_ROW_SELECTION = "rowSelection";
    public static final String VISUAL_ROW_SORT = "rowSort";
    public static final String VISUAL_ROW_FILTER = "rowFilter";
    public static final String VISUAL_COLUMN_SELECTION = "columnSelection";
    public static final String VISUAL_COLUMN_FILTER = "columnFilter";
    public static final String VISUAL_COLUMN_SORT = "columnSort";
    /** Name of the column containing the rowSelection */
    public static final String ROWSELECTION_COLUMN = SELECTION_COLUMN; //"#rowSelection";
    /** Name of the column containing the columnSelection */
    public static final String COLUMNSELECTION_COLUMN = "#columnSelection";
    /** Name of the column containing the rowFilter */
    public static final String ROWFILTER_COLUMN = FILTER_COLUMN;
    /** Name of the column containing the columnFilter */
    public static final String COLUMNFILTER_COLUMN = "#columnFilter";
    /** Name of the IntColumn containing the rowPermutation */
    public static final String ROWPERMUTATION_COLUMN = PERMUTATION_COLUMN;
    /** Name of the optional IntColumn managing the inverse permutation. */
    public static final String INVERSEROWPERMUTATION_COLUMN = INVERSEPERMUTATION_COLUMN;
    /** Name of the IntColumn containing the columnPermutation */
    public static final String COLUMNPERMUTATION_COLUMN = "#columnPermutation";
    /** Name of the optional IntColumn managing the inverse permutation. */
    public static final String INVERSECOLUMNPERMUTATION_COLUMN = "#inverseColumnPermutation";
    protected int              leftMargin = 30;
    protected int              topMargin = 30;
    protected Column           vertexLabelColumn;
    protected BooleanColumn    rowSelection;
    protected FilterColumn     rowFilter;
    protected Column           rowSortColumn;
    protected Permutation      rowPermutation;
    protected RowComparator    rowComparator;
    protected IntVector        rowPosition;
    protected boolean          filteredRowVisible = true;
    protected BooleanColumn    columnSelection;
    protected FilterColumn     columnFilter;
    protected Column           columnSortColumn;
    protected Permutation      columnPermutation;
    protected RowComparator    columnComparator;
    protected IntVector        columnPosition;
    protected boolean          filteredColumnVisible = true;
    protected boolean         squared;
    
    static {
        ControlPanelFactory.getInstance().setDefault(
            MatrixVisualization.class, MatrixControlPanel.class);
    }

    /**
     * Constructor for MatrixVisualization.
     *
     * @param graph the graph.
     */
    public MatrixVisualization(Graph graph) {
        super(graph);
        setRowSelection(BooleanColumn.findColumn(graph.getVertexTable(),
            ROWSELECTION_COLUMN));
        setColumnSelection(BooleanColumn.findColumn(graph.getVertexTable(),
                                                    COLUMNSELECTION_COLUMN));
        setRowFilter(FilterColumn.findColumn(graph.getVertexTable(),
            ROWFILTER_COLUMN));
        setColumnFilter(FilterColumn.findColumn(graph.getVertexTable(),
            COLUMNFILTER_COLUMN));
        OutDegree.getColumn(graph); // create a maintained outDegree column.
        InDegree.getColumn(graph);
    }
    
    /**
     * @see infovis.Visualization#declareVisualColumns()
     */
    protected void declareVisualColumns() {
        super.declareVisualColumns();
        putVisualColumn(VISUAL_VERTEX_LABEL,
            new DefaultVisualColumn(false) {
                public void setColumn(Column column) {
                    super.setColumn(column);
                    vertexLabelColumn = column;
                }
        });
        putVisualColumn(VISUAL_ROW_SELECTION, 
            new DefaultVisualColumn(false, new NotTypedFilter(BooleanColumn.class)) {
                public void setColumn(Column column) {
                    super.setColumn(column);
                    rowSelection = (BooleanColumn)column;
                }
        });
        putVisualColumn(VISUAL_ROW_SORT, 
            new DefaultVisualColumn(true) {
                public void setColumn(Column column) {
                    assert (column== null || graph.getVertexTable().indexOf(column) != -1);
                    super.setColumn(column);
                    rowSortColumn = column;
                    rowComparator = column;
                    permuteRowRows();
                }
        });
        putVisualColumn(VISUAL_ROW_FILTER, 
            new DefaultVisualColumn(false, new NotTypedFilter(FilterColumn.class)) {
                public void setColumn(Column column) {
                    super.setColumn(column);
                    rowFilter = (FilterColumn)column;
                }
        });
        putVisualColumn(VISUAL_COLUMN_SELECTION,
            new DefaultVisualColumn(false, new NotTypedFilter(BooleanColumn.class)) {
                public void setColumn(Column column) {
                    super.setColumn(column);
                    columnSelection = (BooleanColumn)column;
                }
        });
        putVisualColumn(VISUAL_COLUMN_SORT,
            new DefaultVisualColumn(true) {
                public void setColumn(Column column) {
                    assert (column== null || graph.getEdgeTable().indexOf(column) != -1);
                    super.setColumn(column);
                    columnSortColumn = column;
                    columnComparator = column;
                    permuteColumnColumns();
                }
        });
        putVisualColumn(VISUAL_COLUMN_FILTER,
            new DefaultVisualColumn(false, new NotTypedFilter(FilterColumn.class)) {
                public void setColumn(Column column) {
                    super.setColumn(column);
                    columnFilter = (FilterColumn)column;
                }
        });
    }

    /**
     * Returns the leftMargin.
     *
     * @return int
     */
    public int getLeftMargin() {
        return leftMargin;
    }

    /**
     * Sets the leftMargin.
     *
     * @param leftMargin The leftMargin to set
     */
    public void setLeftMargin(int leftMargin) {
        this.leftMargin = leftMargin;
    }

    /**
     * Returns the topMargin.
     *
     * @return int
     */
    public int getTopMargin() {
        return topMargin;
    }

    /**
     * Sets the topMargin.
     *
     * @param topMargin The topMargin to set
     */
    public void setTopMargin(int topMargin) {
        this.topMargin = topMargin;
    }

    /**
     * @see infovis.Visualization#computeShapes(Rectangle2D)
     */
    public void computeShapes(Rectangle2D bounds) {
        if (getColumnPositionCount() == 0 || getRowPositionCount() == 0)
            return;
        double w = (bounds.getWidth() - leftMargin) / getColumnPositionCount();
        double h = (bounds.getHeight() - topMargin) / getRowPositionCount();

        if (squared) {
            if (w < h) {
                h = w;
            } else {
                w = h;
            }
        }
        for (RowIterator iter = iterator(); iter.hasNext();) {
            int edge = iter.nextRow();

            int v1 = graph.getInVertex(edge);
            int row = getRowPosition(v1);
            if (row == -1) {
                setShapeAt(edge, null);
                continue;
            }

            int v2 = graph.getOutVertex(edge);
            int col = getColumnPosition(v2);
            if (col == -1) {
                setShapeAt(edge, null);
                continue;
            }

            Rectangle2D.Double s = (Rectangle2D.Double)getShapeAt(edge);
            if (s == null) {
                s = new Rectangle2D.Double(w * col + leftMargin,
                                           h * row + topMargin, w, h);
                setShapeAt(edge, s);
            } else {
                s.setRect(w * col + leftMargin, h * row + topMargin, w, h);
            }
        }
    }
    
    /**
     * @see infovis.Visualization#isFiltered(int)
     */
    public boolean isFiltered(int edge) {
        if (super.isFiltered(edge))
            return true;
        int row = graph.getInVertex(edge);
        if (isRowFiltered(row))
            return true;
        int col = graph.getOutVertex(edge);
        return isColumnFiltered(col);
    }


    public String getLabelAt(int edge) {
        if (labelColumn == null) {
            if (vertexLabelColumn == null)
                return null;
            int inVertex = graph.getInVertex(edge);
            int outVertex = graph.getOutVertex(edge);
            return vertexLabelColumn.getValueAt(inVertex) + "--" +
                   vertexLabelColumn.getValueAt(outVertex);
        }
        return labelColumn.getValueAt(edge);
    }

    /**
     * Returns the vertexLabelColumn.
     *
     * @return Column
     */
    public Column getVertexLabelColumn() {
        return vertexLabelColumn;
    }

    /**
     * Sets the vertexLabelColumn.
     *
     * @param vertexLabelColumn The vertexLabelColumn to set.
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setVertexLabelColumn(Column vertexLabelColumn) {
        return changeManagedColumn(VISUAL_VERTEX_LABEL, this.vertexLabelColumn, vertexLabelColumn);
    }

    // Row permutation management
    /**
     * Returns the rowSelection.
     *
     * @return BooleanColumn
     */
    public BooleanColumn getRowSelection() {
        return rowSelection;
    }

    /**
     * Sets the rowSelection.
     *
     * @param rowSelection The rowSelection to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setRowSelection(BooleanColumn rowSelection) {
        return changeManagedColumn(VISUAL_ROW_SELECTION, this.rowSelection, rowSelection);
    }

    /**
     * Returns the rowFilter.
     *
     * @return FilterColumn
     */
    public FilterColumn getRowFilter() {
        return rowFilter;
    }

    /**
     * Sets the rowFilter.
     *
     * @param rowFilter The rowFilter to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setRowFilter(FilterColumn rowFilter) {
        return changeManagedColumn(VISUAL_ROW_FILTER, this.rowFilter, rowFilter);
    }

    /**
     * Returns <code>true</code> if the specified row is filtered.
     *
     * @param row the row.
     *
     * @return <code>true</code> if the row is filtered.
     */
    public boolean isRowFiltered(int row) {
        return rowFilter != null && rowFilter.isFiltered(row);
    }
    
    public RowIterator vertexIterator() {
        return graph.vertexIterator();
    }


    /**
     * Returns the sortColumn.
     *
     * @return Column
     */
    public Column getRowSortColumn() {
        return rowSortColumn;
    }

    /**
     * Sets the sortColumn.
     *
     * @param rowSortColumn The sortColumn to set.
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setRowSortColumn(Column rowSortColumn) {
        return changeManagedColumn(VISUAL_ROW_SORT, this.rowSortColumn, rowSortColumn);
    }

    /**
     * Compute the rowPermutation according to the current comparator.
     */
    protected void permuteRowRows() {
        RowComparator comp = rowComparator;
        if (comp == null) {
            rowPermutation = null;
            rowPosition = null;
            return;
        }
        if (rowPermutation == null) {
            rowPermutation = new Permutation(IntColumn.findColumn(graph.getVertexTable(),
                                                                  ROWPERMUTATION_COLUMN),
                                             IntColumn.findColumn(graph.getVertexTable(),
                                                                  INVERSEROWPERMUTATION_COLUMN),
                                             graph.getVertexTable().getRowCount());
        }
        rowPermutation.sort(graph.getVertexTable().getRowCount(), comp);
        hideFilteredRowPositions();
    }

    /**
     * Returns the row permutation.
     *
     * @return the row permutation.
     */
    public Permutation getRowPermutation() {
        return rowPermutation;
    }

    /**
     * Returns the current comparator.
     *
     * @return the current comparator.
     */
    public RowComparator getRowComparator() {
        return rowComparator;
    }

    /**
     * Sets the row comparator.
     *
     * @param rowComparator The row comparator to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setRowComparator(RowComparator rowComparator) {
        if (this.rowComparator != rowComparator) {
            setRowSortColumn(null);
            this.rowComparator = rowComparator;
            permuteRowRows();
            invalidate();
            return true;
        }
        return false;
    }

    /**
     * Returns an iterator over the permuted rows.
     *
     * @return an iterator over the permuted rows.
     */
    public RowIterator rowIterator() {
        if (rowPermutation != null)
            return new PermutedIterator(0, rowPermutation);
        else
            return new TableIterator(0, graph.getVertexTable().getRowCount(), true);
    }

    /**
     * Hide the filtered row positions.
     */
    public void hideFilteredRowPositions() {
        if (rowPosition == null) {
            rowPosition = new IntVector(graph.getVertexTable().getRowCount());
        }
        rowPosition.resize(graph.getVertexTable().getRowCount());
        int position = 0;
        for (RowIterator iter = rowIterator(); iter.hasNext();) {
            int row = iter.nextRow();
            if (!filteredRowVisible && isRowFiltered(row)) {
                rowPosition.set(row, -1);
            } else {
                rowPosition.set(row, position++);
            }
        }
        invalidate();
    }

    /**
     * DOCUMENT ME!
     *
     * @param row DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getRowPosition(int row) {
        if (rowPosition != null)
            return rowPosition.get(row);
        return row;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getRowPositionCount() {
        if (rowPosition != null)
            return rowPosition.size();
        return graph.getVertexTable().getRowCount();
    }

    /**
     * Returns the filteredRowVisible.
     *
     * @return boolean
     */
    public boolean isFilteredRowVisible() {
        return filteredRowVisible;
    }

    /**
     * Sets the filteredRowVisible.
     *
     * @param filteredRowVisible The filteredRowVisible to set.
     *
     * @return <code>true</code> if the variable has been set.
     */
    public boolean setFilteredRowVisible(boolean filteredRowVisible) {
        if (this.filteredRowVisible != filteredRowVisible) {
            this.filteredRowVisible = filteredRowVisible;
            hideFilteredRowPositions();
            return true;
        }
        return false;
    }

    // Column permutation management
    /**
     * Returns the columnSelection.
     *
     * @return BooleanColumn
     */
    public BooleanColumn getColumnSelection() {
        return columnSelection;
    }

    /**
     * Sets the columnSelection.
     *
     * @param columnSelection The columnSelection to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setColumnSelection(BooleanColumn columnSelection) {
        return changeManagedColumn(VISUAL_COLUMN_SELECTION, this.columnSelection, columnSelection);
    }

    /**
     * Returns the columnFilter.
     *
     * @return FilterColumn
     */
    public FilterColumn getColumnFilter() {
        return columnFilter;
    }

    /**
     * Sets the columnFilter.
     *
     * @param columnFilter The columnFilter to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setColumnFilter(FilterColumn columnFilter) {
        return changeManagedColumn(VISUAL_COLUMN_FILTER, this.columnFilter, columnFilter);
    }

    /**
     * Returns <code>true</code> if the specified column is filtered.
     *
     * @param column the column.
     *
     * @return <code>true</code> if the column is filtered.
     */
    public boolean isColumnFiltered(int column) {
        return columnFilter != null && columnFilter.isFiltered(column);
    }

    /**
     * Returns the sortColumn.
     *
     * @return Column
     */
    public Column getColumnSortColumn() {
        return columnSortColumn;
    }

    /**
     * Sets the sortColumn.
     *
     * @param columnSortColumn The sortColumn to set.
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setColumnSortColumn(Column columnSortColumn) {
        return changeManagedColumn(VISUAL_COLUMN_SORT, this.columnSortColumn, columnSortColumn);
    }

    /**
     * Compute the columnPermutation according to the current comparator.
     */
    protected void permuteColumnColumns() {
        RowComparator comp = columnComparator;
        if (comp == null) {
            columnPermutation = null;
            columnPosition = null;
            return;
        }
        if (columnPermutation == null) {
            columnPermutation = new Permutation(IntColumn.findColumn(graph.getVertexTable(),
                                                                     COLUMNPERMUTATION_COLUMN),
                                                IntColumn.findColumn(graph.getVertexTable(),
                                                                     INVERSECOLUMNPERMUTATION_COLUMN),
                                                graph.getVertexTable().getRowCount());
        }
        columnPermutation.sort(graph.getVertexTable().getRowCount(), comp);
        hideFilteredColumnPositions();
    }

    /**
     * Returns the column permutation.
     *
     * @return the column permutation.
     */
    public Permutation getColumnPermutation() {
        return columnPermutation;
    }

    /**
     * Returns the current comparator.
     *
     * @return the current comparator.
     */
    public RowComparator getColumnComparator() {
        return columnComparator;
    }

    /**
     * Sets the column comparator.
     *
     * @param columnComparator The column comparator to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setColumnComparator(ColumnComparator columnComparator) {
        if (this.columnComparator != columnComparator) {
            setColumnSortColumn(null);
            this.columnComparator = columnComparator;
            permuteColumnColumns();
            invalidate();
            return true;
        }
        return false;
    }

    /**
     * Returns an iterator over the permuted columns.
     *
     * @return an iterator over the permuted columns.
     */
    public RowIterator columnIterator() {
        if (columnPermutation != null)
            return new PermutedIterator(0, columnPermutation);
        else
            return new TableIterator(0, graph.getVertexTable().getRowCount(), true);
    }

    /**
     * Hide the filtered column positions.
     */
    public void hideFilteredColumnPositions() {
        if (columnPosition == null) {
            columnPosition = new IntVector(graph.getVertexTable().getRowCount());
        }
        columnPosition.resize(graph.getVertexTable().getRowCount());
        int position = 0;
        for (RowIterator iter = columnIterator(); iter.hasNext();) {
            int column = iter.nextRow();
            if (!filteredColumnVisible && isColumnFiltered(column)) {
                columnPosition.set(column, -1);
            } else {
                columnPosition.set(column, position++);
            }
        }
        invalidate();
    }

    /**
     * Returns the position of the specified column or -1 if it is hidden.
     *
     * @param col the column.
     *
     * @return the position of the specified column or -1 if it is hidden.
     */
    public int getColumnPosition(int col) {
        if (columnPosition != null)
            return columnPosition.get(col);
        return col;
    }

    /**
     * Returns the count of visible column positions.
     *
     * @return the count of visible column positions.
     */
    public int getColumnPositionCount() {
        if (columnPosition != null)
            return columnPosition.size();
        return graph.getVertexTable().getRowCount();
    }

    /**
     * Returns the filteredColumnVisible.
     *
     * @return boolean
     */
    public boolean isFilteredColumnVisible() {
        return filteredColumnVisible;
    }

    /**
     * Sets the filteredColumnVisible.
     *
     * @param filteredColumnVisible The filteredColumnVisible to set
     *
     * @return <code>true</code> if the variable has been set.
     */
    public boolean setFilteredColumnVisible(boolean filteredColumnVisible) {
        if (this.filteredColumnVisible != filteredColumnVisible) {
            this.filteredColumnVisible = filteredColumnVisible;
            hideFilteredColumnPositions();
            return true;
        }
        return false;
    }
    /**
     * Returns the squared.
     * @return boolean
     */
    public boolean isSquared() {
        return squared;
    }

    /**
     * Sets the squared.
     * @param squared The squared to set
     */
    public void setSquared(boolean squared) {
        if (this.squared != squared) {
            this.squared = squared;
            invalidate();
        }
    }

    public void stateChanged(ChangeEvent e) {
        // Synchronize the rowSelection and columnSelection with the edgeSelection.
        if (e.getSource() == selection) {
            try {
                columnSelection.disableNotify();
                rowSelection.disableNotify();
                columnSelection.clear();
                rowSelection.clear();
                for (int index = selection.getMinSelectionIndex();
                         index <= selection.getMaxSelectionIndex();
                         index++) {
                    if (selection.isSelectedIndex(index)) {
                        int row = graph.getInVertex(index);
                        if (row != -1)
                            rowSelection.setExtend(row, true);
                        int column = graph.getOutVertex(index);
                        if (column != -1)
                            columnSelection.setExtend(column, true);
                    }
                }
            } finally {
                columnSelection.enableNotify();
                rowSelection.enableNotify();
            }
        } else if (e.getSource() == columnFilter) {
            hideFilteredColumnPositions();
        } else if (e.getSource() == rowFilter) {
            hideFilteredRowPositions();
        }
        super.stateChanged(e);
    }

}
