/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.graph;

import java.util.Map;

import javax.swing.event.TableModelListener;

import infovis.*;
import infovis.Graph;
import infovis.utils.RowIterator;

/**
 * Class GraphProxy
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class GraphProxy implements Graph {
    protected Graph graph;
    
    public GraphProxy(Graph graph) {
        this.graph = graph;
    }

    public void addColumn(Column c) {
        graph.addColumn(c);
    }

    public int addEdge(int v1, int v2) {
        return graph.addEdge(v1, v2);
    }

    public void addGraphChangedListener(GraphChangedListener l) {
        graph.addGraphChangedListener(l);
    }

    public void addTableModelListener(TableModelListener l) {
        graph.addTableModelListener(l);
    }

    public int addVertex() {
        return graph.addVertex();
    }

    public void clear() {
        graph.clear();
    }

    public RowIterator edgeIterator() {
        return graph.edgeIterator();
    }

    public RowIterator edgeIterator(int vertex) {
        return graph.edgeIterator(vertex);
    }

    public boolean equals(Object obj) {
        return graph.equals(obj);
    }

    public int findEdge(int v1, int v2) {
        return graph.findEdge(v1, v2);
    }

    public Map getClientPropery() {
        return graph.getClientPropery();
    }

    public Column getColumn(String name) {
        return graph.getColumn(name);
    }

    public Column getColumnAt(int index) {
        return graph.getColumnAt(index);
    }

    public Class getColumnClass(int columnIndex) {
        return graph.getColumnClass(columnIndex);
    }

    public int getColumnCount() {
        return graph.getColumnCount();
    }

    public String getColumnName(int columnIndex) {
        return graph.getColumnName(columnIndex);
    }

    public int getDegree(int vertex) {
        return graph.getDegree(vertex);
    }

    public int getEdge(int v1, int v2) {
        return graph.getEdge(v1, v2);
    }

    public int getEdgeAt(int vertex, int index) {
        return graph.getEdgeAt(vertex, index);
    }

    public int getEdgesCount() {
        return graph.getEdgesCount();
    }

    public Table getEdgeTable() {
        return graph.getEdgeTable();
    }

    public int getInDegree(int vertex) {
        return graph.getInDegree(vertex);
    }

    public int getInEdgeAt(int vertex, int index) {
        return graph.getInEdgeAt(vertex, index);
    }

    public int getInVertex(int edge) {
        return graph.getInVertex(edge);
    }

    public Map getMetadata() {
        return graph.getMetadata();
    }

    public String getName() {
        return graph.getName();
    }

    public int getOutVertex(int edge) {
        return graph.getOutVertex(edge);
    }

    public int getRowCount() {
        return graph.getRowCount();
    }

    public Table getTable() {
        return graph.getTable();
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        return graph.getValueAt(rowIndex, columnIndex);
    }

    public Table getVertexTable() {
        return graph.getVertexTable();
    }

    public int getVerticesCount() {
        return graph.getVerticesCount();
    }

    public int hashCode() {
        return graph.hashCode();
    }

    public int indexOf(Column column) {
        return graph.indexOf(column);
    }

    public int indexOf(String name) {
        return graph.indexOf(name);
    }

    public RowIterator inEdgeIterator(int vertex) {
        return graph.inEdgeIterator(vertex);
    }

    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return graph.isCellEditable(rowIndex, columnIndex);
    }

    public boolean isDirected() {
        return graph.isDirected();
    }

    public boolean isRowValid(int row) {
        return graph.isRowValid(row);
    }

    public RowIterator iterator() {
        return graph.iterator();
    }

    public boolean remove(Column c) {
        return graph.remove(c);
    }

    public void removeEdge(int edge) {
        graph.removeEdge(edge);
    }

    public void removeGraphChangedListener(GraphChangedListener l) {
        graph.removeGraphChangedListener(l);
    }

    public void removeTableModelListener(TableModelListener l) {
        graph.removeTableModelListener(l);
    }

    public void removeVertex(int vertex) {
        graph.removeVertex(vertex);
    }

    public RowIterator reverseIterator() {
        return graph.reverseIterator();
    }

    public void setColumnAt(int i, Column c) {
        graph.setColumnAt(i, c);
    }

    public void setDirected(boolean directed) {
        graph.setDirected(directed);
    }

    public void setName(String name) {
        graph.setName(name);
    }

    public void setValueAt(
        Object aValue,
        int rowIndex,
        int columnIndex) {
        graph.setValueAt(aValue, rowIndex, columnIndex);
    }

    public String toString() {
        return graph.toString();
    }

    public RowIterator vertexIterator() {
        return graph.vertexIterator();
    }

}
