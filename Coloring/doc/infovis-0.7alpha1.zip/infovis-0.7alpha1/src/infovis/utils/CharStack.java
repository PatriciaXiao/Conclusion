/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/

package infovis.utils;

/**
 * Dynamic table of chars
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.5 $
 */
public class CharStack {
    private char data[];
    private int top;

    public CharStack() {
	this(10);
    }

    public CharStack(int initialSize) {
	top = 0;
	data = new char[initialSize];

    }
	
    public void clear() {
	reset();
    }

    public final void push(char f) {
	if (top == data.length) {
	    char newdata[] = new char[top * 2];
	    System.arraycopy(data, 0, newdata, 0, top);
	    data = newdata;
	}
	data[top++] = f;
    }
	
    public final char top() {
	return data[top-1];
    }


    public final char pop() {
	return data[--top];
    }

    public final int size() {
	return top;
    }

    public final char get(int index) {
	return data[index];
    }

    final void put(int index, char val) {
	data[index] = val;
    }

    public final void reset() {
	top = 0;
    }
    public final char[] getData() {
	return data;
    }
    public final boolean isEmpty() {
	return top == 0;
    }
}

