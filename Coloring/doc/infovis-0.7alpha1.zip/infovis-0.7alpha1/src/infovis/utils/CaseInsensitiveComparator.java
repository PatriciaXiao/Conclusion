/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.utils;

import java.util.Comparator;

/**
 * Class CaseInsensitiveComparator
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class CaseInsensitiveComparator implements Comparator {
    public static final CaseInsensitiveComparator sharedInstance = new CaseInsensitiveComparator();
    
    public static CaseInsensitiveComparator getSharedInstance() {
        return sharedInstance;
    }
    
    public int compare(Object o1, Object o2) {
        String s1 = (String) o1;
        String s2 = (String) o2;
        
        return s1.compareToIgnoreCase(s2);
    }
}
