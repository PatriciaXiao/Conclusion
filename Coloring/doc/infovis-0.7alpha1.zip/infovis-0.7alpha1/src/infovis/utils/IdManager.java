/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.utils;

/**
 * Class IdManager
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class IdManager extends IntIntSortedMap {
    protected int timeStamp = 0;
    protected int minId;
    protected int maxId;

    public IdManager() {
        minId = 0;
        maxId = -1;

    }

    public void clear() {
        minId = 0;
        maxId = -1;
        super.clear();
    }

    public int getMinId() {
        return minId;
    }

    public int getMaxId() {
        return maxId;
    }

    public boolean isFree(int id) {
        return id < minId || id > maxId || containsKey(id);
    }

    public void free(int id) {
        if (isFree(id))
            return;
        if (id == maxId) {
            boolean removed = false;
            while (!isEmpty() && lastKey() == (maxId - 1)) {
                maxId--;
                remove(maxId);
                removed = true;
            }
            if (!removed) {
                maxId--;
            }
            else if (isEmpty()) {
                minId = 0;
                maxId = -1;
            }
        }
        else if (id == minId) {
            boolean removed = false;
            while (!isEmpty() && firstKey() == (minId + 1)) {
                minId++;
                remove(minId);
                removed = true;
            }
            if (!removed) {
                minId++;
            }
            else if (isEmpty()) {
                minId = 0;
                maxId = -1;
            }
        }
        else {
            put(id, timeStamp++);
        }
    }

    public int newId() {
        int newId;
        if (isEmpty()) {
            if (minId == 0) {
                newId = (++maxId);
            }
            else
                newId = (--minId);
        }
        else {
            newId = firstKey();
            remove(newId);
        }
        return newId;
    }
    
    public int getIdCount() {
        return maxId - minId + 1 - size();
    }

    public RowIterator iterator() {
        return new TableIterator(minId, maxId + 1) {
            public int nextRow() {
                int ret = row;
                do {
                    row++;
                }
                while (containsKey(row));
                return ret;
            }
        };
    }

    public RowIterator reverseIterator() {
        return new TableIterator(maxId, minId - 1) {
            public int nextRow() {
                int ret = row;
                do {
                    row--;
                }
                while (containsKey(row));
                return ret;
            }
        };
    }
}

