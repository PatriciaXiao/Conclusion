/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.awt;

import infovis.Visualization;

import java.awt.*;

/**
 * Class VisualizationCanvas
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class VisualizationCanvas extends Canvas {
    protected Visualization visualization;

    public VisualizationCanvas(
        GraphicsConfiguration config,
        Visualization visualization) {
        super(config);
        this.visualization = visualization;
    }

    public VisualizationCanvas(Visualization visualization) {
        super();
        this.visualization = visualization;
    }

    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        if (this.visualization != null)
            visualization.paint(g2, getBounds());
    }

    /**
     * Returns the visualization.
     * @return Visualization
     */
    public Visualization getVisualization() {
        return visualization;
    }

    /**
     * Sets the visualization.
     * @param visualization The visualization to set
     */
    public void setVisualization(Visualization visualization) {
        if (this.visualization != null)
            this.visualization.setParent(null);
        this.visualization = visualization;
        if (this.visualization != null)
            this.visualization.setParent(this);
    }
}
