/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/

package infovis;

import infovis.graph.GraphChangedListener;
import infovis.utils.RowIterator;


/**
 * A Graph class for Information Visualization.
 *
 * A Graph references one or two vertex tables and is an edge table.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.26 $
 */
public interface Graph extends Table {
    /** Metadata key for the graph type */
    public static final String GRAPH_TYPE = "GRAPH_TYPE";
    /** Metadata value for a directed graph */
    public static final String GRAPH_TYPE_DIRECTED = "directed";
    /** Metadata value for an undirected graph */
    public static final String GRAPH_TYPE_UNDIRECTED = "undirected";

    /**
     * Returns true if the graph is directed.
     * 
     * @return true if the graph is directed.
     */
    public boolean isDirected();
    
    /**
     * Sets the graph to directed or undirected.
     * 
     * @param directed boolean specifying whether the graph is directed or not.
     */
    public void setDirected(boolean directed);

    /**
     * Returns the number of vertices in the graph
     *
     * @return        The number of vertices in the graph.
     */
    public int getVerticesCount();

    /**
     * Adds a new "in" vertex to the graph.
     *
     * @return the "in" vertex number.
     */
    public int addVertex();

    /**
     * Removes the specified vertex from the graph.
     * 
     * @param vertex the vertex to remove
     * @return true if the vertex has been successfully removed.
     */
    public void removeVertex(int vertex);

    /**
     * Returns the number of edges in the graph.
     *
     * @return the number of edges in the graph.
     */
    public int getEdgesCount();

    /**
     * Adds a new edge between two vertices.
     *
     * @param v1 the first vertex.
     * @param v2 the second vertex.
     *
     * @return the new edge index.
     */
    public int addEdge(int v1, int v2);
    
    /**
     * Removes the specified edge
     * 
     * @param edge the edge to remove
     */
    public void removeEdge(int edge);

    /**
     * Returns the "in" vertex of an edge.
     *
     * @param edge the edge.
     *
     * @return the "in" vertex of an edge or NIL.
     */
    public int getInVertex(int edge);

    /**
     * Returns the "out" vertex of an edge.
     *
     * @param edge the edge.
     *
     * @return the "out" vertex of an edge.
     */
    public int getOutVertex(int edge);

    /**
     * Returns the outgoind edge of a specified vertrex at a specified index
     *  
     * @param vertex the in vertex of the requested edge
     * @param index the index of the edge in the edge list of the vertex
     * @return the outgoind edge of a specified vertrex at a specified index
     */
    public int getEdgeAt(int vertex, int index);
    
    /**
     * Returns the incoming edge of a specified vertrex at a specified index
     *  
     * @param vertex the out vertex of the requested edge
     * @param index the index of the edge in the edge list of the vertex
     * @return the incoming edge of a specified vertrex at a specified index
     */
    public int getInEdgeAt(int vertex, int index);

    /**
     * Returns an edge between two specified vertices.
     *
     * @param v1 the first vertex.
     * @param v2 the second vertex.
     *
     * @return an edge between two specified vertices
     * 	or NIL if none exists.
     */
    public int getEdge(int v1, int v2);

    /**
     * Returns an edge between two specified vertices.
     *
     * @param v1 the first vertex.
     * @param v2 the second vertex.
     *
     * @return an edge between two specified vertices
     * 	creating one if none exists.
     */
    public int findEdge(int v1, int v2);

    /**
     * Returns the degree of the vertex, which is simply the number of edges
     * of the vertex.
     *
     * @param vertex the vertex.
     * @return  The degree of the vertex.
     */
    public int getDegree(int vertex);
    
    /**
     * Returns an iterator over the edges of a specified vertex.
     *
     * @param vertex the vertex.
     *
     * @return the iterator over the edges of the vertex.
     */
    public RowIterator edgeIterator(int vertex);

    /**
     * Returns the in degree of the vertex, which is simply the number of edges
     * arriving to the vertex.
     *
     * @param vertex the vertex.
     * @return  The degree of the vertex.
     */
    public int getInDegree(int vertex);

    /**
     * Returns an iterator over the edges arriving at a specified vertex
     * 
     * @return an iterator over the edges arriving at a specified vertex
     */
    public RowIterator inEdgeIterator(int vertex);
    
    /**
     * Returns an iterator over the vertices of the graph
     * 
     * @return an iterator over the vertices of the graph
     */
    public RowIterator vertexIterator();
    
    /**
     * Returns an iterator over the edges of the graph
     * 
     * @return an iterator over the edges of the graph
     */
    public RowIterator edgeIterator();

    /**
     * Returns the edgeTable.
     * @return DefaultTable
     */
    public Table getEdgeTable();
    
    /**
     * Returns the vertex Table 
     * @return the vertex Table 
     */
    public Table getVertexTable();

    /**
     * Attaches a GraphChangedListener to the graph
     *  
     * @param l the GraphChangedListener to notify when the graph structure changes.
     */
    public void addGraphChangedListener(GraphChangedListener l);
    
    /**
     * Removes a GraphChangedListener from the graph
     *  
     * @param l the GraphChangedListener to remove
     */
    public void removeGraphChangedListener(GraphChangedListener l);
}
