/**
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France
 * -------------------------------------------------------------------------
 * This software is published under the terms of the QPL Software License a
 * copy of which has been included with this distribution in the
 * license-infovis.txt file.
 */
package infovis;

import infovis.column.*;
import infovis.utils.*;
import infovis.visualization.*;

import java.awt.*;
import java.awt.geom.Rectangle2D;


/**
 * Base class for all the visualizations.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.45 $
 */
public interface Visualization extends LabeledComponent, Orientable, RowFilter {
    /* Name of the orientations options */
    /* Name of the visual dimensions managed by the visualization. */
    
    /** Name of the selection visual column */
    public static final String VISUAL_SELECTION = "selection";
    /** Name of the filter visual column */
    public static final String VISUAL_FILTER = "filter";
    /** Name of the sort visual column */
    public static final String VISUAL_SORT = "sort";
    /** Name of the label visual column */
    public static final String VISUAL_LABEL = "label";
    /** Name of the color visual column */
    public static final String VISUAL_COLOR = "color";
    /** Name of the size visual column */
    public static final String VISUAL_SIZE = "size";
    /** Name of the alpha visual column */
    public static final String VISUAL_ALPHA = "alpha";
    /** Name of the shape visual column */
    public static final String VISUAL_SHAPE = "#shape";
    /** Name of the optional IntColumn managing the permutation. */
    public static final String PERMUTATION_COLUMN = "#permutation";
    /** Name of the optional IntColumn managing the inverse permutation. */
    public static final String INVERSEPERMUTATION_COLUMN = "#inversePermutation";
    
    public boolean isVisualColumnInvalidate(String name);
    
    public VisualColumnDescriptor getVisualColumnDescriptor(String name);
    
    /**
     * Returns the visualization of a specified class from a stack of visualizations or null.
     * @param cls the specified class
     * @return the visualization of a specified class from a stack of visualizations or null.
     */
    public Visualization findVisualization(Class cls);
    
    /**
     * Returns a dependent Visualization used by this Visualization in its stack.
     *   
     * @param index
     * @return a dependent Visualization used by this Visualization in its stack.
     */
    public Visualization getVisualization(int index);
    
    /**
     * Releases all the resources used by the visualization.
     *
     */
    public void dispose();

    /**
     * Returns the Table.
     *
     * @return the Table.
     */
    public Table getTable();
    
    public Rectangle2D getBounds();

    /**
     * Returns the owning VisualizationPanel.
     *
     * @return the owning VisualizationPanel.
     */
    public Component getParent();

    /**
     * Sets the owning VisualizationPanel.
     *
     * @param parent owning VisualizationPanel.
     */
    public void setParent(Component parent);

    // Repaint/recomputeShape management
    /**
     * Invalidates the contents of the Visualization if the column has
     * requested so.  Otherwise, just repaint.
     *
     * @param c the Column triggering the invalidate/repaint.
     */
    public void invalidate(Column c);

    /**
     * Invalidates the contents of the Visualization.
     */
    public void invalidate();

    /**
     * Trigger a repaint on the visualization pane.
     */
    public void repaint();

    /**
     * Returns <code>true</code> if modifying this column triggers a
     * recomputation of the visualization.
     *
     * @param c the Column.
     *
     * @return <code>true</code> if modifying this column triggers a
     *         recomputation of the visualization.
     */
    public boolean isInvalidateColumn(Column c);

    
    public boolean setVisualColumn(String name, Column column);
    
    public Column getVisualColumn(String name);

    // Management of managed Columns
    /**
     * Returns the current ListSelectionModel of this pickable.
     *
     * @return the current ListSelectionModel of this pickable.
     */
    public BooleanColumn getSelection();

    /**
     * Returns the filter.
     *
     * @return FilterColumn
     */
    public FilterColumn getFilter();

    /**
     * Returns <code>true</code> if the row is filtered.
     *
     * @param row the row.
     *
     * @return <code>true</code> if the row is filtered.
     */
    public boolean isFiltered(int row);

    /**
     * Returns the orientation.
     * @return int
     */
    public int getOrientation();

    /**
     * Sets the orientation.
     * @param orientation The orientation to set
     */
    public void setOrientation(int orientation);

    /**
     * Returns the colorVisualization.
     *
     * @return ColorVisualization
     */
    public ColorVisualization getColorVisualization();

    /**
     * Install the color associated with the specified row in the graphics.
     *
     * @param g the graphics.
     * @param row the row.
     */
    public void setColorFor(Graphics2D g, int row);

    /**
     * DOCUMENT ME!
     *
     * @param row DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getColorValue(int row);

    /**
     * DOCUMENT ME!
     *
     * @param row DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public Color getColorAt(int row);

    /**
     * Returns the label associated with the specified row.
     *
     * @param row the row.
     *
     * @return the label associated with the specified row.
     */
    public String getLabelAt(int row);

    /**
     * Returns the size associated with the specified row.
     *
     * @param row the row.
     *
     * @return the size associated with the specified row.
     */
    public double getSizeAt(int row);
    
    /**
     * Returns the alpha value associated with the specified row.
     *
     * @param row the row.
     *
     * @return the alpha value associated with the specified row.
     */    
    public double getAlphaAt(int row);

    /**
     * Returns the maxSize.
     *
     * @return double
     */
    public double getMaxSize();

    /**
     * Returns the minSize.
     *
     * @return double
     */
    public double getMinSize();

    /**
     * Sets the maxSize.
     *
     * @param maxSize The maxSize to set
     */
    public void setMaxSize(double maxSize);

    /**
     * Sets the minSize.
     *
     * @param minSize The minSize to set
     */
    public void setMinSize(double minSize);
    

    // Painting
    
    /**
     * Computes the shapes associated with the rows, and store them with
     * setShapeAt.
     *
     * @param bounds the bounding box of the visualization.
     */
    public abstract void computeShapes(Rectangle2D bounds);

    /**
     * Method for painting the visualization.
     *
     * @param graphics the graphics.
     * @param bounds the bounding box of the visualization.
     */
    public void paint(Graphics2D graphics, Rectangle2D bounds);

    /**
     * Checks whether the shapes should be recomputed and call
     * updateShapes then.
     *
     * @param bounds the Visualization bounds.
     */
    public void validateShapes(Rectangle2D bounds);

    /**
     * Returns the ObjectColumn containing the shapes.
     *
     * @return the ObjectColumn containing the shapes.
     */
    public ObjectColumn getShapes();

    /**
     * Returns the shape of stored for a specified row or null if none is
     * store.
     *
     * @param row the row.
     *
     * @return the shape of stored for a specified row or null if none is
     *         store.
     */
    public Shape getShapeAt(int row);

    /**
     * Associate a shape with a specified row
     *
     * @param row the row.
     * @param s the shape.
     */
    public void setShapeAt(int row, Shape s);

    // Picking
    /**
     * Pick the top item.
     *
     * @param x the X coordinate.
     * @param y the Y coordinate.
     * @param bounds the bounding box of the visualization.
     *
     * @return int the index of the item on top.
     */
    public int pickTop(double x, double y, Rectangle2D bounds);

    /**
     * Pick the top item.
     *
     * @param hitBox the bounds where the top item is searched.
     * @param bounds the total bounds where the visualization is displayed.
     *
     * @return int the index of the item on top.
     */
    public int pickTop(Rectangle2D hitBox, Rectangle2D bounds);

    /**
     * Pick all the items under a rectangle.
     *
     * @param hitBox the bounds where the top item is searched.
     * @param bounds the total bounds where the visualization is displayed.
     * @param pick a BooleanColumn that will contain true at each row of
     *        items intersecting the hitBox.
     *
     * @return int the index of the item on top.
     */
    public BooleanColumn pickAll(Rectangle2D hitBox, Rectangle2D bounds,
                                 BooleanColumn pick);

    /**
     * Pick all the items under a rectangle.
     *
     * @param hitBox the bounds where the top item is searched.
     * @param bounds the total bounds where the visualization is displayed.
     * @param pick an IntColumn that will contain each row of items
     *        intersecting the hitBox.
     *
     * @return int the index of the item on top.
     */
    public IntColumn pickAll(Rectangle2D hitBox, Rectangle2D bounds,
                             IntColumn pick);

    public LabeledItem createLabelItem(int row);
    // Management of permutations
    
    
    public void hideSelectedRows();
    
    public void hideFilteredRows();
    
    public void showAllRows();

    /**
     * Returns the permutation.
     *
     * @return Permutation
     */
    public Permutation getPermutation();

    /**
     * Returns the current comparator.
     *
     * @return the current comparator.
     */
    public RowComparator getComparator();

    /**
     * Sets the comparator.
     *
     * @param comparator The comparator to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setComparator(RowComparator comparator);

    /**
     * Returns the row at a specified permuted index.
     *
     * @param index the index.
     *
     * @return the row at a specified permuted index.
     */
    public int getRowAtIndex(int index);

    /**
     * Returns the index at a specified permuted row.
     *
     * @param row the row.
     *
     * @return the index at a specified permuted row.
     */
    public int getRowIndex(int row);

    /**
     * Returns a <code>RowIterator</code> taking the permutation into
     * account.
     *
     * @return a <code>RowIterator</code> taking the permutation into
     *         account.
     */
    public RowIterator iterator();

    // Default values
    /**
     * Returns the defaultFont.
     *
     * @return Font
     */
    public Font getDefaultFont();

    /**
     * Sets the defaultFont.
     *
     * @param defaultFont The defaultFont to set
     */
    public void setDefaultFont(Font defaultFont);

    /**
     * Returns the showingLabel.
     * @return boolean
     */
    public boolean isShowingLabel();

    /**
     * Sets the showingLabel.
     * @param showingLabel The showingLabel to set
     */
    public void setShowingLabel(boolean showingLabel);

    /**
     * Returns the defaultColor.
     *
     * @return Color
     */
    public Color getDefaultColor();

    /**
     * Sets the defaultColor.
     *
     * @param defaultColor The defaultColor to set
     */
    public void setDefaultColor(Color defaultColor);

    /**
     * Returns the selectedColor.
     *
     * @return Color
     */
    public Color getSelectedColor();

    /**
     * Sets the selectedColor.
     *
     * @param selectedColor The selectedColor to set
     */
    public void setSelectedColor(Color selectedColor);

    /**
     * Returns the filteredColor.
     *
     * @return Color
     */
    public Color getFilteredColor();

    /**
     * Returns the unselectedColor.
     *
     * @return Color
     */
    public Color getUnselectedColor();

    /**
     * Sets the unselectedColor.
     *
     * @param unselectedColor The unselectedColor to set
     */
    public void setUnselectedColor(Color unselectedColor);
    /**
     * Returns the smooth.
     * @return boolean
     */
    public boolean isSmooth();

    /**
     * Sets the smooth.
     * @param smooth The smooth to set
     */
    public void setSmooth(boolean smooth);

    /**
     * Sets the filteredColor.
     *
     * @param filteredColor The filteredColor to set
     */
    public void setFilteredColor(Color filteredColor);

    /**
     * Returns the defaultSize.
     *
     * @return double
     */
    public double getDefaultSize();

    /**
     * Returns the defaultAlpha.
     *
     * @return double
     */
    public double getDefaultAlpha();

    public void setDefaultAlpha(double defaultAlpha);

    /**
     * Returns the defaultStroke.
     *
     * @return BasicStroke
     */
    public BasicStroke getDefaultStroke() ;

    /**
     * Sets the defaultStroke.
     *
     * @param defaultStroke The defaultStroke to set
     */
    public void setDefaultStroke(BasicStroke defaultStroke);

    /**
     * Sets the defaultSize.
     *
     * @param defaultSize The defaultSize to set
     */
    public void setDefaultSize(double defaultSize);
    
    /**
     * Returns the displayingStatistics.
     * @return boolean
     */
    public boolean isDisplayingStatistics();

    /**
     * Sets the displayingStatistics.
     * @param displayingStatistics The displayingStatistics to set
     */
    public void setDisplayingStatistics(boolean displayingStatistics);

    /**
     * Returns the displayedItems.
     * @return int
     */
    public int getDisplayedItems();

    /**
     * Returns the layoutTime.
     * @return long
     */
    public long getLayoutTime();

    /**
     * Returns the redisplayTime.
     * @return long
     */
    public long getRedisplayTime();


    /**
     * Returns the fisheyes.
     * @return Fisheyes
     */
    public Fisheyes getFisheyes();

    /**
     * Sets the fisheyes.
     * @param fisheyes The fisheyes to set
     */
    public void setFisheyes(Fisheyes fisheyes);

    public Component getComponent();

}
