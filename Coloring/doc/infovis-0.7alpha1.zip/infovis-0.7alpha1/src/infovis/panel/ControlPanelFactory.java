/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.panel;

import infovis.Visualization;
import infovis.visualization.DefaultVisualization;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.5 $
 */
public class ControlPanelFactory {
	static ControlPanelFactory instance;

	Map creators = new HashMap();

	/**
	 * Constructor for ControlPanelFactory.
	 */
	public ControlPanelFactory() {
		createDefaults();
	}

	protected void createDefaults() {
		add(DefaultVisualization.class, new Creator() {
			public ControlPanel create(Visualization visualization, Class c) {
				if (c == DefaultVisualization.class) {
					return new ControlPanel(visualization);
				}
				return null;
			}
		});
	}

	public static ControlPanelFactory getInstance() {
		if (instance == null) {
			instance = new ControlPanelFactory();
		}
		return instance;
	}

	public static void setInstance(ControlPanelFactory shared) {
		instance = shared;
	}

	/**
	 * Creates a Control Panel from a Visualization.
	 *
	 * @param c The Visualization.
	 *
	 * @return A Control Panel.
	 */
	public ControlPanel create(Visualization visualization) {
		ControlPanel ret = null;
		Class visClass = Visualization.class;
		for (Class c = visualization.getClass();
			visClass.isAssignableFrom(c);
			c = c.getSuperclass()) {
			Creator creator = getCreator(c);
			if (creator != null)
				ret = creator.create(visualization, c);
			if (ret != null)
				break;
		}
		return ret;
	}

	public static ControlPanel createControlPanel(Visualization visualization) {
		return getInstance().create(visualization);
	}

	/**
	 * Adds a default creator for a specific kind of visualization.
	 *
	 * @param c The creator
	 */
	public void add(Class c, Creator creator) {
		assert(Visualization.class.isAssignableFrom(c));

		creators.put(c, creator);
	}

	public void add(Class visClass, Class cpClass) {
		add(visClass, new DefaultCreator(cpClass));
	}

	public static void addControlPanel(Class c, Creator creator) {
		getInstance().add(c, creator);
	}

	public static void addControlPanel(Class c, Class cpClass) {
		getInstance().add(c, cpClass);
	}

	public void setDefault(Class visClass, Class cpClass) {
		if (getCreator(visClass) == null)
			add(visClass, cpClass);
	}

	public Creator getCreator(Class c) {
		return (Creator) creators.get(c);
	}

	public interface Creator {
		ControlPanel create(Visualization visualization, Class c);
	}

	public static class DefaultCreator implements Creator {
		Class controlPanelClass;

		public DefaultCreator(Class c) {
			assert(ControlPanel.class.isAssignableFrom(c));
			controlPanelClass = c;
		}

		public ControlPanel create(Visualization visualization, Class c) {
			Class[] parameterTypes = { c };
			Constructor cons;
			try {
				cons = controlPanelClass.getConstructor(parameterTypes);
			} catch (NoSuchMethodException e) {
                                System.err.println("Cannot find constructor for "+controlPanelClass.getName());
				return null;
			}
			if (cons != null) {
				Object[] args = { visualization };
				try {
					return (ControlPanel) cons.newInstance(args);
				} catch (InstantiationException e) {
                                    System.err.println(
                                        "Cannot instantiate control panel for "
                                        +controlPanelClass.getName());
				} catch (IllegalAccessException e) {
				} catch (InvocationTargetException e) {
				}
			}
			return null;
		}

	}
}
