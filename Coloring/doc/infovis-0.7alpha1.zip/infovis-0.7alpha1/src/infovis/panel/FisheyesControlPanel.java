/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.panel;

import infovis.Visualization;
import infovis.visualization.Fisheyes;

import java.awt.Dimension;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.5 $
 */
public class FisheyesControlPanel extends AbstractControlPanel {
    Fisheyes fisheyes;
    JCheckBox enable;
    Box metrics;
    ButtonGroup metricsGroup;
    JRadioButton metricsL1;
    JRadioButton metricsL2;
    JRadioButton metricsLinf;
    JComboBox lens;
    JSlider maxScale;
    RangeSlider radius;
    JSlider tolerance;

    /**
     * Constructor for FisheyesControlPanel.
     * @param axis
     */
    public FisheyesControlPanel(Visualization vis) {
        super(vis);
        fisheyes = vis.getFisheyes();
        if (fisheyes == null) 
            fisheyes = new Fisheyes();
        
        enable = new JCheckBox("Enable Fisheyes");
        enable.setSelected(vis.getFisheyes() != null);
        enable.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                if (enable.isSelected()) {
                    if (fisheyes == null) {
                        fisheyes = new Fisheyes();
                    }
                    getVisualization().setFisheyes(fisheyes);
                    metricsL1.setEnabled(true);
                    metricsL2.setEnabled(true);
                    metricsLinf.setEnabled(true);
                    lens.setEnabled(true);
                    maxScale.setEnabled(true);
                    radius.setEnabled(true);
                    tolerance.setEnabled(true);
                }
                else {
                    getVisualization().setFisheyes(null);
                    metricsL1.setEnabled(false);
                    metricsL2.setEnabled(false);
                    metricsLinf.setEnabled(false);
                    lens.setEnabled(false);
                    maxScale.setEnabled(false);
                    radius.setEnabled(false);
                    tolerance.setEnabled(false);
                }
                getVisualization().repaint();
            }
        });
        add(enable);
        
        metrics = new Box(BoxLayout.X_AXIS);
        setTitleBorder(metrics, "Metrics");
        
        metricsGroup = new ButtonGroup();
        
        metricsL1 = new JRadioButton("L1");
        addMetrics(metricsL1);
        metricsL1.setSelected(fisheyes.getDistanceMetric() == Fisheyes.DISTANCE_L1);
        
        metricsL2 = new JRadioButton("L2");
        addMetrics(metricsL2);
        metricsL2.setSelected(fisheyes.getDistanceMetric() == Fisheyes.DISTANCE_L2);
        
        metricsLinf = new JRadioButton("Linf");
        addMetrics(metricsLinf);
        metricsLinf.setSelected(fisheyes.getDistanceMetric() == Fisheyes.DISTANCE_LINF);
        
        add(metrics);
        
        lens = new JComboBox(getLensTypes());
        lens.setSelectedIndex(fisheyes.getLensType());
        setTitleBorder(lens, "Lens Shape");
        lens.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        lens.addActionListener(this);
        add(lens);
        
        int scale = (int)Math.round(fisheyes.getMaximumScale());
        maxScale = new JSlider(JSlider.HORIZONTAL, 1,10,
            scale);
        maxScale.setMajorTickSpacing(1);
        maxScale.setPaintTicks(true);
        maxScale.setPaintLabels(true);
        setTitleBorder(maxScale, "Maximum Scale");
        maxScale.addChangeListener(this);
        add(maxScale);
        
        radius = new RangeSlider(0, 200,
            (int)fisheyes.getFocusRadius(), (int)fisheyes.getLensRadius());
        radius.getModel().addChangeListener(this);
    
        setMaximumSize(radius);
        setTitleBorder(radius, "Lens Radius");
        radius.setEnabled(true);
        add(radius);
        
        tolerance = new JSlider(JSlider.HORIZONTAL, 1, 10,
            (int)fisheyes.getTolerance());
        
        tolerance.setMajorTickSpacing(1);
        tolerance.setPaintTicks(true);
        tolerance.setPaintLabels(true);
        setTitleBorder(tolerance, "Shape Tolerance");
        tolerance.addChangeListener(this);
        add(tolerance);
    }
    
    protected void addMetrics(JRadioButton button) {
        String name = button.getName();
        button.setActionCommand(name);
        button.addActionListener(this);
        metricsGroup.add(button);
        metrics.add(button);
    }
    
    
    public String[] getLensTypes() {
        String[] str = { "Gaussian", "Cosine", "Hemisphere", "Linear" };
        return str;
    }
    
    /**
     * @see infovis.panel.AbstractControlPanel#actionPerformed(ActionEvent)
     */
    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equals("L1")) {
            fisheyes.setDistanceMetric(Fisheyes.DISTANCE_L1);
            getVisualization().repaint();
        }
        else if (e.getActionCommand().equals("L2")) {
            fisheyes.setDistanceMetric(Fisheyes.DISTANCE_L2);
            getVisualization().repaint();
        }
        else if (e.getActionCommand().equals("Linf")) {
            fisheyes.setDistanceMetric(Fisheyes.DISTANCE_LINF);
            getVisualization().repaint();
        }
        else if (e.getSource() == lens) {
            fisheyes.setLensType((short)lens.getSelectedIndex());
            getVisualization().repaint();
        }
        else
            super.actionPerformed(e);
    }

    /**
     * @see infovis.panel.AbstractControlPanel#stateChanged(ChangeEvent)
     */
    public void stateChanged(ChangeEvent e) {
        if (e.getSource() == maxScale) {
            int scale = maxScale.getValue();
            fisheyes.setMaximumScale(scale);
            getVisualization().repaint();
        }
        else if (e.getSource() == radius.getModel()) {
            BoundedRangeModel model = radius.getModel();
            fisheyes.setRadii(model.getValue(), model.getValue()+model.getExtent());
            getVisualization().repaint();
        }
        else if (e.getSource() == tolerance) {
            int t = tolerance.getValue();
            fisheyes.setTolerance(t);
            getVisualization().repaint();
        }
        else
            super.stateChanged(e);
    }

}
