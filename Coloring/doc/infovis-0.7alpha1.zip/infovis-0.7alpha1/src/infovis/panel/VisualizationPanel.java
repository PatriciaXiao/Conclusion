/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/

package infovis.panel;

import infovis.Visualization;

import java.awt.*;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;

/**
 * Component managing a visualization.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.16 $
 */
public class VisualizationPanel extends JComponent {
    protected Visualization visualization;
	
    public VisualizationPanel(Visualization visualization) {
	setPreferredSize(new Dimension(500,500));
        setVisualization(visualization);
    }
    
    public void removeNotify() {
        super.removeNotify();
        if (this.visualization != null)
            visualization.dispose();
    }

    /**
     * @see javax.swing.JComponent#printComponent(Graphics)
     */
    protected void paintComponent(Graphics g) {
	Graphics2D g2 = (Graphics2D)g;
        if (this.visualization != null)
            visualization.paint(g2, getVisibleRect());
    }

    /**
     * Returns the visualization.
     * @return Visualization
     */
    public Visualization getVisualization() {
	return visualization;
    }

    /**
     * Sets the visualization.
     * @param visualization The visualization to set
     */
    public void setVisualization(Visualization visualization) {
        if (this.visualization != null)
	   this.visualization.setParent(null);
	this.visualization = visualization;
        if (this.visualization != null)
	   this.visualization.setParent(this);
    }

    /**
     * @see javax.swing.JComponent#getToolTipText(MouseEvent)
     */
    public String getToolTipText(MouseEvent event) {
	int row = visualization.pickTop(event.getX(), event.getY(), getBounds());
	if (row == -1)
	    return null;
	return visualization.getLabelAt(row);
    }

}
