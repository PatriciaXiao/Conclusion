/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.panel;

import infovis.Table;
import infovis.Visualization;
import infovis.column.ColumnFilter;
import infovis.column.filter.InternalFilter;
import infovis.table.FilteredTable;
import infovis.visualization.ExcentricLabelVisualization;

import javax.swing.*;


/**
 * Control Panel for showing selectio, dynamic queries and eveything
 * else.
 *
 * Should evolve with new components.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.25 $
 */
public class ControlPanel extends JSplitPane {
    Visualization               visualization;
    Table                       table;
    VisualizationPanel          visualizationPanel;
    FilteredTable               filteredTable;
    protected JTable            jtable;
    protected JComponent        detail;
    protected JTabbedPane       tabs;
    protected DynamicQueryPanel dynamicQueryPanel;
    protected JComponent    visual;
    protected ExcentricLabelControlPanel excentric;
    protected FisheyesControlPanel     fisheyes;
    /**
     * Constructor for ControlPanel.
     */
    public ControlPanel(Visualization visualization) {
        this(visualization, InternalFilter.sharedInstance());
    }
    
    /**
     * Constructor for ControlPanel.
     */
    public ControlPanel(Visualization visualization, ColumnFilter filter) {
        super(JSplitPane.HORIZONTAL_SPLIT);

        if (ExcentricLabelVisualization.find(visualization) == null) {
            visualization = new ExcentricLabelVisualization(visualization, null);
        }        
        this.visualization = visualization;
        this.table = visualization.getTable();
        visualizationPanel = new VisualizationPanel(visualization);
        filteredTable = new FilteredTable(this.table, filter);

        JSplitPane hsplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        detail = createDetailControlPanel();
        hsplit.setTopComponent(detail);
        tabs = new JTabbedPane();
        hsplit.setBottomComponent(tabs);
        //hsplit.setResizeWeight(1);
        hsplit.setDividerLocation(200);

        tabs.add("Filters", createFiltersControlPanel());
        tabs.add("Visual", createVisualPanel());
        createOtherTabs();
        
//        AGLCanvas canvas = new AGLCanvas();
//        canvas.getContentPane().add(visualizationPanel);
//
//        setLeftComponent(canvas);
        setLeftComponent(visualizationPanel);
        setRightComponent(hsplit);
        setResizeWeight(1);
    }
    
    public void dispose() {
        visualization.setParent(null);
        visualization.dispose();
        visualization = null;
    }

    /**
     * Creates other tables required by the Visualization.
     */
    protected void createOtherTabs() {
        tabs.add("Excentric", createExcentricLabelControPanel());
        tabs.add("Fisheyes", createFisheyesControlPanel());
    }
    
    /**
     * Creates a tab for changing the Excentric Labels paramters.
     */
    protected JComponent createExcentricLabelControPanel() {
        excentric = new ExcentricLabelControlPanel(visualization);
        return excentric;
    }
    
    /**
     * Creates a tab for changing the Fisheyes paramters.
     */
    protected JComponent createFisheyesControlPanel() {
        fisheyes = new FisheyesControlPanel(visualization);
        return fisheyes;
    }

    /**
     * Creates a tab for showing selected items on a table.
     */
    protected JComponent createDetailControlPanel() {
        DetailTable detail = new DetailTable(getFilteredTable(),
                                      visualization.getSelection());
        jtable = new JTable(detail);
        //jtable.setPreferredScrollableViewportSize(new Dimension(450, 200));
        JScrollPane jscroll = new JScrollPane(jtable);

        //jscroll.getViewport().setViewSize(new Dimension(450, 200));
        return jscroll;
    }

    /**
     * Creates a tab for showing dynamic query filters.
     */
    protected JComponent createFiltersControlPanel() {
        dynamicQueryPanel = new DynamicQueryPanel(getVisualization(), getFilteredTable());
        JScrollPane queryScroll = new JScrollPane(dynamicQueryPanel,
                                                  JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                                  JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        return queryScroll;
    }

    /**
     * Creates a tab for showing how visual variable are visualized and change it.
     */
    protected JComponent createVisualPanel() {
        return new DefaultVisualPanel(visualization, getFilter());
    }

    /**
     * Returns the jtable.
     * @return JTable
     */
    public JTable getJtable() {
        return jtable;
    }

    /**
     * Returns the table.
     * @return Table
     */
    public Table getTable() {
        return table;
    }

    /**
     * Returns the dynamicQueryPanel.
     * @return DynamicQueryPanel
     */
    public DynamicQueryPanel getDynamicQueryPanel() {
        return dynamicQueryPanel;
    }

    /**
     * Returns the detail.
     * @return DetailTable
     */
    public JComponent getDetail() {
        return detail;
    }

    /**
     * Returns the stdVisual.
     * @return DefaultVisualPanel
     */
    public JComponent getStdVisual() {
        return visual;
    }

    /**
     * Returns the tabs.
     * @return JTabbedPane
     */
    public JTabbedPane getTabs() {
        return tabs;
    }

    /**
     * Returns the visualization.
     * @return BasicVisualization
     */
    public Visualization getVisualization() {
        return visualization;
    }

    /**
     * Returns the filteredTable.
     * @return FilteredTable
     */
    public FilteredTable getFilteredTable() {
        return filteredTable;
    }
    /**
     * Returns the filter.
     * @return ColumnFilter
     */
    public ColumnFilter getFilter() {
        return filteredTable.getFilter();
    }

    /**
     * Sets the filter.
     * @param filter The filter to set
     */
    public void setFilter(ColumnFilter filter) {
        filteredTable.setFilter(filter);
    }

}
