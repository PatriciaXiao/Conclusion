/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.panel.dqinter;

import infovis.Column;
import infovis.column.FilterColumn;
import infovis.column.NumberColumn;

import java.text.Format;

import javax.swing.*;

/**
 * Class CategoricalDynamicQuery
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.2 $
 */
public class CategoricalDynamicQuery
    extends AbstractDynamicQuery {
    protected NumberColumn numberColumn;
    protected FilterColumn filter;
    protected JList list;
    protected JScrollPane scrollPane;

    public CategoricalDynamicQuery(NumberColumn col) {
        super(col);
    }

    public void update() {
        if (list == null)
            return;
        DefaultListModel model = (DefaultListModel)list.getModel();
        int min = numberColumn.getIntMin();
        int max = numberColumn.getIntMax();
        if (model.getSize() == (max - min))
            return;
        Format format = numberColumn.getFormat();
        model.clear();
        for (int v = min; v <= max; v++) {
            String value = (format == null) ? ""+v : ""+v; // TODO

            model.addElement(value);
        }
    }
    
    public void setColumn(Column column) {
        numberColumn = (NumberColumn)column; // will throw exception if needed
        super.setColumn(column);
    }

    public boolean isFiltered(int row) {
        if (column.isValueUndefined(row))
            return false;
        int v = numberColumn.getIntAt(row) - numberColumn.getIntMin(); // make it robust
        return !list.getSelectionModel().isSelectedIndex(v);
    }


    public JComponent getComponent() {
        if (scrollPane == null) {
            list = new JList();
            scrollPane = new JScrollPane(
                list,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
                );
            update();
        }
        return scrollPane;
    }
}
