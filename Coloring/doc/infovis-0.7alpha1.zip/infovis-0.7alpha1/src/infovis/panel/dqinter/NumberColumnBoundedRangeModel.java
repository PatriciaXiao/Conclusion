/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.panel.dqinter;

import java.awt.Dimension;

import infovis.Column;
import infovis.column.FilterColumn;
import infovis.column.NumberColumn;
import infovis.panel.*;

import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * <code>BoundedFloatModel</ocde> for <code>NumberColumn</code>s.
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class NumberColumnBoundedRangeModel
    extends DefaultDoubleBoundedRangeModel
    implements ChangeListener, DynamicQuery {
    protected NumberColumn column;
    protected FilterColumn filter;
    protected DoubleRangeSlider component;
	
    /**
     * Constructor from a NumberColumn
     */
    public NumberColumnBoundedRangeModel(NumberColumn column) {
	setColumn(column);
    }

    public void stateChanged(ChangeEvent e) {
	if (e.getSource() == column) {
	    update();
	}
    }

    public void update() {
	setRangeProperties(column.getDoubleMin(),
			   column.getDoubleMax()-column.getDoubleMin(),
			   column.getDoubleMin(),
			   column.getDoubleMax(),
			   false);
    }
	
    public boolean isFiltered(int row) {
	if (column.isValueUndefined(row))
	    return false;
	double v = column.getDoubleAt(row);
        double min = column.round(getValue());
        double max = column.round(getValue()+getExtent());
	boolean ret = ! (v >= min && v <= max);
//        if (ret) {
//            assert(ret);
//        }
        return ret;
    }

    /**
     * Returns the column.
     * @return Column
     */
    public Column getColumn() {
	return column;
    }

    /**
     * Sets the column.
     * @param column The column to set
     */
    public void setColumn(NumberColumn column) {
	if (column == this.column)
	    return;
	if (this.column != null)
	    this.column.removeChangeListener(this);
	this.column = column;
	if (this.column != null)
	    this.column.addChangeListener(this);
	update();
    }
    
    public FilterColumn getFilterColumn() {
        return filter;
    }
    
    public void setFilterColumn(FilterColumn filter) {
        if (this.filter != null) {
            this.filter.removeDynamicQuery(this);
        }
        this.filter = filter;
        if (this.filter != null) {
            this.filter.addDynamicQuery(this);      
        }
    }

    public void apply() {
	if (filter != null)
            filter.applyDynamicQuery(this, column.iterator());
    }

    protected void fireStateChanged() {
	super.fireStateChanged();
	apply();
    }

    public JComponent getComponent() {
	if (component == null) {
	    component = new DoubleRangeSlider(this);
            component.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));            
	    component.setEnabled(true);
	}
	return component;
    }


}
