/**
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France
 * -------------------------------------------------------------------------
 * This software is published under the terms of the QPL Software License a
 * copy of which has been included with this distribution in the
 * license-infovis.txt file.
 */
package infovis.panel;

import infovis.*;
import infovis.column.StringColumn;
import infovis.graph.DefaultGraph;
import infovis.graph.io.GraphReaderFactory;
import infovis.graph.io.HTMLGraphReader;
import infovis.graph.visualization.GraphVisualization;
import infovis.graph.visualization.MatrixVisualization;
import infovis.table.DefaultTable;
import infovis.table.io.TableReaderFactory;
import infovis.table.visualization.ScatterPlotVisualization;
import infovis.tree.DefaultTree;
import infovis.tree.io.TreeReaderFactory;
import infovis.tree.visualization.TreeVisualization;
import infovis.tree.visualization.TreemapVisualization;
import infovis.tree.visualization.treemap.SliceAndDice;
import infovis.visualization.VisualizationFactory;

import java.awt.*;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import agile2d.AgileJFrame;

/**
 * Component to create a visualization program as simply as possible.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.21 $
 */
public class MainFrameDecorator implements ActionListener {
    JFrame frame;
    JMenuBar menuBar;
    JMenu fileMenu;
    JMenu viewMenu;
    JMenu helpMenu;
    JFileChooser fileChooser;
    JTextField urlChooser;
    JDialog urlDialog;
    JMenuItem createImageItem;
    JFileChooser createImageFileChooser;
    BoundedRangeModel scaleModel;

    JMenu visualizationMenu;
    Table table;
    Visualization visualization = null;
    ControlPanel controlPanel;
    JComponent splashScreen;
    boolean creatingWindow = true;
    boolean usingAgile = false;

    AbstractAction fileOpenAction = new DefaultAction("Open", 'O') {
        public void actionPerformed(ActionEvent e) {
            chooseFile();
        }
    };
    AbstractAction urlOpenAction = new DefaultAction("Url Open", 'U') {
        public void actionPerformed(ActionEvent e) {
            chooseURL();
        }
    };
    AbstractAction quitAction = new DefaultAction("Quit", 'Q') {
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    };
    AbstractAction aboutAction = new AbstractAction("About...") {
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(
                null,
                "The Visualization Toolkit\n(C) Jean-Daniel Fekete and INRIA, France",
                "About the Visualization Toolkit",
                JOptionPane.INFORMATION_MESSAGE);
        }
    };

    AbstractAction toggleAgileAction =
        new AbstractAction("Toggle Agile2D") {
        public void actionPerformed(ActionEvent e) {
            usingAgile = !usingAgile;
        }
    };
    
    AbstractAction createImageAction =
        new AbstractAction("Create Image") {
            public void actionPerformed(ActionEvent e) {
                createImage();
            }
    };
    
    AbstractAction editTableAction =
        new AbstractAction("Edit Table") {
            public void actionPerformed(ActionEvent e) {
                editTable();
            }
        };

    /**
     * Creates a new MainFrameDecorator object.
     *
     * @param frame the JFrame to decorate.
     */
    public MainFrameDecorator(JFrame frame) {
        this.frame = frame;
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        urlDialog = new JDialog(frame, "Open URL ...", true);
        urlChooser = new JTextField(30);
        urlChooser.setAutoscrolls(true);
        urlChooser.addActionListener(this);
        urlDialog.getContentPane().add(urlChooser);
        urlDialog.pack();
        fileChooser = new JFileChooser(".");
        fileChooser.setFileSelectionMode(
            JFileChooser.FILES_AND_DIRECTORIES);
        fileChooser.setDoubleBuffered(false);
        createImageFileChooser = new JFileChooser(".");
        createImageFileChooser.setFileSelectionMode(
            JFileChooser.FILES_ONLY);
        createImageFileChooser.setDoubleBuffered(false);
        JSlider scaleSlider = new JSlider(JSlider.VERTICAL, 0, 1600, 100);
        scaleModel = scaleSlider.getModel();
        scaleSlider.setMajorTickSpacing(100);
        scaleSlider.setMinorTickSpacing(10);
        scaleSlider.setPaintTicks(true);
        scaleSlider.setPaintLabels(true);
        scaleSlider.setBorder(BorderFactory.createTitledBorder("Scale"));
        createImageFileChooser.setAccessory(scaleSlider);
        menuBar = new JMenuBar();
        frame.setJMenuBar(menuBar);
        createMenus();
        frame.getContentPane().add(createSplashScreen());
    }

    /**
     * Creates the menus.
     */
    protected void createMenus() {
        fileMenu = createFileMenu();
        menuBar.add(fileMenu);
        viewMenu = createViewMenu();
        menuBar.add(viewMenu);
        visualizationMenu = new JMenu("Visualization");
        visualizationMenu.setEnabled(false);
        menuBar.add(visualizationMenu);
        helpMenu = createHelpMenu();
        menuBar.add(helpMenu);
    }

    /**
     * Creates the file menu.
     *
     * @return the file menu.
     */
    public JMenu createFileMenu() {
        JMenu fileMenu = new JMenu("File");

        fileMenu.add(fileOpenAction);
        fileMenu.add(urlOpenAction);
        createImageItem = fileMenu.add(createImageAction);
        createImageItem.setEnabled(false);
        fileMenu.addSeparator();
        fileMenu.add(quitAction);
        return fileMenu;
    }

    public JMenu createViewMenu() {
        JMenu viewMenu = new JMenu("View");

        JCheckBoxMenuItem cb = new JCheckBoxMenuItem(toggleAgileAction);
        cb.setArmed(usingAgile);
        viewMenu.add(cb);
        viewMenu.add(editTableAction);
        editTableAction.setEnabled(false);
        return viewMenu;
    }

    /**
     * Creates the help menu.
     *
     * @return the help menu.
     */
    public JMenu createHelpMenu() {
        JMenu helpMenu = new JMenu("Help");

        helpMenu.add(aboutAction);
        return helpMenu;
    }

    /**
     * Create the splash screen.
     *
     * @return the splash screen.
     */
    public JComponent createSplashScreen() {
        splashScreen = new SplashPanel();
        return splashScreen;
    }

    /**
     * shows a file chooser and wait for an selection.
     */
    protected void chooseFile() {
        int ret = fileChooser.showOpenDialog(null);
        if (ret == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            String error = openFile(file);
            if (error == null) {
                frame.pack();
            }
            else {
                JOptionPane.showMessageDialog(
                    null,
                    "Error",
                    "Couldn't read file " + file.getAbsoluteFile(),
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    protected void chooseURL() {
        urlDialog.setVisible(true);
        String url = urlChooser.getText();
        if (url.length() != 0) {
            Graph graph = new DefaultGraph();
            HTMLGraphReader reader = new HTMLGraphReader(url, graph);
            reader.add(url);
            if (reader.load()) {
                visualization = createGraphVisualization(graph);
            }
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param file DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String openFile(File file) {
        String name = file.getAbsolutePath();

        table = new DefaultTable();
        Graph graph = new DefaultGraph(table);
        boolean loaded = GraphReaderFactory.readGraph(name, graph);

        if (loaded) {
            visualization = createGraphVisualization(graph);
            return null;
        }
        
        table = new DefaultTable();
        Tree tree = DefaultTree.findTree(table);
        loaded = TreeReaderFactory.readTree(name, tree);
        if (loaded) {
            visualization = createTreeVisualization(tree);
            return null;
        }
        
        table = new DefaultTable();
        loaded = TableReaderFactory.readTable(name, table);
        if (loaded) {
            visualization = createTableVisualization(table);
            return null;
        }

        return "invalid format";
    }

    /**
     * DOCUMENT ME!
     *
     * @param t DOCUMENT ME!
     * @param index DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public static StringColumn getStringColumn(Table t, int index) {
        StringColumn ret = null;
        for (int i = 0; i < t.getColumnCount(); i++) {
            ret = StringColumn.getColumn(t, i);
            if (ret != null && !ret.isInternal() && index-- == 0)
                return ret;
        }
        return null;
    }

    /**
     * DOCUMENT ME!
     *
     * @param table DOCUMENT ME!
     * @param visualization DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public Visualization createContols(
        Table table,
        final Visualization visualization) {
        //visualization.setLabelColumn(getStringColumn(table, 0));
        ControlPanelFactory factory =
            ControlPanelFactory.getInstance();

        final ControlPanel control =
            (ControlPanel) factory.create(visualization);
        if (splashScreen != null) {
            frame.getContentPane().remove(splashScreen);
        }
        if (controlPanel != null && !creatingWindow) {
            frame.getContentPane().remove(controlPanel);
            controlPanel.getVisualization().dispose();
            controlPanel = null;
        }
        else if (controlPanel != null && creatingWindow) {
            JFrame window =
                usingAgile
                    ? new AgileJFrame("Agile2D " + table.getName())
                    : new JFrame(table.getName());
            window.addWindowListener(new WindowAdapter() {
                public void windowClosed(WindowEvent e) {
                    control.dispose();
                }
            });
            window.setSize(500, 500);
            window.getContentPane().add(control);
            window.pack();
            window.setVisible(true);
            return visualization;
        }
        controlPanel = control;
        frame.getContentPane().add(controlPanel);
        frame.pack();
        System.gc();
        System.runFinalization();
        VisualizationFactory.Creator[] creators =
            VisualizationFactory
                .getInstance()
                .getCompatibleCreators(
                table);
        visualizationMenu.removeAll();
        for (int i = 0; i < creators.length; i++) {
            addVisualizationMenu(creators[i], i);
        }
        visualizationMenu.setEnabled(creators.length != 0);
        createImageItem.setEnabled(visualization != null);
        editTableAction.setEnabled(visualization != null);

        return visualization;
    }

    public void addVisualizationMenu(
        final VisualizationFactory.Creator creator,
        int i) {
        final String name = creator.getName();
        visualizationMenu.add(new DefaultAction(name, '1' + i) {
            public void actionPerformed(ActionEvent e) {
                Visualization visualization = creator.create(table);
                if (visualization != null)
                    createContols(table, visualization);
            }
        });
    }

    /**
     * DOCUMENT ME!
     *
     * @param graph DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public GraphVisualization createGraphVisualization(Graph graph) {
        table = graph;
        MatrixVisualization visualization =
            new MatrixVisualization(graph);
        createContols(graph, visualization);
        return visualization;
    }

    /**
     * DOCUMENT ME!
     *
     * @param tree DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public TreeVisualization createTreeVisualization(Tree tree) {
        table = tree;
        TreemapVisualization visualization =
            new TreemapVisualization(
                tree,
                null,
                SliceAndDice.SLICEANDDICE);
        createContols(tree, visualization);
        return visualization;
    }

    /**
     * DOCUMENT ME!
     *
     * @param table DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public Visualization createTableVisualization(Table table) {
        this.table = table;
        Visualization visualization =
            new ScatterPlotVisualization(table);
        createContols(table, visualization);
        return visualization;
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == urlChooser) {
            urlDialog.setVisible(false);
        }
    }
    public void createImage() {
        int ret = createImageFileChooser.showOpenDialog(null);
        if (ret == JFileChooser.APPROVE_OPTION) {
            File file = createImageFileChooser.getSelectedFile();
            createImage(file, scaleModel.getValue()/100.0f);
        }
    }
    
    public void createImage(File file, float scale) {
        Component comp = visualization.getComponent();
        
        Rectangle bounds = comp.getBounds();
        bounds.x = 0;
        bounds.y = 0;
        bounds.width = (int)(bounds.width * scale);
        bounds.height = (int)(bounds.height * scale);
        BufferedImage image = new BufferedImage(
            bounds.width,
            bounds.height,
            BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = (Graphics2D)image.getGraphics();
        visualization.paint(g2d, bounds);
        
        try {
            ImageIO.write(image, "png", file);
        }
        catch (IOException e) {
            e.printStackTrace();            
        }
        image.flush();
        image = null;
    }
    
    public void editTable() {
        JFrame window = new JFrame("Table");
        JTable jtable = new JTable(table);
        jtable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        JScrollPane pane = new JScrollPane(
            jtable,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        window.getContentPane().add(pane);
        //window.setSize(500, 500);
        window.pack();
        window.setVisible(true);
    }

    /**
     * Main program.
     *
     * @param args args.
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("InfoVis Toolkit");
        new MainFrameDecorator(frame);
        frame.pack();
        frame.setVisible(true);
    }
}
