/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.panel;

import infovis.Visualization;
import infovis.visualization.*;
import infovis.visualization.DefaultExcentricLabels;
import infovis.visualization.ExcentricLabels;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.4 $
 */
public class ExcentricLabelControlPanel extends AbstractControlPanel {
    ExcentricLabels excentricLabels;
    JCheckBox enable;
    JSlider radiusSlider;
    JSlider maxCountSlider;
    JCheckBox opaque;

    /**
     * Constructor for ExcentricLabelControlPanel.
     * @param axis
     */
    public ExcentricLabelControlPanel(Visualization vis) {
        super(vis);
        excentricLabels = findExcentric();
        if (excentricLabels == null)
            excentricLabels = new DefaultExcentricLabels();
        
        enable = new JCheckBox("Enable Excentric Labels");
        enable.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                if (enable.isSelected()) {
                    getExcentricVisualization().setExcentric(excentricLabels);
                    radiusSlider.setEnabled(true);
                    maxCountSlider.setEnabled(true);
                    opaque.setEnabled(true);
                }
                else {
                    getExcentricVisualization().setExcentric(null);
                    radiusSlider.setEnabled(false);
                    maxCountSlider.setEnabled(false);
                    opaque.setEnabled(false);
                }
            }
        });
        add(enable);
        
        radiusSlider = new JSlider(1, 300);
        radiusSlider.setValue((int)(excentricLabels.getFocusSize()/2));
        radiusSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                excentricLabels.setFocusSize(2*radiusSlider.getValue());
            }
        });
        radiusSlider.setBorder(BorderFactory.createTitledBorder("Radius"));
        add(radiusSlider);
        
        maxCountSlider = new JSlider(10, 100);
        maxCountSlider.setValue(excentricLabels.getMaxLabels());
        maxCountSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                excentricLabels.setMaxLabels(maxCountSlider.getValue());
            }
        });
        maxCountSlider.setBorder(BorderFactory.createTitledBorder("Max Labels"));
        add(maxCountSlider);
        
        opaque = new JCheckBox("Opaque Labels");
        opaque.setSelected(excentricLabels.isOpaque());
        opaque.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                excentricLabels.setOpaque(opaque.isSelected());
            }
        });
        add(opaque);
        enable.setSelected(findExcentric() != null);
    }
    
    public ExcentricLabelVisualization getExcentricVisualization() {
        return (ExcentricLabelVisualization)getVisualization().
            findVisualization(ExcentricLabelVisualization.class);
    }
    
    public ExcentricLabels findExcentric() {
        ExcentricLabelVisualization el = getExcentricVisualization();
        if (el == null)
            return null;
        return el.getExcentric();
    }

}
