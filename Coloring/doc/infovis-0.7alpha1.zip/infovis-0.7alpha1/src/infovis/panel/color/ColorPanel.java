/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.panel.color;

import infovis.*;
import infovis.panel.ColumnListCellRenderer;
import infovis.panel.FilteredColumnListModel;
import infovis.visualization.ColorVisualization;

import java.awt.Dimension;

import javax.swing.*;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;


/**
 * Panel for managing the Color and ColorVisualization associated with
 * a BasicVisualization.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.15 $
 */
public class ColorPanel extends Box implements ListDataListener {
    Visualization                  visualization;
    String                         visualColor;
    Table                          table;
    FilteredColumnListModel        model;
    JComboBox                      colorCombo;
    JPanel                         controlHolder;
    ColorVisualizationControlPanel control;

    /**
     * Creates a new ColorPanel object.
     *
     * @param visualization the Visualization.
     */
    public ColorPanel(Visualization visualization, String visualColor, String label) {
        super(BoxLayout.Y_AXIS);
        this.visualization = visualization;
        this.visualColor = visualColor;
        table = visualization.getTable();
        model = new FilteredColumnListModel(table);
        model.setNullAdded(true);
        colorCombo = new JComboBox(model);
        model.setSelectedItem(visualization.getVisualColumn(visualColor));
        colorCombo.setRenderer(new ColumnListCellRenderer());
        colorCombo.setBorder(BorderFactory.createTitledBorder(label));
        colorCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE,
                                                (int)colorCombo.getPreferredSize()
                                                               .getHeight()));
        add(colorCombo);
        model.addListDataListener(this);

        controlHolder = new JPanel();
        controlHolder.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        control = 
            ColorVisualizationControlPanelFactory.createColorVisualisationControlPanel(
                visualization);
        if (control != null)
            controlHolder.add(control);
        add(controlHolder);
    }

    public void contentsChanged(ListDataEvent e) {
        Column col = (Column)colorCombo.getSelectedItem();
        visualization.setVisualColumn(Visualization.VISUAL_COLOR, col);
        ColorVisualization vis = visualization.getColorVisualization();
        if (control == null || vis != control.getColorVisualization()) {
            if (control != null)
                controlHolder.remove(control);
            control =
                ColorVisualizationControlPanelFactory.createColorVisualisationControlPanel(visualization);
            if (control != null)
                controlHolder.add(control);
        }
    }

    public void intervalAdded(ListDataEvent e) {
    }

    public void intervalRemoved(ListDataEvent e) {
    }
}
