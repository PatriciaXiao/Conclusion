/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.panel;

import infovis.column.ColumnFilter;
import infovis.visualization.LinkVisualization;

/**
 * Class DefaultLinkVisualPanel
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class DefaultLinkVisualPanel extends DefaultVisualPanel {

    public DefaultLinkVisualPanel(
        LinkVisualization visualization,
        ColumnFilter filter) {
        super(visualization, filter);
    }

    protected void createAll() {
        addColor(getVisualization());
        addSize(getVisualization());
        addAlpha(getVisualization());
        addLabel(getVisualization());
    }
    
    public static void addVisualPanelTab(
        ControlPanel controlPanel,
        LinkVisualization linkVisualization,
        ColumnFilter filter) {
        controlPanel.getTabs().insertTab(
            "Links",
            null,
            new DefaultLinkVisualPanel(linkVisualization, filter),
            null,
            2);
    }
}
