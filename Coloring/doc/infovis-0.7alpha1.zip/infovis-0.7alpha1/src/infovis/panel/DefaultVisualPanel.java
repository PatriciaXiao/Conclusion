/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.panel;

import infovis.*;
import infovis.column.ColumnFilter;
import infovis.column.NumberColumn;
import infovis.column.filter.*;
import infovis.panel.color.ColorPanel;

import java.awt.Dimension;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.event.*;


/**
 * Control panel for standard visual components such as size and label.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class DefaultVisualPanel extends AbstractControlPanel {
    protected ColumnFilter            filter;
    protected Table                   table;
    protected ColorPanel              colorPanel;
    protected JCheckBox               smooth;
    protected FilteredColumnListModel sizeModel;
    protected JComboBox               sizeCombo;
    protected JSlider                 defaultSizeSlider; 
    protected FilteredColumnListModel alphaModel;
    protected JComboBox               alphaCombo;
    protected JSlider                 defaultAlphaSlider; 
    protected FilteredColumnListModel labelModel;
    protected JCheckBox               labelItems;
    protected JCheckBox               displayStatistics;
    protected JComboBox               labelCombo;
    protected FilteredColumnListModel sortModel;
    protected JComboBox               sortCombo;
    protected ButtonGroup orientationGroup;
    protected Box orientation;
    protected JRadioButton orientationNorth;
    protected JRadioButton orientationSouth;
    protected JRadioButton orientationEast;
    protected JRadioButton orientationWest;

    /**
     * Constructor for DefaultVisualPanel.
     */
    public DefaultVisualPanel(Visualization visualization, ColumnFilter filter) {
        super(visualization);
        this.filter = filter;
        table = getVisualization().getTable();
        createAll();
    }

    protected void createAll() {
        addColor(getVisualization());
        addAlpha(getVisualization());
        addSize(getVisualization());
        addLabel(getVisualization());
        addSort(getVisualization());
    }

    protected void addSort(Visualization visualization) {
        
        sortModel = new FilteredColumnListModel(table, filter);
        sortCombo = createJCombo(sortModel, null, "Sort by");
    }

    protected void addLabel(Visualization visualization) {        
        labelModel = new FilteredColumnListModel(table, filter);
        labelCombo = createJCombo(labelModel,
            visualization.getVisualColumn(Visualization.VISUAL_LABEL),
                                  "Label by");
        
        Box checkBox = new Box(BoxLayout.X_AXIS);                          
        labelItems = new JCheckBox("Label all items");
        labelItems.setSelected(visualization.isShowingLabel());
        labelItems.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                getVisualization().setShowingLabel(labelItems.isSelected());
            }
        });
        checkBox.add(labelItems);
        
        displayStatistics = new JCheckBox("Display stats");
        displayStatistics.setSelected(visualization.isDisplayingStatistics());
        displayStatistics.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                getVisualization().setDisplayingStatistics(displayStatistics.isSelected());
            }
        });
        checkBox.add(displayStatistics);
        add(checkBox);
    }

    protected void addSize(Visualization visualization) {
        sizeModel = new FilteredColumnListModel(table, filter);
        sizeModel.setFilter(new ComposeOrFilter(InternalFilter.sharedInstance(),
                                                NotNumberFilter.sharedInstance()));
        sizeModel.setNullAdded(true);
        sizeCombo = createJCombo(sizeModel,
            visualization.getVisualColumn(Visualization.VISUAL_SIZE),
                                 "Size by");
        defaultSizeSlider = new JSlider(0, 255, (int)(visualization.getDefaultSize()));
        setTitleBorder(defaultSizeSlider, "Default Size");
        defaultSizeSlider.setMaximumSize(new Dimension(Integer.MAX_VALUE,
                                           (int)defaultSizeSlider.getPreferredSize()
                                                     .getHeight()));
        defaultSizeSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                getVisualization().setDefaultSize(defaultSizeSlider.getValue());
            }
        });
        add(defaultSizeSlider);
    }
    
    protected void addAlpha(Visualization visualization) {
        alphaModel = new FilteredColumnListModel(table, filter);
        alphaModel.setFilter(new ComposeOrFilter(InternalFilter.sharedInstance(),
                                                NotNumberFilter.sharedInstance()));
        alphaModel.setNullAdded(true);
        alphaCombo = createJCombo(alphaModel,
            visualization.getVisualColumn(Visualization.VISUAL_ALPHA),
                                 "Alpha by");
        defaultAlphaSlider = new JSlider(0, 255, (int)(visualization.getDefaultAlpha()*255));
        setTitleBorder(defaultAlphaSlider, "Default Alpha");
        defaultAlphaSlider.setMaximumSize(new Dimension(Integer.MAX_VALUE,
                                           (int)defaultAlphaSlider.getPreferredSize()
                                                     .getHeight()));
        defaultAlphaSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                getVisualization().setDefaultAlpha(defaultAlphaSlider.getValue()/255.0);
            }
        });
        add(defaultAlphaSlider);
    }

    protected void addColor(Visualization visualization) {
        
        colorPanel = new ColorPanel(visualization, Visualization.VISUAL_COLOR, "Color by");
        add(colorPanel);

        smooth = new JCheckBox("Smooth");
        
        smooth.setSelected(visualization.isSmooth());
        smooth.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                getVisualization().setSmooth(smooth.isSelected());
            }
        });
        add(smooth);
    }

    protected JComboBox createJCombo(FilteredColumnListModel model, Column c,
                                     String label) {
        model.setNullAdded(true);
        JComboBox combo = new JComboBox(model);
        model.setSelectedItem(c);
        combo.setRenderer(new ColumnListCellRenderer());
        return addJCombo(label, combo);
    }

    protected JComboBox addJCombo(
        String label,
        JComboBox combo) {
        setTitleBorder(combo, label);
        combo.setMaximumSize(new Dimension(Integer.MAX_VALUE,
                                           (int)combo.getPreferredSize()
                                                     .getHeight()));
        add(combo);
        combo.getModel().addListDataListener(this);
        return combo;
    }
    
    public void addOrientationButtons() {
        orientationGroup = new ButtonGroup();
        orientation = new Box(BoxLayout.X_AXIS);
        setTitleBorder(orientation, "Orientation");
        
        orientationNorth = new JRadioButton("North");
        orientationGroup.add(orientationNorth);
        orientationNorth.setSelected(
            getVisualization().getOrientation()==Visualization.ORIENTATION_NORTH);
        orientationNorth.addActionListener(this);
        orientation.add(orientationNorth);
        
        orientationSouth = new JRadioButton("South");
        orientationGroup.add(orientationSouth);
        orientationSouth.setSelected(
            getVisualization().getOrientation()==Visualization.ORIENTATION_SOUTH);
        orientationSouth.addActionListener(this);
        orientation.add(orientationSouth);
        
        orientationEast = new JRadioButton("East");
        orientationGroup.add(orientationEast);
        orientationNorth.setSelected(
            getVisualization().getOrientation()==Visualization.ORIENTATION_EAST);
        orientationEast.addActionListener(this);
        orientation.add(orientationEast);
        
        orientationWest = new JRadioButton("West");
        orientationGroup.add(orientationWest);
        orientationNorth.setSelected(
            getVisualization().getOrientation()==Visualization.ORIENTATION_WEST);
        orientationWest.addActionListener(this);
        orientation.add(orientationWest);
        
        add(orientation);
    }
    

    /**
     * @see javax.swing.event.ListDataListener#contentsChanged(ListDataEvent)
     */
    public void contentsChanged(ListDataEvent e) {
        if (e.getSource() == sizeModel) {
            NumberColumn col = (NumberColumn)sizeCombo.getSelectedItem();
            getVisualization().setVisualColumn(Visualization.VISUAL_SIZE, col);
        }
        else if (e.getSource() == labelModel) {
            getVisualization().setVisualColumn(Visualization.VISUAL_LABEL, (Column)labelCombo.getSelectedItem());
        }
        else if (e.getSource() == sortModel) {
            getVisualization().setVisualColumn(Visualization.VISUAL_SORT, (Column)sortCombo.getSelectedItem());
        }
        super.contentsChanged(e);
    }
    
    public void actionPerformed(ActionEvent e) {    
        if (e.getSource() == orientationNorth) {
            getVisualization().setOrientation(Visualization.ORIENTATION_NORTH);
            getVisualization().repaint();
        }
        else if (e.getSource() == orientationSouth) {
            getVisualization().setOrientation(Visualization.ORIENTATION_SOUTH);
            getVisualization().repaint();
        }
        else if (e.getSource() == orientationEast) {
            getVisualization().setOrientation(Visualization.ORIENTATION_EAST);
            getVisualization().repaint();
        }
        else if (e.getSource() == orientationWest) {
            getVisualization().setOrientation(Visualization.ORIENTATION_WEST);
            getVisualization().repaint();
        }
        else
            super.actionPerformed(e);
    }
    
    /**
     * Returns the labelCombo.
     * @return JComboBox
     */
    public JComboBox getLabelCombo() {
        return labelCombo;
    }

    /**
     * Returns the labelModel.
     * @return FilteredColumnListModel
     */
    public FilteredColumnListModel getLabelModel() {
        return labelModel;
    }

    /**
     * Returns the sizeCombo.
     * @return JComboBox
     */
    public JComboBox getSizeCombo() {
        return sizeCombo;
    }

    /**
     * Returns the sizeModel.
     * @return FilteredColumnListModel
     */
    public FilteredColumnListModel getSizeModel() {
        return sizeModel;
    }

    /**
     * Returns the table.
     * @return Table
     */
    public Table getTable() {
        return table;
    }
}
