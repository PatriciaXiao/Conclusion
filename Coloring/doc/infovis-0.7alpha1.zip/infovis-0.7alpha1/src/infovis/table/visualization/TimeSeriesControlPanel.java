/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.table.visualization;

import javax.swing.JComponent;

import infovis.column.ColumnFilter;
import infovis.panel.ControlPanel;

/**
 * Class TimeSeriesControlPanel
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class TimeSeriesControlPanel extends ControlPanel {

    public TimeSeriesControlPanel(TimeSeriesVisualization visualization) {
        super(visualization);
    }

    public TimeSeriesControlPanel(
        ScatterPlotVisualization visualization,
        ColumnFilter filter) {
        super(visualization, filter);
    }

    public TimeSeriesVisualization getTimeSeries() {
        return (TimeSeriesVisualization)getVisualization().
            findVisualization(TimeSeriesVisualization.class);
    }
    
    protected JComponent createVisualPanel() {
        return new TimeSeriesVisualPanel(getTimeSeries(), getFilter());
    }

}
