/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.table.visualization;

import infovis.Table;
import infovis.column.NumberColumn;
import infovis.table.visualization.TimeSeriesVisualization;
import infovis.utils.RowIterator;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;

/**
 * Implements the Parallel Coordinates Visualization as
 * described by 
 * A. Inselberg (1985),
 * "The Plane with Parallel Coordinates",
 * Special Issue on Computational Geometry of The Visual Computer 1: 69--97.
 * 
 * @author Pooven Calinghee
 * @version $Revision: 1.2 $
 */
public class ParallelCoordinatesVisualization extends TimeSeriesVisualization {

	/**
	 * Creates a new Parallel Coordinates object.
	 *
	 * @param table the Table to visualize.
	 */
	public ParallelCoordinatesVisualization(Table table) {
		super(table);
	}

	/**
	* @see infovis.visualization.DefaultVisualization#paintBackground(java.awt.Graphics2D, java.awt.geom.Rectangle2D)
	*/
	public void paintBackground(Graphics2D graphics, Rectangle2D bounds) {
		super.paintBackground(graphics, bounds);
		double sx = bounds.getWidth() / (columns.size() - 1);
		graphics.setColor(Color.BLACK);
		for (int i = 0; i < columns.size(); i++) {
			float x = (float) (sx * i + bounds.getX());
			float y = (float) bounds.getY();
			graphics.drawLine(
				(int) x,
				(int) y,
				(int) x,
				(int) bounds.getHeight());
		}
	}

	/**
	 * @see infovis.Visualization#computeShapes(Rectangle2D)
	 */

	public void computeShapes(Rectangle2D bounds) {
		double sx = bounds.getWidth() / (columns.size() - 1);
		for (RowIterator iter = iterator(); iter.hasNext();) {

			int i = iter.nextRow();
			GeneralPath p = (GeneralPath) getShapeAt(i);
			if (p == null) {
				p = new GeneralPath();
			} else {
				p.reset();
			}
			boolean first = true;
			for (int col = 0; col < columns.size(); col++) {
				NumberColumn n = getNumberColumnAt(col);
                                if (n.isValueUndefined(i)) {
                                    first = true;
                                    continue;
                                }
				double min = n.getDoubleMin();
				double max = n.getDoubleMax();
				double diff = (max - min);
				double sy = diff == 0 ? 1 : bounds.getHeight() / diff;
				float x = (float) (sx * col + bounds.getX());
				float h = (float) (sy * (n.getDoubleAt(i) - min));
				float y = (float) (bounds.getY() + bounds.getHeight() - h);

				if (first) {
					p.moveTo(x, y);
					first = false;
				} else {
					p.lineTo(x, y);
				}
			}
			setShapeAt(i, p);
		}
	}

}