/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.table.visualization;

import infovis.Column;
import infovis.Table;
import infovis.column.NumberColumn;
import infovis.panel.ControlPanelFactory;
import infovis.utils.RowIterator;
import infovis.visualization.StrokingVisualization;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.*;

import javax.swing.DefaultListModel;
import javax.swing.ListModel;
import javax.swing.event.ChangeEvent;


/**
 * BasicVisualization component for Time Series
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.25 $
 */
public class TimeSeriesVisualization extends StrokingVisualization {
    private transient Point2D.Double dataBounds;
    protected DefaultListModel columns = new DefaultListModel();

    static {
            ControlPanelFactory.getInstance().setDefault(
                TimeSeriesVisualization.class,
                TimeSeriesControlPanel.class);
        }
    /**
     * Creates a new TimeSeriesVisualization object.
     *
     * @param table the Table to visualize.
     */
    public TimeSeriesVisualization(Table table) {
        super(table);
        showingLabel = false; // we don't want to see the labels
        unselectedColor = null;
        //setDefaultColor(new Color(0, 0, 0.6f, 0.5f));
        addAllDataColumns();
    }

    /**
     * Adds a column.
     *
     * @param c The column.
     */
    public void addDataColumn(NumberColumn c) {
        columns.addElement(c);
        changeManagedColumn(null, null, c);
    }

    /**
     * Removes a column.
     *
     * @param c The column.
     */
    public void removeDataColumn(NumberColumn c) {
        if (columns.removeElement(c)) {
            changeManagedColumn(null, c, null);
        }
    }

    /**
     * Adds all data columns.
     */
    public void addAllDataColumns() {
        columns.clear();
        for (int col = 0; col < table.getColumnCount(); col++) {
            Column c = table.getColumnAt(col);

            if ((c == null) || c.isInternal() ||
                    !(c instanceof NumberColumn)) {
                continue;
            }
            NumberColumn n = (NumberColumn)c;
            addDataColumn(n);
        }
    }

    public int getDataColumnCount() {
        return columns.size();
    }
    
    public ListModel getDataColumnList() {
        return columns;
    }

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public NumberColumn getNumberColumnAt(int index) {
        return (NumberColumn)columns.get(index);
    }
    
    protected Point2D.Double getDataBounds() {
        if (dataBounds == null) {
            double  min = 0;
            double  max = 0;
            boolean first = true;

            for (int i = 0; i < columns.size(); i++) {
                NumberColumn col = getNumberColumnAt(i);

                if (first) {
                    min = col.getDoubleMin();
                    max = col.getDoubleMax();
                    first = false;
                } else {
                    min = Math.min(min, col.getDoubleMin());
                    max = Math.max(max, col.getDoubleMax());
                }
            }

            dataBounds = new Point2D.Double(min, max);
        }

        return dataBounds;
    }

    /**
     * @see infovis.visualization.DefaultVisualization#stateChanged(ChangeEvent)
     */
    public void stateChanged(ChangeEvent e) {
        dataBounds = null;
        super.stateChanged(e);
    }

    /**
     * @see infovis.visualization.DefaultVisualization#paintShape(Graphics2D, int, Shape s)
     */
    public void paintShape(Graphics2D graphics, int row, Shape s) {
    }
    
    /**
     * @see infovis.Visualization#computeShapes(Rectangle2D)
     */
    public void computeShapes(Rectangle2D bounds) {
        Point2D.Double db = getDataBounds();

        double         sx = bounds.getWidth() / (columns.size()-1);
        double         sy = -bounds.getHeight() / (db.getY() - db.getX());
        double         ty = -db.getX();

        for (RowIterator iter = iterator(); iter.hasNext(); ) {
            int i = iter.nextRow();
            GeneralPath p = (GeneralPath)getShapeAt(i);
            if (p == null) {
                p = new GeneralPath();
            }
            else {
                p.reset();
            }
            boolean     first = true;
            for (int col = 0; col < columns.size(); col++) {
                NumberColumn n = getNumberColumnAt(col);
                if (n.isValueUndefined(i)) {
                    first = true;
                    continue;
                }
                float        x = (float)(sx * col + bounds.getX());
                float        y = (float)(bounds.getHeight() + sy * (n.getDoubleAt(i) + ty) +
                                 bounds.getY());

                if (first) {
                    p.moveTo(x, y);
                    first = false;
                } else {
                    p.lineTo(x, y);
                }
            }
            setShapeAt(i, p);
        }
    }
}
