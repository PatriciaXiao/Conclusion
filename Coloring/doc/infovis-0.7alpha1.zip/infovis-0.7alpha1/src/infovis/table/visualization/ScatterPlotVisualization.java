/**
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France
 * -------------------------------------------------------------------------
 * This software is published under the terms of the QPL Software License a
 * copy of which has been included with this distribution in the
 * license-infovis.txt file.
 */
package infovis.table.visualization;

import infovis.Column;
import infovis.Table;
import infovis.column.*;
import infovis.column.filter.NotStringOrNumberFilter;
import infovis.metadata.DependencyMetadata;
import infovis.panel.*;
import infovis.panel.dqinter.*;
import infovis.utils.RowIterator;
import infovis.visualization.DefaultVisualColumn;
import infovis.visualization.DefaultVisualization;

import java.awt.geom.Rectangle2D;

import javax.swing.event.ChangeEvent;

/**
 * Scatter plot visualization.
 * 
 * <p>
 * Visualize a table with a scatter plot representation.
 * </p>
 *
 * Plugin Name: Scatter Plot
 * Plugin Data: infovis.Table 
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.43 $
 */
public class ScatterPlotVisualization extends DefaultVisualization {
    public static final String VISUAL_X_AXIS = "xAxis";
    public static final String VISUAL_Y_AXIS = "yAxis";
    protected NumberColumnBoundedRangeModel xAxisModel;
    protected NumberColumnBoundedRangeModel yAxisModel;
    protected Column xAxisColumn;
    protected Column yAxisColumn;
    protected int margin = 10;
    protected IdColumn idColumn;
    
    //private HashMap orderedIntCols4StrCols = null;

    static {
        ControlPanelFactory.getInstance().setDefault(
            ScatterPlotVisualization.class,
            ScatterPlotControlPanel.class);
    }

    /**
     * Creates a new ScatterPlotVisualization object.
     *
     * @param table the table.
     * @param xAxisColumn the <code>Column</code> for the X Axis
     * @param yAxisColumn the <code>Column</code> for the Y Axis
     */
    public ScatterPlotVisualization(
        Table table,
        Column xAxis,
        Column yAxis) {
        super(table);
        idColumn = new IdColumn();
        setXAxisColumn(xAxis);
        setYAxisColumn(yAxis);
    }

    /**
     * Creates a new ScatterPlotVisualization object.
     *
     * @param table the table.
     * @param xAxisColumn the name of the <code>Column</code> for the X Axis
     * @param yAxisColumn the name of the <code>Column</code> for the Y Axis
     */
    public ScatterPlotVisualization(
        Table table,
        String xAxis,
        String yAxis) {
        this(
            table,
            (Column) table.getColumn(xAxis),
            (Column) table.getColumn(yAxis));
    }

    /**
     * Creates a new ScatterPlotVisualization object. Required columns are
     * searched in the table, taking the first two
     * <code>NumberColumn</code>s as axes.
     *
     * @param table the table.
     */
    public ScatterPlotVisualization(Table table) {
        this(
            table,
            getNumberColumn(table, 0),
            getNumberColumn(table, 1));
	//FIXME
    }

    protected void declareVisualColumns() {
        super.declareVisualColumns();
        putVisualColumn(
            VISUAL_X_AXIS,
            new DefaultVisualColumn(true, NotStringOrNumberFilter.sharedInstance()) {
            public void setColumn(Column column) {
                super.setColumn(column);
                xAxisColumn = column;
                setXAxisModel(null);
            }
        });
        putVisualColumn(
            VISUAL_Y_AXIS,
            new DefaultVisualColumn(true, NotStringOrNumberFilter.sharedInstance()) {
            public void setColumn(Column column) {
                super.setColumn(column);
                yAxisColumn = column;
                setYAxisModel(null);
            }
        });
    }

    /**
     * Returns the nth <code>Column</code> skipping internal columns.
     *
     * @param t the Table.
     * @param index the index of the column, skipping over internal column,
     *
     * @return the nth <code>NumberColumn</code> skipping internal columns.
     */
    public static NumberColumn getNumberColumn(Table t, int index) {
        NumberColumn ret = null;
        for (int i = 0; i < t.getColumnCount(); i++) {
            ret = LiteralColumn.getNumberColumn(t, i);
            if (ret != null && !ret.isInternal() && index-- == 0)
                return ret;
        }
        return null;
    }
    
    public NumberColumn getNumberColumnFor(Column column) {
        if (column == null)
            return idColumn;
        if (column instanceof NumberColumn) {
            return (NumberColumn)column;
        }

        for (int i = 0; i < table.getColumnCount(); i++) {
            Column col = table.getColumnAt(i);
            if (col instanceof NumberColumn
                && DependencyMetadata.isDependentColumn(column, col)) {
                return (NumberColumn)col;
            }
        }
        return ColumnId.findIdColumn(column);
    }

    public void computeShapes(Rectangle2D bounds) {
        double width = bounds.getWidth();
        double height = bounds.getHeight();
        double off = maxSize / 2 + margin;
        double margin2 = 2 * margin;

        if (width <= (maxSize + margin2)
            || height <= (maxSize + margin2))
            return;
            
        idColumn.setSize(getRowCount());
	NumberColumn xCol = getNumberColumnFor(xAxisColumn);
        NumberColumn yCol = getNumberColumnFor(yAxisColumn);
        double xmin =
            xAxisModel == null
                ? xCol.getDoubleMin()
                : xAxisModel.getValue();
        double xmax =
            xAxisModel == null
                ? xCol.getDoubleMax()
                : xmin + xAxisModel.getExtent();
        double xscale =
            (xmax <= xmin)
                ? 1
                : (width - maxSize - margin2) / (xmax - xmin);
        double ymin =
            yAxisModel == null
                ? yCol.getDoubleMin()
                : yAxisModel.getValue();
        double ymax =
            yAxisModel == null
                ? yCol.getDoubleMax()
                : ymin + yAxisModel.getExtent();
        double yscale =
            (ymax <= ymin)
                ? 1
                : (height - maxSize - margin2) / (ymax - ymin);
        //System.out.println("xmin: "+xmin+" xmax: "+xmax+" ymin: "+ymax+" ymax:"+ymax);

        for (RowIterator iter = iterator(); iter.hasNext();) {
            int row = iter.nextRow();
            if (xCol.isValueUndefined(row) || yCol.isValueUndefined(row)) {
                setShapeAt(row, null);
                continue;
            }

            double xpos = (xCol.getDoubleAt(row) - xmin) * xscale + off;
            double ypos =
                height - ((yCol.getDoubleAt(row) - ymin) * yscale + off);
            double s = getSizeAt(row);
            double s2 = s / 2;
            Rectangle2D.Double rect = (Rectangle2D.Double) getShapeAt(row);
            if (rect == null) {
                rect = new Rectangle2D.Double(xpos - s2, ypos - s2, s, s);
                setShapeAt(row, rect);
            }
            else {
                rect.setRect(xpos - s2, ypos - s2, s, s);
            }
        }
    }

    /**
     * Returns the xAxisColumn.
     *
     * @return Column
     */
    public Column getXAxisColumn() {
        return xAxisColumn;
    }

    /**
     * Returns the yAxisColumn.
     *
     * @return Column
     */
    public Column getYAxisColumn() {
        return yAxisColumn;
    }

    /*
     * Sets the xAxisColumn.
     * @param xAxisColumn The xAxisColumn to set.
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setXAxisColumn(Column xAxis) {
        return changeManagedColumn(
            VISUAL_X_AXIS,
            this.xAxisColumn,
            xAxis);
    }

    /**
     * Sets the yAxisColumn.
     *
     * @param yAxisColumn The yAxisColumn to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setYAxisColumn(Column yAxis) {
        return changeManagedColumn(
            VISUAL_Y_AXIS,
            this.yAxisColumn,
            yAxis);
    }

    /**
     * Returns the margin.
     *
     * @return int
     */
    public int getMargin() {
        return margin;
    }

    /**
     * Sets the margin.
     *
     * @param margin The margin to set
     */
    public void setMargin(int margin) {
        this.margin = margin;
        invalidate();
    }

    /**
     * Returns the xAxisModel.
     *
     * @return DoubleBoundedRangeModel
     */
    public DoubleBoundedRangeModel getXAxisModel() {
        return xAxisModel;
    }

    /**
     * Returns the yAxisModel.
     *
     * @return DoubleBoundedRangeModel
     */
    public DoubleBoundedRangeModel getYAxisModel() {
        return yAxisModel;
    }

    /**
     * Sets the xAxisModel.
     *
     * @param xAxisModel The xAxisModel to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setXAxisModel(NumberColumnBoundedRangeModel xAxisModel) {
        if (xAxisModel != null
            && xAxisModel.getColumn() != xAxisColumn)
            return false;
        if (this.xAxisModel != xAxisModel) {
            if (this.xAxisModel != null) {
                this.xAxisModel.removeChangeListener(this);
            }
            this.xAxisModel = xAxisModel;
            if (this.xAxisModel != null) {
                this.xAxisModel.addChangeListener(this);
            }
            invalidate();
            return true;
        }
        return false;
    }

    /**
     * Sets the yAxisModel.
     *
     * @param yAxisModel The yAxisModel to set
     *
     * @return <code>true</code> if the column has been set.
     */
    public boolean setYAxisModel(NumberColumnBoundedRangeModel yAxisModel) {
        if (yAxisModel != null
            && yAxisModel.getColumn() != yAxisColumn)
            return false;
        if (this.yAxisModel != yAxisModel) {
            if (this.yAxisModel != null) {
                this.yAxisModel.removeChangeListener(this);
            }
            this.yAxisModel = yAxisModel;
            if (this.yAxisModel != null) {
                this.yAxisModel.addChangeListener(this);
            }
            invalidate();
            return true;
        }
        return false;
    }

    /**
     * @see infovis.visualization.DefaultVisualization#stateChanged(ChangeEvent)
     */
    public void stateChanged(ChangeEvent e) {
        if (e.getSource() == xAxisModel
            || e.getSource() == yAxisModel) {
            invalidate();
        }
        else {
            super.stateChanged(e);
        }
    }
}
