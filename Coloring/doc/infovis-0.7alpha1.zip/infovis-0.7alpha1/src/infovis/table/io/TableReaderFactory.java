/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.table.io;

import infovis.Table;
import infovis.io.AbstractReader;
import infovis.io.AbstractReaderFactory;
import infovis.tree.DefaultTree;
import infovis.tree.io.DirectoryTreeReader;

import java.io.*;


/**
 * Factory of table readers.
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.13 $
 */
public class TableReaderFactory extends AbstractReaderFactory {
    static TableReaderFactory instance = new TableReaderFactory();

    protected void addDefaultCreators() {
	add(new AbstractCreator("csv") {
		public AbstractReader create(BufferedReader in, String name,
                                             Table table) {
		    return new CSVTableReader(in, name, table);
		}
	    });
	add(new AbstractCreator("tqd") {
		public AbstractReader create(BufferedReader in, String name,
                                             Table table) {
		    return new TQDTableReader(in, name, table);
		}
	    });
	add(new Creator() {
                public String getName() {
                    return "directory";
                }
		public AbstractReader create(String name,
					     Table table) {
		    File f = new File(name);
		    if (! f.isDirectory()) 
			return null;
		    return new DirectoryTreeReader(name, DefaultTree.findTree(table));
		}
                public AbstractReader create(BufferedReader in, String name,
                                             Table table) {
                    return create(name, table);
                }
	    });
    }
	
    public static TableReaderFactory getInstance() {
	return instance;
    }
	public static void setInstance(TableReaderFactory table){
			instance= table;
		}
	
    public static AbstractReader createTableReader(String name, Table table) {
	return getInstance().create(name, table);
    }
    
    public static boolean readTable(String name, Table table) {
        return getInstance().tryRead(name, table);
    }
}
