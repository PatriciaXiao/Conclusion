/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.table;

import infovis.Column;
import infovis.Table;
import infovis.utils.RowIterator;
import infovis.utils.TableIterator;

import java.text.ParseException;
import java.util.*;

import javax.swing.event.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;


/**
 * Concrete Table.
 *
 * Implements all the methods of <code>Table</code> managing a
 * ArrayList of columns.
 * 
 * TODO:
 * Implements notification by registering to columns
 * only when a listener is installed.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.19 $
 */
public class DefaultTable implements Table, ChangeListener {
    ArrayList column;
    String    name;
    ArrayList listenerList;
    Map       metadata;
    Map       clientPropery;

    /**
     * Creates a new DefaultTable object.
     */
    public DefaultTable() {
        column = new ArrayList();
        //listenerList = new ArrayList();
    }

    // interface Metadata
    /**
     * Returns the clientPropery.
     * @return Map the clientPropery map.
     */
    public Map getClientPropery() {
        if (clientPropery == null) {
            clientPropery = new HashMap();
        }
        return clientPropery;
    }

    /**
     * Returns the metadata.
     * @return Map the metadata map.
     */
    public Map getMetadata() {
        if (metadata == null) {
            metadata = new HashMap();
        }
        return metadata;
    }

    // interface Table

    /**
     * @see infovis.Table#getName()
     */
    public String getName() {
        return name;
    }

    /**
     * @see infovis.Table#setName(String)
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @see Table#getColumnCount()
     */
    public int getColumnCount() {
        return column.size();
    }

    /**
     * @see Table#clear()
     */
    public void clear() {
        for (int i = 0; i < getColumnCount(); i++) {
            getColumnAt(i).clear();
        }
        if (metadata != null) {
            metadata.clear();
        }
        if (clientPropery != null) {
            clientPropery.clear();
        }

        fireTableStructureChanged();
    }


    /**
     * @see Table#addColumn(Column)
     */
    public void addColumn(Column c) {
        column.add(c);
        if (listenerList != null) {
            c.addChangeListener(this);
        }
        fireTableStructureChanged();
    }

    /**
     * @see Table#getColumnAt(int)
     */
    public Column getColumnAt(int index) {
        if (index < 0 || index >= getColumnCount())
            return null;
        return (Column)column.get(index);
    }

    /**
     * @see Table#setColumnAt(int,Column)
     */
    public void setColumnAt(int i, Column c) {
        if (listenerList != null) {
            Column old = getColumnAt(i);
            if (old != c) {
                old.removeChangeListener(this);
            }
        }
        column.set(i, c);
        if (listenerList != null) {
            c.addChangeListener(this);
        }
        fireTableStructureChanged();
    }

    /**
     * @see Table#indexOf(String)
     */
    public int indexOf(String name) {
        for (int i = 0; i < getColumnCount(); i++) {
            Column col = getColumnAt(i);
            if (col.getName().equals(name))
                return i;
        }
        return -1;
    }

    /**
     * @see infovis.Table#indexOf(Column)
     */
    public int indexOf(Column column) {
        for (int i = 0; i < getColumnCount(); i++) {
            Column col = getColumnAt(i);
            if (col == column)
                return i;
        }
        return -1;
    }

    /**
     * @see Table#getColumn(String)
     */
    public Column getColumn(String name) {
        for (int i = 0; i < getColumnCount(); i++) {
            Column col = getColumnAt(i);
            if (col.getName().equals(name))
                return col;
        }
        return null;
    }

    /**
     * @see Table#remove(Column)
     */
    public boolean remove(Column c) {
        if (listenerList != null) {
            c.removeChangeListener(this);
        }
        if (column.remove(c)) {
            fireTableStructureChanged();
            return true;
        }
        return false;
    }
    /**
     * @see infovis.Table#iterator()
     */
    public RowIterator iterator() {
        return new TableIterator(0, getRowCount(), true);
    }

    public RowIterator reverseIterator() {
        return new TableIterator(getRowCount()-1, -1, false);
    }

    /**
     * @see infovis.Table#getTable()
     */
    public Table getTable() {
        return this;
    }
    
    /**
     * @see infovis.Table#isRowValid(int)
     */
    public boolean isRowValid(int row) {
        return row >= 0 && row < getRowCount();
    }


    // interface TableModel

    /**
     * @see javax.swing.table.TableModel#getColumnName(int)
     */
    public String getColumnName(int columnIndex) {
        return getColumnAt(columnIndex).getName();
    }

    /**
     * @see javax.swing.table.TableModel#getRowCount()
     */
    public int getRowCount() {
        int max = 0;
        for (int index = 0; index < getColumnCount(); index++) {
            int r = getColumnAt(index).getRowCount();
            if (r > max)
                max = r;
        }

        return max;
    }

    /**
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     */
    public Object getValueAt(int rowIndex, int columnIndex) {
        return getColumnAt(columnIndex).getValueAt(rowIndex);
    }

    /**
     *  <code>TableModel</code> method for editable tables.
     *
     *  @param  aValue   value to assign to cell
     *  @param  rowPosition   row of cell
     *  @param  columnPosition  column of cell
     *
     * @see javax.swing.table.TableModel#setValueAt(Object, int, int)
     */
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        try {
            getColumnAt(columnIndex).setValueAt(rowIndex, (String)aValue);
        } catch (ParseException e) {
        }
    }

    /**
     * @see javax.swing.table.TableModel#getColumnClass(int)
     */
    public Class getColumnClass(int columnIndex) {
        return String.class;
    }

    /**
     * @see javax.swing.table.TableModel#isCellEditable(int, int)
     */
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    protected ArrayList getListenerList() {
        if (listenerList == null) {
            listenerList = new ArrayList();
        }
        return listenerList;
    }
    
    /**
     * @see javax.swing.table.TableModel#addTableModelListener(TableModelListener)
     */
    public void addTableModelListener(TableModelListener l) {
        if (listenerList == null) {
            registerColumnListeners();
        }
        getListenerList().add(l);
    }

    /**
     * @see javax.swing.table.TableModel#removeTableModelListener(TableModelListener)
     */
    public void removeTableModelListener(TableModelListener l) {
        if (listenerList == null) return;
        getListenerList().remove(l);
        if (listenerList.isEmpty()) {
            unregisterColumnListeners();
            listenerList = null;
        }
    }

    // Implementation specific methods

    /**
     * Test if the column is internal, i.e. the first character of its name is a '#'.
     *
     * @param col the column.
     *
     * @return <code>true</code>
     *  if the column is internal, i.e. the first character of its name is a '#'.
     */
    public static boolean isColumnInternal(Column col) {
        return col.getName().charAt(0) == INTERNAL_PREFIX;
    }

    // TableModel implementation


    /**
     * Notifies all listeners that all cell values in the table's
     * rows may have changed. The number of rows may also have changed
     * and the <code>JTable</code> should redraw the
     * table from scratch. The structure of the table (as in the order of the
     * columns) is assumed to be the same.
     *
     * @see TableModelEvent
     * @see javax.swing.event.EventListenerList
     * @see javax.swing.JTable#tableChanged(TableModelEvent)
     */
    public void fireTableDataChanged() {
        if (listenerList == null) return;
        fireTableChanged(new TableModelEvent(this));
    }

    /**
     * Notifies all listeners that the table's structure has changed.
     * The number of columns in the table, and the names and types of
     * the new columns may be different from the previous state.
     * If the <code>JTable</code> receives this event and its
     * <code>autoCreateColumnsFromModel</code>
     * flag is set it discards any table columns that it had and reallocates
     * default columns in the order they appear in the model. This is the
     * same as calling <code>setModel(TableModel)</code> on the
     * <code>JTable</code>.
     *
     * @see TableModelEvent
     * @see javax.swing.event.EventListenerList
     */
    public void fireTableStructureChanged() {
        if (listenerList == null) return;
        fireTableChanged(new TableModelEvent(this, TableModelEvent.HEADER_ROW));
    }

    /**
     * Forwards the given notification event to all
     * <code>TableModelListeners</code> that registered
     * themselves as listeners for this table model.
     *
     * @param e  the event to be forwarded
     *
     * @see #addTableModelListener
     * @see TableModelEvent
     * @see javax.swing.event.EventListenerList
     */
    public void fireTableChanged(TableModelEvent e) {
        if (listenerList == null) return;
        for (int i = listenerList.size() - 1; i >= 0; i--) {
            TableModelListener l = (TableModelListener)listenerList.get(i);
            l.tableChanged(e);
        }
    }
    
    public void stateChanged(ChangeEvent e) {
        if (e.getSource() instanceof Column) {
            Column c = (Column) e.getSource();
            int col = indexOf(c);
            if (col != -1) {
                fireTableChanged(new TableModelEvent(this, 0, c.getRowCount(), col));
                return;
            }
        }
    }

    protected void registerColumnListeners() {
        for (int i = 0; i < column.size(); i++) {
            Column c = getColumnAt(i);
            c.addChangeListener(this);
        }
    }

    protected void unregisterColumnListeners() {
        for (int i = 0; i < column.size(); i++) {
            Column c = getColumnAt(i);
            c.removeChangeListener(this);
        }
    }
    
}
