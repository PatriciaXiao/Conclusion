/**
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France
 * -------------------------------------------------------------------------
 * This software is published under the terms of the QPL Software License
 * a copy of which has been included with this distribution in the
 * license-infovis.txt file.
 */
package infovis.table;

import infovis.Column;
import infovis.Table;
import infovis.utils.RowIterator;

import java.util.Map;

import javax.swing.event.TableModelListener;


/**
 * A Table Proxy implements an <code>Table</code> by forwarding all
 * the methods to an internal <code>Table</code>.
 * 
 * <p>This class is useful to
 * implements higher level containers out of a standard
 * <code>DefaultTable</code>.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.16 $
 */
public class TableProxy implements Table {
    protected Table table;

    /**
     * Creates a new TableProxy object.
     *
     * @param table The underlying table.
     *
     * @see infovis.Table#getTable()
     */
    public TableProxy(Table table) {
        this.table = table;
    }

    /**
     * @see infovis.Metadata#getClientPropery()
     */
    public Map getClientPropery() {
        return table.getClientPropery();
    }

    /**
     * @see infovis.Metadata#getMetadata()
     */
    public Map getMetadata() {
        return table.getMetadata();
    }

    /**
     * @see infovis.Table#getName()
     */
    public String getName() {
        return table.getName();
    }

    /**
     * @see infovis.Table#setName(String)
     */
    public void setName(String name) {
        table.setName(name);
    }

    /**
     * @see infovis.Table#getColumnCount()
     */
    public int getColumnCount() {
        return table.getColumnCount();
    }

    /**
     * @see infovis.Table#clear()
     */
    public void clear() {
        table.clear();
    }

    /**
     * @see infovis.Table#addColumn(Column)
     */
    public void addColumn(Column c) {
        table.addColumn(c);
    }

    /**
     * @see infovis.Table#getColumnAt(int)
     */
    public Column getColumnAt(int index) {
        return table.getColumnAt(index);
    }

    /**
     * @see infovis.Table#setColumnAt(int, Column)
     */
    public void setColumnAt(int i, Column c) {
        table.setColumnAt(i, c);
    }

    /**
     * @see infovis.Table#indexOf(String)
     */
    public int indexOf(String name) {
        return table.indexOf(name);
    }

    /**
     * @see infovis.Table#indexOf(Column)
     */
    public int indexOf(Column column) {
        return table.indexOf(column);
    }

    /**
     * @see infovis.Table#getColumn(String)
     */
    public Column getColumn(String name) {
        return table.getColumn(name);
    }

    /**
     * @see infovis.Table#remove(Column)
     */
    public boolean remove(Column c) {
        return table.remove(c);
    }

    /**
     * @see infovis.Table#iterator()
     */
    public RowIterator iterator() {
        return table.iterator();
    }

    /**
     * Returns the table.
     *
     * @return Table
     */
    public Table getTable() {
        return table.getTable();
    }
    
    /**
     * @see infovis.Table#isRowValid(int)
     */
    public boolean isRowValid(int row) {
        return table.isRowValid(row);
    }

    // interface TableModel
    /**
     * @see javax.swing.table.TableModel#getColumnName(int)
     */
    public String getColumnName(int columnIndex) {
        return table.getColumnName(columnIndex);
    }

    /**
     * @see javax.swing.table.TableModel#getRowCount()
     */
    public int getRowCount() {
        return table.getRowCount();
    }

    /**
     * @see javax.swing.table.TableModel#getValueAt(int, int)
     */
    public Object getValueAt(int rowIndex, int columnIndex) {
        return table.getValueAt(rowIndex, columnIndex);
    }

    /**
     * @see javax.swing.table.TableModel#setValueAt(Object, int, int)
     */
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        table.setValueAt(aValue, rowIndex, columnIndex);
    }

    /**
     * @see javax.swing.table.TableModel#getColumnClass(int)
     */
    public Class getColumnClass(int columnIndex) {
        return table.getColumnClass(columnIndex);
    }

    /**
     * @see javax.swing.table.TableModel#isCellEditable(int, int)
     */
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return table.isCellEditable(rowIndex, columnIndex);
    }

    /**
     * @see javax.swing.table.TableModel#addTableModelListener(TableModelListener)
     */
    public void addTableModelListener(TableModelListener l) {
        table.addTableModelListener(l);
    }

    /**
     * @see javax.swing.table.TableModel#removeTableModelListener(TableModelListener)
     */
    public void removeTableModelListener(TableModelListener l) {
        table.removeTableModelListener(l);
    }
    public RowIterator reverseIterator() {
        return table.reverseIterator();
    }

}
