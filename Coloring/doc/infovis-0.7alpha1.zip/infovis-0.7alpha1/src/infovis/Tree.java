/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis;

import infovis.tree.TreeChangedListener;
import infovis.utils.RowIterator;


/**
 * Base proxy for considering a table as a tree structure.
 *
 * <p>A tree references a table and make sure it has the topological
 * information stored as four columns.  An index represents a node
 * number, with all associated values stored in the columns.  The four
 * internal columns are: <ul> <li>child: the index of the first child
 * for a given node <li>next: the next sibling node <li>last: the
 * index of the last child for a given node <li>parent: the index of
 * the parent for a given node.  </ul></p>
 *
 * @version $Revision: 1.30 $
 * @author Jean-Daniel Fekete
 */
public interface Tree extends Table {
    /** Metadata to get the tree from the table */
    public static final String TREE_METADATA = "tree";

    /** Value of the tree's ROOT */
    public static final int ROOT = 0;

    /**
     * Returns the nth child of a node.
     *
     * @param node the node
     * @param index the index if the requested child
     *
     * @return the requested child or NIL if node has not so many children.
     */
    public int getChild(int node, int index);

    /**
     * Returns the parent of a node.
     *
     * @param node the node
     *
     * @return the parent or the NIL value if node is the top node
     */
    public int getParent(int node);

    /**
     * Returns the iterator over the children of a node.
     *
     * @param node the node
     *
     * @return the iterator over the children of the node
     */
    public RowIterator childrenIterator(int node);

    /**
     * Adds a node to the tree.
     *
     * @param par the parent of the node.
     *
     * @return the created node.
     *
     * @throws ArrayIndexOutOfBoundsException DOCUMENT ME!
     */
    public int addNode(int par);
    
    /**
     * Removes a node from the tree.
     * 
     * @param node the node to remove
     * @return true if the node has been removed.
     */
    public boolean removeNode(int node);
    
    /**
     * Returns the number of proper nodes in the Tree.
     * Can be different than the value returned by getRowCount if
     * nodes have been removed.
     * 
     * @return the number of proper nodes in the Tree.
     */
    public int getNodeCount();

    /**
     * Returns the next node to be returned by addNode.
     *
     * @return the next node to be returned by addNode.
     */
    public int nextNode();

    /**
     * Change the parent of a specified node, changing the structure.
     *
     * @param node the node.
     * @param newparent the new parent.
     *
     * @throws RuntimeException if the node is an ancestor of the parent.
     */
    public void reparent(int node, int newparent);
    
    /**
     * Returns true if the first node has the second node as ancestor.
     *
     * @param node the node.
     * @param par the tested ancestor.
     *
     * @return true if the first node has the second node as ancestor.
     */
    public boolean isAncestor(int node, int par);

    /**
     * Returns the depth of a node using either a depth column if it has been computed or
     * the computeDepth method.
     *
     * @param node the node.
     *
     * @return the depth of the node.
     */
    public int getDepth(int node);

    /**
     * Returns the degree of a node using either a degree column if it has been computed or
     * the computeDegree method.
     *
     * @param node the node.
     *
     * @return the depth of the node.
     */
    public int getDegree(int node);

    /**
     * Returns true if the node is a leaf_node. Use this method rather than
     * degree(node)==0
     *
     * @param node the node
     *
     * @return true if the node is a leaf_node.
     */
    public boolean isLeaf(int node);
    

    /**
     * Attaches a TreeChangedListener to the tree
     *  
     * @param l the TreeChangedListener to notify when the tree structure changes.
     */
    public void addTreeChangedListener(TreeChangedListener l);
    
    /**
     * Removes a TreeChangedListener from the graph
     *  
     * @param l the TreeChangedListener to remove
     */
    public void removeTreeChangedListener(TreeChangedListener l);    
}
