/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.tree;

import infovis.Tree;

/**
 * Class TreeChangedEvent
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class TreeChangedEvent {
    protected Tree tree;
    protected int node;
    protected short type;
    
    public static final short TREE_NODE_ADDED = 0;
    public static final short TREE_NODE_REMOVED = 1;
    public static final short TREE_NODE_MOVED = 2;
    
    public TreeChangedEvent(Tree tree, int node, short type) {
        this.tree = tree;
        this.node = node;
        this.type = type;
    }

    public int getNode() {
        return node;
    }

    public Tree getTree() {
        return tree;
    }

    public short getType() {
        return type;
    }

}
