/**
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France
 * -------------------------------------------------------------------------
 * This software is published under the terms of the QPL Software License a
 * copy of which has been included with this distribution in the
 * license-infovis.txt file.
 */
package infovis.tree.visualization;

import infovis.Tree;
import infovis.column.BooleanColumn;
import infovis.column.FilterColumn;
import infovis.utils.RowIterator;

import java.awt.geom.Rectangle2D;

/**
 * Node Link Diagram Visualization of Trees with Polar Coordinates.
 *
 * @author Pooven Calinghee
 * @version $Revision: 1.1 $
 */
public class NodeLinkTreeVisualizationPolar extends NodeLinkTreeVisualization {

	/**
	 * Constructor for NodeLinkTreeVisualizationPolar.
	 *
	 * @param tree
	 */
	public NodeLinkTreeVisualizationPolar(Tree tree) {
		this(tree, null, null);
	}

	/**
	 * Constructor for NodeLinkTreeVisualizationPolar.
	 *
	 * @param tree
	 * @param selection
	 * @param filter
	 */
	public NodeLinkTreeVisualizationPolar(
		Tree tree,
		BooleanColumn selection,
		FilterColumn filter) {
		super(tree, selection, filter);
	}

	/**
	 * Recompute the tree scale so that it fits inside
	 * its specified bounds.
	 * Transform the tree into a radial layout while
	 * resizing it.
	 */
	protected void rescaleTree(Rectangle2D bounds) {
		double sx = bounds.getWidth() / bbox.width;
		double sy = bounds.getHeight() / bbox.height;
		double scale = (sx < sy) ? sx : sy;
		double diameter =
			(bounds.getHeight() <= bounds.getWidth())
			? bounds.getHeight() : bounds.getWidth();
		double cx = bounds.getWidth() / 2;
		double cy = bounds.getHeight() / 2;

		if (scale > 1)
			scale = 1;
		for (RowIterator iter = iterator(); iter.hasNext();) {
			int row = iter.nextRow();
			Rectangle2D.Float rect = (Rectangle2D.Float) getShapeAt(row);
			if (rect == null) {
				continue;
			}
			
			double r = (rect.y - bbox.y) * diameter * 0.5 / bbox.height;
			double t = (rect.x - bbox.x) * 2 * Math.PI / bbox.width;

			rect.x = (float)(r * Math.cos(t) + cx + bounds.getX());
			rect.y = (float)(r * Math.sin(t) + cy + bounds.getY());
			rect.width *= (float)scale;
			rect.height *= (float)scale;

		}
	}

}
