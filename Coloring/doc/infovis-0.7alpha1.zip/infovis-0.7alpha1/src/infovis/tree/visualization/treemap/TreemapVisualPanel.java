/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.tree.visualization.treemap;

import infovis.Visualization;
import infovis.column.ColumnFilter;
import infovis.tree.visualization.TreeVisualPanel;
import infovis.tree.visualization.TreemapVisualization;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.*;
import javax.swing.event.ListDataEvent;

/**
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.5 $
 */
public class TreemapVisualPanel extends TreeVisualPanel {
    JComboBox algorithmCombo;

    /**
     * Constructor for TreemapVisualPanel.
     * @param visualization
     * @param filter
     */
    public TreemapVisualPanel(Visualization visualization, ColumnFilter filter) {
        super(visualization, filter);
    }
    
    public TreemapVisualization getTreemapVisualization() {
        return (TreemapVisualization)getVisualization()
            .findVisualization(TreemapVisualization.class);
    }
    
    /**
     * @see infovis.panel.DefaultVisualPanel#createAll(Visualization)
     */
    protected void createAll() {
        super.createAll();
        addAlgorithmCombo();
    }

    protected void addAlgorithmCombo() {
        algorithmCombo = new JComboBox();
        algorithmCombo.setRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(
                JList list,
                Object value,
                int index,
                boolean isSelected,
                boolean cellHasFocus) {
                Treemap treemap = (Treemap)value;
                return super.getListCellRendererComponent(list, treemap.getName(), index, isSelected, cellHasFocus);
            }
        });
        algorithmCombo.setBorder(BorderFactory.createTitledBorder("Treemap Algorithm"));
        algorithmCombo.setMaximumSize(new Dimension(Integer.MAX_VALUE,
                                           (int)algorithmCombo.getPreferredSize()
                                                     .getHeight()));

        addAlgorithm(SliceAndDice.SLICEANDDICE);
        addAlgorithm(Squarified.SQUARIFIED);
        addAlgorithm(Strip.STRIP);
        algorithmCombo.getModel().setSelectedItem(getTreemapVisualization().getTreemap());                                                     
        algorithmCombo.getModel().addListDataListener(this);
        add(algorithmCombo);
    }
    
    protected void addAlgorithm(Treemap treemap) {
        
        DefaultComboBoxModel model = (DefaultComboBoxModel)algorithmCombo.getModel();
        
        model.addElement(treemap);
    }

    /**
     * @see infovis.panel.DefaultVisualPanel#contentsChanged(ListDataEvent)
     */
    public void contentsChanged(ListDataEvent e) {
        if (e.getSource() == algorithmCombo.getModel()
            && e.getType() == ListDataEvent.CONTENTS_CHANGED) {
            getTreemapVisualization().setTreemap((Treemap)algorithmCombo.getSelectedItem());
        }
        else
            super.contentsChanged(e);
    }

}
