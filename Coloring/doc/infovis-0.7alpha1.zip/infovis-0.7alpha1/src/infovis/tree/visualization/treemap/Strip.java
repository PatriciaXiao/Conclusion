/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.tree.visualization.treemap;

/**
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.4 $
 */
public class Strip extends Squarified {
    public static final Strip STRIP = new Strip();
    
    /**
     * Constructor for Strip.
     */
    protected Strip() {
    }
    
    /**
     * @see infovis.tree.visualization.treemap.Squarified#getName()
     */
    public String getName() {
        return "Strip";
    }

    /**
     * @see infovis.tree.visualization.treemap.Squarified#isVertical(double, double, double, double, int)
     */
    protected boolean isVertical(
        double xmin,
        double ymin,
        double xmax,
        double ymax,
        int node) {
        return false;
    }

}
