/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.tree.visualization;

import infovis.Tree;
import infovis.column.*;
import infovis.metadata.AdditiveAggregation;
import infovis.metadata.ValueCategory;
import infovis.panel.ControlPanelFactory;
import infovis.tree.Algorithms;
import infovis.tree.DepthFirst;
import infovis.utils.IntVector;

import java.awt.Color;
import java.awt.geom.Rectangle2D;

/**
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.7 $
 */
public class IcicleTreeVisualization extends TreeVisualization {
    float minItemHeight = 20;
    int maxDepth;
    IntColumn rainbow;

    static {
        ControlPanelFactory.getInstance().setDefault(
            IcicleTreeVisualization.class, IcicleTreeControlPanel.class);
    }
    
    /**
     * Constructor for IcicleTreeVisualization.
     * @param tree
     */
    public IcicleTreeVisualization(Tree tree) {
        super(tree);
        setVisualColumn(VISUAL_SIZE, AdditiveAggregation.findDegreeColumn(tree));
        rainbow = new IntColumn("#rainbow");
        ValueCategory.setValueCategory(rainbow, ValueCategory.TYPE_EXPLICIT);
        setVisualColumn(VISUAL_COLOR, rainbow);
        maxDepth = Algorithms.treeDepth(tree);
    }

    /**
     * Constructor for IcicleTreeVisualization.
     * @param tree
     * @param selection
     * @param filter
     */
    public IcicleTreeVisualization(
        Tree tree,
        BooleanColumn selection,
        FilterColumn filter) {
        super(tree, selection, filter);
        setVisualColumn(VISUAL_SIZE, AdditiveAggregation.findDegreeColumn(tree));
        maxDepth = Algorithms.treeDepth(tree);
    }

    /**
     * @see infovis.Visualization#computeShapes(Rectangle2D)
     */
    public void computeShapes(Rectangle2D bounds) {
        float scaleX = 1;
        float scaleY = 1;
        
        switch(orientation) {
        case ORIENTATION_NORTH:
        case ORIENTATION_SOUTH:
            scaleX = (float)bounds.getWidth() / sizeColumn.getIntAt(Tree.ROOT);
            scaleY = (float)bounds.getHeight() / maxDepth;
            break;
        case ORIENTATION_EAST:
        case ORIENTATION_WEST:
            scaleX = (float)bounds.getHeight() / sizeColumn.getIntAt(Tree.ROOT);
            scaleY = (float)bounds.getWidth() / maxDepth;
            break;
        }
        IcicleVisitor visitor = new IcicleVisitor(scaleX, scaleY);
        DepthFirst.visit(tree, visitor, Tree.ROOT);
    }

    
    class IcicleVisitor implements DepthFirst.Visitor {
        IntVector positions = new IntVector();
        float width;
        float height;
        int depth = 0;
        
        public IcicleVisitor(float width, float height) {
            this.width = width;
            this.height = height;
            positions.push(0);
            depth = -1;
            maxDepth = Algorithms.treeDepth(tree);
        }
        
        public int getPosition() {
            return positions.top();
        }
        
        void push() {
            positions.push(getPosition());
            depth++;
        }
        
        void pop() {
            positions.pop();
            depth--;
        }
        
        void setPosition(int pos) {
            positions.setTop(pos);
        }
        
        /**
         * @see infovis.tree.DepthFirst.Visitor#preorder(int)
         */
        public boolean preorder(int node) {
            push();
            int position = getPosition();
            Rectangle2D.Float rect = (Rectangle2D.Float)getShapeAt(node);
            if (rect == null) {
                rect = new Rectangle2D.Float();
                setShapeAt(node, rect);
            }
            int dp = sizeColumn.getIntAt(node);
            int color = Color.HSBtoRGB((position + (float)dp/2)/sizeColumn.getIntAt(Tree.ROOT),
                1.0f, 1.0f);
            rainbow.setExtend(node, color);
            switch(orientation) {
            case ORIENTATION_NORTH:
                rect.x = position * width;
                rect.y = (maxDepth-depth - 1) * height;
                rect.width = dp * width;
                rect.height = height;
                break;
            case ORIENTATION_SOUTH:
                rect.x = position * width;
                rect.y = depth * height;
                rect.width = dp * width;
                rect.height = height;
                break;
            case ORIENTATION_WEST:
                rect.y = position * width;
                rect.x = (maxDepth - depth - 1) * height;
                rect.height = dp * width;
                rect.width = height;
                break;
            case ORIENTATION_EAST:
                rect.y = position * width;
                rect.x = depth * height;
                rect.height = dp * width;
                rect.width = height;
                break;
            }
            return true;
        }
        
        /**
         * @see infovis.tree.DepthFirst.Visitor#inorder(int)
         */
        public void inorder(int node) {
        }
        /**
         * @see infovis.tree.DepthFirst.Visitor#postorder(int)
         */
        public void postorder(int node) {
            pop();
            int position = getPosition();
            position += sizeColumn.getIntAt(node);
            setPosition(position);
        }

    }
}
