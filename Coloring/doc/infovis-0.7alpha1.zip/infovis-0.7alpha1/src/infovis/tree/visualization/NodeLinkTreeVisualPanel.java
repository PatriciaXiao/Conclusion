/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.tree.visualization;

import infovis.Visualization;
import infovis.column.ColumnFilter;

import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * Class NodeLinkTreeVisualPanel
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.4 $
 */
public class NodeLinkTreeVisualPanel extends TreeVisualPanel {
    protected JSlider siblingSepSlider;
    protected JSlider subtreeSepSlider;
    protected JSlider levelSepSlider;
    
    public NodeLinkTreeVisualPanel(Visualization visualization, ColumnFilter filter) {
        super(visualization, filter);
    }
    
    public NodeLinkTreeVisualization getNodeLinkTreeVisualization() {
        return (NodeLinkTreeVisualization)getVisualization()
            .findVisualization(NodeLinkTreeVisualization.class);
    }

    protected void createAll() {
        super.createAll();
        addParameterControls();
    }
    
    protected void addParameterControls() {
        siblingSepSlider = new JSlider(0, 50,
            (int)getNodeLinkTreeVisualization().getSiblingSeparation());
        siblingSepSlider.setPaintLabels(true);
        siblingSepSlider.setPaintTicks(true);
        siblingSepSlider.setMajorTickSpacing(10);
        siblingSepSlider.setMinorTickSpacing(5);
        siblingSepSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                getNodeLinkTreeVisualization().setSiblingSeparation(
                    siblingSepSlider.getValue());
                getVisualization().invalidate();
            }
        });
        setTitleBorder(siblingSepSlider, "Sibling Separator");
        add(siblingSepSlider);
        
        subtreeSepSlider = new JSlider(0, 100,
            (int)getNodeLinkTreeVisualization().getSubtreeSeparation());
        subtreeSepSlider.setPaintLabels(true);
        subtreeSepSlider.setPaintTicks(true);
        subtreeSepSlider.setMajorTickSpacing(50);
        subtreeSepSlider.setMinorTickSpacing(10);
        subtreeSepSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                getNodeLinkTreeVisualization().setSubtreeSeparation(
                    subtreeSepSlider.getValue());
                getVisualization().invalidate();
            }
        });
        setTitleBorder(subtreeSepSlider, "Subtree Separator");
        add(subtreeSepSlider);
        
        levelSepSlider = new JSlider(0, 100,
            (int)getNodeLinkTreeVisualization().getLevelSeparation());
        levelSepSlider.setPaintLabels(true);
        levelSepSlider.setPaintTicks(true);
        levelSepSlider.setMajorTickSpacing(50);
        levelSepSlider.setMinorTickSpacing(10);
        levelSepSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                getNodeLinkTreeVisualization().setLevelSeparation(
                    levelSepSlider.getValue());
                getVisualization().invalidate();
            }
        });
        setTitleBorder(levelSepSlider, "Level Separator");
        add(levelSepSlider);
    }
}
