/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.tree.visualization;

import infovis.Column;
import infovis.Tree;
import infovis.column.*;
import infovis.metadata.*;
import infovis.panel.ControlPanelFactory;
import infovis.tree.*;
import infovis.tree.DefaultTree;
import infovis.tree.DepthFirst;
import infovis.utils.*;
import infovis.visualization.DefaultVisualization;
import infovis.visualization.VisualColumnProxy;

import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

/**
 * Abstract base class for tree visualizations.
 *
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.22 $
 */
public abstract class TreeVisualization
    extends DefaultVisualization
    implements Tree, DepthFirst.Visitor {
    public static final String SORTEDCHILDREN_COLUMN =
        "#sortedChildren";
    protected Tree tree;
    protected int root;
    volatile Graphics2D graphics;
    protected ObjectColumn sortedChildren;

    static {
        ControlPanelFactory.getInstance().setDefault(
            TreeVisualization.class,
            TreeControlPanel.class);
    }

    /**
     * Constructor for TreeVisualization.
     * @param tree the Tree.
     */
    public TreeVisualization(Tree tree) {
        this(tree, null, null);
    }

    public TreeVisualization(
        Tree tree,
        BooleanColumn selection,
        FilterColumn filter) {
        super(tree, selection, filter);
        this.tree = tree;
        if (tree instanceof DefaultTree) {
            DefaultTree dtree = (DefaultTree) tree;
            dtree.createDegreeColumn();
            dtree.createDepthColumn();
        }
        this.root = Tree.ROOT;
        this.sortedChildren =
            ObjectColumn.findColumn(tree, SORTEDCHILDREN_COLUMN);
    }

    protected void declareVisualColumns() {
        super.declareVisualColumns();
        ColumnFilter filter =
            new AdditiveAggregation.NonAdditiveFilter(tree);
        setVisualColumnFilter(VISUAL_SORT, filter);
        putVisualColumn(
            VISUAL_SORT,
            new VisualColumnProxy(
                getVisualColumnDescriptor(VISUAL_SORT)) {
            public void setColumn(Column sortColumn) {
                if (sortColumn != null) {
                    Aggregation aggr = null;
                    if (AtLeafAggregation.isAtLeaf(sortColumn, tree)
                        == Aggregation.AGGREGATE_YES) {
                        // choose additive aggregation as default, doesn't make sense for dates
                        aggr = AdditiveAggregation.sharedInstance();
                    }
                    else {
                        AggregationCategory factory =
                            AggregationCategory.sharedInstance();
                        aggr = factory.getAggregation(sortColumn, TreeVisualization.this);
                    }
                    if (aggr != null) {
                        Column col =
                            aggr.aggregate(sortColumn, TreeVisualization.this, null);
                        if (col != null) {
                            sortColumn = col;
                        }
                    }
                }
                super.setColumn(sortColumn);
            }
        });
    }

    /**
     * Returns the tree.
     * @return Tree
     */
    public Tree getTree() {
        return tree;
    }

    /**
     * @see infovis.tree.DepthFirst.Visitor#preorder(int)
     */
    public boolean preorder(int node) {
        if (!isFiltered(node)) {
            paintItem(graphics, node);
        }
        return true;
    }

    /**
    * @see infovis.tree.DepthFirst.Visitor#inorder(int)
    */
    public void inorder(int node) {
    }

    /**
     * @see infovis.tree.DepthFirst.Visitor#postorder(int)
     */
    public void postorder(int node) {
    }

    /**
     * @see infovis.visualization.DefaultVisualization#paintItems(Graphics2D, Rectangle2D)
     */
    public void paintItems(Graphics2D graphics, Rectangle2D bounds) {
        this.graphics = graphics;
        DepthFirst.visit(this, this, root);
    }

    /**
     * Returns the root.
     * @return int
     */
    public int getRoot() {
        return root;
    }

    /**
     * Sets the root.
     * @param root The root to set
     */
    public void setRoot(int root) {
        if (this.root != root) {
            if (!tree.isRowValid(root))
                return;
            if (root != Tree.ROOT && tree.isLeaf(root))
                root = tree.getParent(root);
            this.root = root;
            invalidate();
        }
    }

//    public boolean setSortColumn(Column sortColumn) {
//        if (sortColumn != null) {
//            Aggregation aggr = null;
//            if (AtLeafAggregation.isAtLeaf(sortColumn, tree)
//                == Aggregation.AGGREGATE_YES) {
//                // choose additive aggregation as default, doesn't make sense for dates
//                aggr = AdditiveAggregation.sharedInstance();
//            }
//            else {
//                AggregationCategory factory =
//                    AggregationCategory.sharedInstance();
//                aggr = factory.getAggregation(sortColumn, this);
//            }
//            if (aggr != null) {
//                Column col = aggr.aggregate(sortColumn, this, null);
//                if (col != null) {
//                    sortColumn = col;
//                }
//            }
//        }
//        return super.setVisualColumn(VISUAL_SORT, sortColumn);
//    }

    protected void permuteRows() {
        super.permuteRows();
        if (permutation == null) {
            sortedChildren.clear();
            return;
        }
        DepthFirst.Visitor visitor = new DepthFirst.Visitor() {
            public boolean preorder(int node) {
                if (permutation.getInverse(node) == -1) {
                    sortedChildren.setValueUndefined(node, true);
                    return false;
                }
                IntVector children = new IntVector();
                for (RowIterator citer = tree.childrenIterator(node);
                    citer.hasNext();
                    ) {
                    int c = citer.nextRow();
                    if (permutation.getInverse(c) != -1)
                        children.push(c);
                }
                if (children.size() == 0) {
                    sortedChildren.setValueUndefined(node, true);
                }
                else {
                    int[] cTable = children.toArray(null);
                    if (cTable.length > 1 && comparator != null)
                        Sort.sort(cTable, comparator);
                    sortedChildren.setExtend(node, cTable);
                }
                return true;
            }

            public void inorder(int node) {
            }

            public void postorder(int node) {
            }
        };
        DepthFirst.visit(tree, visitor, Tree.ROOT);

    }

    // Tree Interface

    public RowIterator childrenIterator(int node) {
        if (permutation != null) {
            int[] children = (int[]) sortedChildren.getObjectAt(node);
            if (children == null)
                return NullRowIterator.sharedInstance();
            else
                return new ArrayChildrenIterator(0, children);
        }
        else {
            return tree.childrenIterator(node);
        }
    }

    public int addNode(int par) {
        return tree.addNode(par);
    }
    
    public boolean removeNode(int node) {
        return tree.removeNode(node);
    }
    
    

    public int getChild(int node, int index) {
        if (permutation != null) {
            int[] children = (int[]) sortedChildren.getObjectAt(node);
            if (children != null && children.length > index)
                return children[index];
            return Tree.NIL;
        }
        return tree.getChild(node, index);
    }

    public int getDegree(int node) {
        if (permutation != null) {
            int[] children = (int[]) sortedChildren.getObjectAt(node);
            if (children == null)
                return 0;
            return children.length;
        }
        return tree.getDegree(node);
    }

    public int getDepth(int node) {
        return tree.getDepth(node);
    }

    public int getFirstChild(int node) {
        return getChild(node, 0);
    }

    public int getParent(int node) {
        return tree.getParent(node);
    }

    public boolean isAncestor(int node, int par) {
        return tree.isAncestor(node, par);
    }

    public boolean isLeaf(int node) {
        if (permutation != null) {
            int[] children = (int[]) sortedChildren.getObjectAt(node);
            return children == null;
        }
        return tree.isLeaf(node);
    }

    public void reparent(int node, int newparent) {
        tree.reparent(node, newparent);
    }

    public int nextNode() {
        return tree.nextNode();
    }
    public RowIterator reverseIterator() {
        return tree.reverseIterator();
    }

    public int getNodeCount() {
        return tree.getNodeCount();
    }

    public void addTreeChangedListener(TreeChangedListener l) {
        tree.addTreeChangedListener(l);
    }

    public void removeTreeChangedListener(TreeChangedListener l) {
        tree.removeTreeChangedListener(l);
    }

}
