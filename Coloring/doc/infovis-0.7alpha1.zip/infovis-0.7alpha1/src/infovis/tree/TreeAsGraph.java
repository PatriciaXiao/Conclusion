/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.tree;

import infovis.*;
import infovis.graph.*;
import infovis.graph.GraphChangedListener;
import infovis.graph.GraphException;
import infovis.utils.RowIterator;

import javax.swing.event.EventListenerList;

/**
 * Class TreeAsGraph
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public class TreeAsGraph extends TreeProxy implements Graph, TreeChangedListener {
    protected EventListenerList listeners;

    public TreeAsGraph(Tree tree) {
        super(tree);
        tree.addTreeChangedListener(this);
    }

    public void dispose() {
        tree.removeTreeChangedListener(this);
    }

    public boolean isDirected() {
        return true;
    }

    public void setDirected(boolean directed) {
        if (!directed) {
            throw new GraphException(
                "cannot change a tree into an undirected graph",
                NIL,
                NIL);
        }
    }

    public int getVerticesCount() {
        return tree.getNodeCount();
    }

    public int addVertex() {
        return tree.addNode(Tree.ROOT);
    }

    public void removeVertex(int vertex) {
        tree.removeNode(vertex);
    }

    public int getEdgesCount() {
        return tree.getNodeCount() - 1;
    }

    public int addEdge(int v1, int v2) {
        tree.reparent(v2, v1);
        return v2;
    }

    public void removeEdge(int edge) {
        tree.reparent(edge, Tree.ROOT);
    }

    public int getInVertex(int edge) {
        return tree.getParent(edge);
    }

    public int getOutVertex(int edge) {
        return edge;
    }

    public int getEdgeAt(int vertex, int index) {
        return tree.getChild(vertex, index);
    }

    public int getInEdgeAt(int vertex, int index) {
        if (index == 0)
            return tree.getParent(vertex);
        return NIL;
    }

    public int getEdge(int v1, int v2) {
        return v2;
    }

    public int findEdge(int v1, int v2) {
        return v2;
    }

    public int getDegree(int vertex) {
        return tree.getDegree(vertex);
    }

    public RowIterator edgeIterator(int vertex) {
        return tree.childrenIterator(vertex);
    }

    public int getInDegree(int vertex) {
        if (vertex == Tree.ROOT)
            return 0;
        return 1;
    }

    class ParentIterator implements RowIterator {
        int parent;

        public ParentIterator(int parent) {
            this.parent = parent;
        }

        public int nextRow() {
            int ret = parent;
            parent = NIL;
            return ret;
        }

        public int peekRow() {
            return parent;
        }

        public RowIterator copy() {
            return new ParentIterator(parent);
        }

        public boolean hasNext() {
            return parent != NIL;
        }

        public Object next() {
            return new Integer(nextRow());
        }

        public void remove() {
            if (parent != NIL)
                tree.removeNode(parent);
        }
    };

    public RowIterator inEdgeIterator(int vertex) {
        return new ParentIterator(tree.getParent(vertex));
    }

    public RowIterator vertexIterator() {
        return tree.iterator();
    }

    public RowIterator edgeIterator() {
        RowIterator iter = tree.iterator();
        iter.nextRow(); // skip the root
        return iter;
    }

    public Table getEdgeTable() {
        return tree;
    }

    public Table getVertexTable() {
        return tree;
    }

    public void addGraphChangedListener(GraphChangedListener l) {
        getListeners().add(GraphChangedListener.class, l);
    }

    public void removeGraphChangedListener(GraphChangedListener l) {
        if (listeners == null)
            return;
        listeners.remove(GraphChangedListener.class, l);

    }

    public void treeChanged(TreeChangedEvent ev) {
        if (listeners == null)
            return;
        Object[] ll =
            listeners.getListeners(GraphChangedListener.class);
        if (ll.length == 0)
            return;
        GraphChangedEvent e;
        switch (ev.getType()) {
            case TreeChangedEvent.TREE_NODE_ADDED :
                e =
                    new GraphChangedEvent(
                        this,
                        ev.getNode(),
                        GraphChangedEvent.GRAPH_VERTEX_ADDED);
                for (int i = 0; i < ll.length; i++) {
                    GraphChangedListener l =
                        (GraphChangedListener) ll[i];
                    l.graphChanged(e);
                }
                if (ev.getNode() == Tree.ROOT)
                    break;
                e =
                    new GraphChangedEvent(
                        this,
                        ev.getNode(),
                        GraphChangedEvent.GRAPH_EDGE_ADDED);
                for (int i = 0; i < ll.length; i++) {
                    GraphChangedListener l =
                        (GraphChangedListener) ll[i];
                    l.graphChanged(e);
                }
                break;
            case TreeChangedEvent.TREE_NODE_REMOVED :
                if (ev.getNode() != Tree.ROOT) {
                    e =
                        new GraphChangedEvent(
                            this,
                            ev.getNode(),
                            GraphChangedEvent.GRAPH_EDGE_REMOVED);
                    for (int i = 0; i < ll.length; i++) {
                        GraphChangedListener l =
                            (GraphChangedListener) ll[i];
                        l.graphChanged(e);
                    }
                }
                e =
                    new GraphChangedEvent(
                        this,
                        ev.getNode(),
                        GraphChangedEvent.GRAPH_VERTEX_REMOVED);
                for (int i = 0; i < ll.length; i++) {
                    GraphChangedListener l =
                        (GraphChangedListener) ll[i];
                    l.graphChanged(e);
                }
                break;
            case TreeChangedEvent.TREE_NODE_MOVED :
                e =
                    new GraphChangedEvent(
                        this,
                        ev.getNode(),
                        GraphChangedEvent.GRAPH_EDGE_REMOVED);
                for (int i = 0; i < ll.length; i++) {
                    GraphChangedListener l =
                        (GraphChangedListener) ll[i];
                    l.graphChanged(e);
                }
                e =
                    new GraphChangedEvent(
                        this,
                        ev.getNode(),
                        GraphChangedEvent.GRAPH_EDGE_ADDED);
                for (int i = 0; i < ll.length; i++) {
                    GraphChangedListener l =
                        (GraphChangedListener) ll[i];
                    l.graphChanged(e);
                }
                break;
        }
    }

    protected EventListenerList getListeners() {
        if (listeners == null) {
            listeners = new EventListenerList();
        }
        return listeners;
    }
}
