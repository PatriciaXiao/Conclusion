/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.tree;

import java.util.EventListener;

/**
 * Class TreeChangedListener
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.1 $
 */
public interface TreeChangedListener extends EventListener {
    public abstract void treeChanged(TreeChangedEvent ev);
}
