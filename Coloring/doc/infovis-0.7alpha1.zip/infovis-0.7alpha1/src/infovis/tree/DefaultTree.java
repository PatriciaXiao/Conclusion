/*****************************************************************************
 * Copyright (C) 2003 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the QPL Software License    *
 * a copy of which has been included with this distribution in the           *
 * license-infovis.txt file.                                                 *
 *****************************************************************************/
package infovis.tree;

import java.util.BitSet;

import javax.swing.event.EventListenerList;

import infovis.Table;
import infovis.Tree;
import infovis.column.IntColumn;
import infovis.table.DefaultTable;
import infovis.table.TableProxy;
import infovis.utils.*;


/**
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.11 $
 */
public class DefaultTree extends TableProxy implements Tree {
    /**
     * Name of the IntColumn referencing the first child of a node.
     */
    public static final String CHILD_COLUMN = "#child";

    /**
     * Name of the IntColumn referencing the next sibling of a node.
     */
    public static final String NEXT_COLUMN = "#next";

    /**
     * Name of the IntColumn referencing the last child of a node.
     */
    public static final String LAST_COLUMN = "#last";

    /**
     * Name of the IntColumn referencing the parent of a node.
     */
    public static final String PARENT_COLUMN = "#parent";

    /**
     * Name of the optional IntColumn referencing the depth of a node.
     */
    public static final String DEPTH_COLUMN = "#depth";

    /**
     * Name of the optional IntColumn referencing the degree of a node.
     */
    public static final String DEGREE_COLUMN = "#degree";
    
    protected IdManager    idManager;
    protected IntColumn    child;
    protected IntColumn    next;
    protected IntColumn    last;
    protected IntColumn    parent;
    protected IntColumn    depth;
    protected IntColumn    degree;
    protected EventListenerList listeners;
    
    static final int[] nullInt = new int[0];

    /**
     * Creates a new DefaultTree object.
     */
    public DefaultTree() {
        this(new DefaultTable());
    }
    
    /**
     * Creates a new Tree object from an Table
     *
     * @param table the Table
     */
    protected DefaultTree(Table table) {
        super(table);
        assert(table.getMetadata().get(TREE_METADATA)==null);

        table.getMetadata().put(TREE_METADATA, this);
        idManager = new IdManager();
        child = IntColumn.findColumn(this, CHILD_COLUMN);
        next = IntColumn.findColumn(this, NEXT_COLUMN);
        last = IntColumn.findColumn(this, LAST_COLUMN);
        parent = IntColumn.findColumn(this, PARENT_COLUMN);
        
        if (parent.getRowCount() == 0) { // tree structure just created
            // be paranoid
            last.clear();
            next.clear();
            child.clear();
            int root = idManager.newId();
            assert(root == ROOT);
            child.setExtend(ROOT, NIL);
            next.setExtend(ROOT, NIL);
            last.setExtend(ROOT, NIL);
            parent.setExtend(ROOT, NIL);

            // reroot all the existing rows
            int size = getRowCount();
            for (int i = 1; i < size; i++) {
                addNode(ROOT);
            }
        }
        else {
           //checkAndRepair();
           throw new RuntimeException("Tree structure exists but not inside a tree");
        }
    }
    
    // Overriden from the Table interface
    /**
     * @see infovis.Table#clear()
     */
    public void clear() {
        super.clear();
        try {
            disableNotify();
            idManager.clear();
            idManager.newId();
            child.add(NIL);
            next.add(NIL);
            last.add(NIL);
            parent.add(NIL);
    
            if (depth != null) {
                updateDepth();
            }
            if (degree != null) {
                updateDegree();
            }
        }
        finally {
            enableNotify();
        }
    }

    public RowIterator iterator() {
        return idManager.iterator();
    }
    
    public RowIterator reverseIterator() {
        return idManager.reverseIterator();
    }
    
    public boolean isRowValid(int row) {
        return ! idManager.isFree(row);
    }
    
    // Tree interface
    
    /**
     * @see infovis.Tree#getChild(int, int)
     */
    public int getChild(int node, int index) {
        if (! isRowValid(node))
            return NIL;
        for (int c = getFirstChild(node); c != Tree.NIL; c = getNextSibling(c)) {
            if (index-- == 0)
                return c;
        }
        return NIL;
    }

    /**
     * Returns the parent of a node.
     *
     * @param node the node
     *
     * @return the parent or the NIL value if node is the top node
     */
    public int getParent(int node) {
        if (! isRowValid(node))
            return NIL;
        return parent.get(node);
    }

    /**
     * Returns the iterator over the children of a node.
     *
     * @param node the node
     *
     * @return the iterator over the children of the node
     */
    public RowIterator childrenIterator(int node) {
        if (! isRowValid(node))
            return null;
        return new ChildrenIterator(child.get(node));
    }

    /**
     * Adds a node to the tree.
     *
     * @param par the parent of the node.
     *
     * @return the created node.
     *
     * @throws ArrayIndexOutOfBoundsException DOCUMENT ME!
     */
    public int addNode(int par) {
        if (par == NIL) {
            throw new ArrayIndexOutOfBoundsException(" NIL is an invalid parent except for the root" +
                                                     par);
        }
        int node = idManager.newId();
        
        try {
           disableNotify();
            parent.setExtend(node, par);
            next.setExtend(node, NIL);
            child.setExtend(node, NIL);
            last.setExtend(node, NIL);
    
            if (last.get(par) == NIL) {
                child.set(par, node);
                if (depth != null) {
                    // created a child so update depth along the top
                    depth.setExtend(node, 0);
                    for (int i = par; i != NIL; i = getParent(i)) {
                        depth.set(i, depth.get(i) + 1);
                    }
                }
            } else {
                next.set(last.get(par), node);
            }
    
            last.set(par, node);
    
            if (degree != null) {
                degree.setExtend(node, 0);
                degree.set(par, degree.get(par) + 1);
            }
    
            if (depth != null) {
                depth.setExtend(node, depth.get(par)+1);
            }
        }
        finally {
            enableNotify();
        }
        fireTreeChangedListeners(node, TreeChangedEvent.TREE_NODE_ADDED);
        return node;
    }
    
    public int getNodeCount() {
        return idManager.getIdCount();
    }


    public boolean removeNode(int node) {
        if (!isRowValid(node))
            return false;
        if (node == 0) {
            clear();
        }
        else {
            removeChild(node);
            idManager.free(node);
            // don't touch the columns
        }
        fireTreeChangedListeners(node, TreeChangedEvent.TREE_NODE_REMOVED);
        return true;
    }

    /**
     * Returns the next node to be returned by addNode.
     *
     * @return the next node to be returned by addNode.
     */
    public int nextNode() {
        int next = idManager.newId();
        idManager.free(next);
        return next;
    }

    /**
     * Change the parent of a specified node, changing the structure.
     *
     * @param node the node.
     * @param newparent the new parent.
     *
     * @throws RuntimeException if the node is an ancestor of the parent.
     */
    public void reparent(int node, int newparent) {
        if (isAncestor(newparent, node))
            throw new RuntimeException("cannot reparent into a child");
        int par = getParent(node);
        if (par == newparent)
            return;
        removeChild(node);
        addChild(node, newparent);
        updateDegree();
        updateDepth();
        fireTreeChangedListeners(node, TreeChangedEvent.TREE_NODE_MOVED);
    }
    

    /**
     * Returns true if the first node has the second node as ancestor.
     *
     * @param node the node.
     * @param par the tested ancestor.
     *
     * @return true if the first node has the second node as ancestor.
     */
    public boolean isAncestor(int node, int par) {
        while (node != NIL) {
            if (node == par) {
                return true;
            }

            node = getParent(node);
        }

        return false;
    }
    
    /**
     * Returns the depth of a node using either a depth column if it has been computed or
     * the computeDepth method.
     *
     * @param node the node.
     *
     * @return the depth of the node.
     */
    public int getDepth(int node) {
        if (depth != null)
            return depth.get(node);
        return computeDepth(node);
    }

    /**
     * Returns the degree of a node using either a degree column if it has been computed or
     * the computeDegree method.
     *
     * @param node the node.
     *
     * @return the depth of the node.
     */
    public int getDegree(int node) {
        if (degree != null)
            return degree.get(node);
        return computeDegree(node);
    }

    /**
     * Returns the first child of a node.
     *
     * @param node the node
     *
     * @return the first child or NIL value if node has no child
     */
    public int getFirstChild(int node) {
        if (! isRowValid(node))
            return NIL;
        return child.get(node);
    }

    /**
     * Returns the next sibling of a node.
     *
     * @param node the node
     *
     * @return the next sibling or the NIL value if node is the last sibling
     */
    public int getNextSibling(int node) {
        if (! isRowValid(node))
            return NIL;
        return next.get(node);
    }

    /**
     * Returns the last child of a node.
     *
     * @param node the node
     *
     * @return the last child or the NIL value if node has no child.
     */
    public int getLastChild(int node) {
        if (! isRowValid(node))
            return NIL;
        return last.get(node);
    }

    protected void removeChild(int node) {
        try {
            disableNotify();
            int par = getParent(node);
            parent.set(node, NIL);
            if (getFirstChild(par) == node) {
                child.set(par, getNextSibling(node));
                if (getLastChild(par) == node) {
                    last.set(par, NIL);
                }
    
                // If we are first, no previous to update
                // If we are also last, nothing else to do
            }
            else {
                // Not first, chase the previous to change its next pointer.
                int n;
                for (n = getFirstChild(par); n != NIL; n = getNextSibling(n)) {
                    if (getNextSibling(n) == node) {
                        // got it
                        next.set(n, getNextSibling(node));
                        break;
                    }
                }
                if (getLastChild(par) == node) {
                    assert (getNextSibling(node) == NIL);
                    last.set(par, n);
                }
            }
            if (depth != null) {
                depth.setValueUndefined(node, true);
            }
            if (degree != null) {
                degree.set(par, degree.get(par)-1);
            }
        }
        finally {
            enableNotify();
        }
    }

    protected void addChild(int node, int par) {
        try {
            disableNotify();
            parent.setExtend(node, par);
            next.setExtend(node, NIL);
    
            if (last.get(par) == NIL) {
                child.set(par, node);
            } else {
                next.set(last.get(par), node);
            }
    
            last.set(par, node);
    
            if (depth != null) {
                depth.set(node, depth.get(par)+1);
            }
            if (degree != null) {
                degree.set(par, degree.get(par)+1);
            }
        }
        finally {
            enableNotify();
        }
    }

    /**
     * Computes the depth of the node in the tree and return it.
     *
     * @param node the node.
     *
     * @return the depth of the node in the tree.
     */
    public int computeDepth(int node) {
        int depth = 0;
        while (node != ROOT) {
            node = getParent(node);
            depth++;
        }
        return depth;
    }

    /**
     * Creates a column to hold the computed depth of each node,
     * avoiding its computation when needed.
     * Does nothing if the column already exists.
     */
    public void createDepthColumn() {
        if (depth != null)
            return;
        depth = IntColumn.findColumn(this, DEPTH_COLUMN);
        updateDepth();
    }

    protected void updateDepth() {
        if (depth == null)
            return;
        for (int node = 0; node < parent.getRowCount(); node++) {
            depth.setExtend(node, computeDepth(node));
        }
    }

    /**
     * Returns true if a depth column has been computed.
     *
     * @return true if a depth column has been computed.
     */
    public boolean hasDepthColumn() {
        return depth != null;
    }

    /**
     * Returns the degree of a node, i.e. the number of children
     *
     * @param node the node
     *
     * @return the degree of the node
     */
    public int computeDegree(int node) {
        int degree = 0;

        for (int n = child.get(node); n != NIL; n = next.get(n)) {
            degree++;
        }

        return degree;
    }

    /**
     * Creates a column holding the degree of nodes.
     *
     * <p>Accelerates degree queries if they are frequent but
     * slows down structural changes since the column needs to
     * be updated.
     *
     */
    public void createDegreeColumn() {
        if (degree != null)
            return;
        degree = IntColumn.findColumn(this, DEGREE_COLUMN);
        updateDegree();
    }

    protected void updateDegree() {
        if (degree == null)
            return;
        for (int node = 0; node < child.getRowCount(); node++) {
            degree.setExtend(node, computeDegree(node));
        }
    }

    /**
     * Returns true if the node is a leaf_node. Use this method rather than
     * degree(node)==0
     *
     * @param node the node
     *
     * @return true if the node is a leaf_node.
     */
    public boolean isLeaf(int node) {
        if (!isRowValid(node))
            return false;
        return getFirstChild(node) == NIL;
    }    

    /**
     * Returns a Tree created from a Table.
     * If the Table is already a tree, it is returned.
     * If the table is already managed as a tree, the managing tree is returned.
     * Otherwise, a DefaultTree is created using this Table.
     * 
     * @param table the Table from which the Tree should be returned.
     * @return A Tree sharing the contents of this table.
     */
    public static Tree findTree(Table table) {
        if (table instanceof Tree) {
            return (Tree)table;
        }
        Tree tree = (Tree)table.getMetadata().get(TREE_METADATA);
        if (tree == null) {
            tree = new DefaultTree(table);
        }
        return tree;
    }
    
    /**
     * Checks and repairs the tree structure if needed.
     * 
     * @return false if the structure had to be repaired.
     */
    public boolean checkAndRepair() {
//      TODO: check with idManager
        boolean ret = true;
        BitSet visited = new BitSet(getRowCount());
        int bad;
        try {
            disableNotify();
            // first check structure
            do {
                visited.clear();
                bad = check(ROOT, visited);
                if (bad != NIL) {
                    if (bad == ROOT) {
                        child.setExtend(ROOT, NIL);
                        next.setExtend(ROOT, NIL);
                        last.setExtend(ROOT, NIL);
                        parent.setExtend(ROOT, NIL);
                    }
                    else {
                        reparent(bad, ROOT);
                    }
                    ret = false;
                }
            }
            while(bad != NIL);
            
            // now, reroot orphans
            for (RowIterator iter = iterator(); iter.hasNext(); ) {
                int node = iter.nextRow();
                if (! visited.get(node)) {
                    reparent(node, ROOT);
                    ret = false;
                }
            }
        }
        finally {
            enableNotify();        
        }
        return ret;
    }

    protected int check(int node, BitSet visited) {
//      TODO: check with idManager
        if (visited.get(node))
            return node;
        visited.set(node, true);
        for (int c = getFirstChild(node); c != NIL; c = getNextSibling(c)) {
            int ret = check(c, visited);
            if (ret != NIL) return ret;
        }
        return NIL;
    }
    
    protected void disableNotify() {
        child.disableNotify();
        next.disableNotify();
        last.disableNotify();
        parent.disableNotify();
        if (depth != null)
            depth.disableNotify();
        if (degree != null)
            degree.disableNotify();        
    }

    protected void enableNotify() {
        child.enableNotify();
        next.enableNotify();
        last.enableNotify();
        parent.enableNotify();
        if (depth != null)
            depth.enableNotify();
        if (degree != null)
            degree.enableNotify();        
    }

    /**
     * Sorts the node children according to a <code>RowComparator</code>
     *
     * @param node the node.
     * @param comp the comparator.
     */
    protected void sortChildren(int node, RowComparator comp) {
        int[] c = children(node);

        if (c == null || c.length < 2) {
            return;
        }

        Sort.sort(c, comp);
    }

    /**
     * Returns a table of children of this node.
     *
     * @param node the node.
     *
     * @return a table of childen of the given node
     * or null is the node has no child.
     */
    public int[] children(int node) {
        int   n = getDegree(node);
        int[] c;
        if (n == 0)
            c = nullInt;
        else {
            c = new int[n];
            int i = 0;

            for (int child = getFirstChild(node); child != NIL;
                     child = getNextSibling(child))
                c[i++] = child;
        }
        return c;
    }

    /**
     * Traverse the tree with a depth first traversal, calling the visitor at
     * each node.
     *
     * @param visitor the <code>DepthFirstVisitor</code>.
     */
    public void visit(DepthFirst.Visitor visitor) {
        DepthFirst.visit(this, visitor, ROOT);
    }

    /**
     * Traverse the tree with a depth first traversal, calling the visitor at
     * each node.
     *
     * @param visitor the <code>DepthFirstVisitor</code>.
     */
    public void visit(BreadthFirst.Visitor visitor) {
        BreadthFirst.visit(this, visitor, ROOT, new IntVector());
    }

    class ChildrenIterator implements RowIterator {
        int node;

        public ChildrenIterator(int node) {
            this.node = node;
        }

        public boolean hasNext() {
            return node != NIL;
        }

        public Object next() {
            return new Integer(nextRow());
        }

        public void remove() {
        }

        public int nextRow() {
            int n = node;
            node = next.get(node);

            return n;
        }

        public int peekRow() {
            return node;
        }
        
        /**
         * @see infovis.utils.RowIterator#copy()
         */
        public RowIterator copy() {
            return new ChildrenIterator(node);
        }

    }
    
    public void addTreeChangedListener(TreeChangedListener l) {
        getListeners().add(TreeChangedListener.class, l);
    }

    public void removeTreeChangedListener(TreeChangedListener l) {
        if (listeners == null) return;
        listeners.remove(TreeChangedListener.class, l);
    }


    protected EventListenerList getListeners() {
        if (listeners == null) {
            listeners = new EventListenerList();
        }
        return listeners;
    }
    
    protected void fireTreeChangedListeners(int node, short type) {
        if (listeners == null) return;
        fireTreeChangedListeners(new TreeChangedEvent(this, node, type));
    }
    
    protected void fireTreeChangedListeners(TreeChangedEvent e) {
        if (listeners == null) return;
    
        Object[] ll = listeners.getListeners(TreeChangedListener.class);
        for (int i = 0; i < ll.length; i++) {
            TreeChangedListener l = (TreeChangedListener)ll[i];
            l.treeChanged(e);
        }
    }
}
