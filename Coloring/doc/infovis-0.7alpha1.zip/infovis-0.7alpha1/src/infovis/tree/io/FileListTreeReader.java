/*****************************************************************************
 * Copyright (C) 2004 Jean-Daniel Fekete and INRIA, France                   *
 * ------------------------------------------------------------------------- *
 * See the file LICENCE.TXT for license information.                         *
 *****************************************************************************/
package infovis.tree.io;

import infovis.Tree;
import infovis.column.IntColumn;
import infovis.column.StringColumn;
import infovis.io.WrongFormatException;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * Class FileListTreeReader
 * 
 * Creates a tree from a list of file names, one per line.
 * 
 * @author Jean-Daniel Fekete
 * @version $Revision: 1.12 $
 */
public class FileListTreeReader extends AbstractTreeReader {
    protected StringColumn nameColumn;
    protected IntColumn indexColumn;
    protected String prefix;
    protected String separator = "/";

    public FileListTreeReader(
        BufferedReader in,
        String name,
        Tree tree) {
        super(in, name, tree);
        nameColumn = StringColumn.findColumn(tree, "name");
        prefix = "";
    }
    
    public boolean load() throws WrongFormatException {
        int lineNum = 0;
        try {
            while (! isEof()) {
                String line = in.readLine();
                if (line == null)
                    break;
                if (! line.startsWith(prefix)) {
                    continue;
                }
                String[] path =
                    line.substring(prefix.length()).split(separator);
                int parent = Tree.ROOT;
                for (int j = 0; j < path.length; j++) {
                    String name = path[j];
                    if (name.length() == 0)
                        continue;
                    parent = findNode(name, parent, tree, nameColumn);
                }
                if (indexColumn != null) {
                    indexColumn.setExtend(parent, lineNum);
                }
                lineNum++;
            }
        }
        catch(IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }


    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String string) {
        prefix = string;
    }

    public String getSeparator() {
        return separator;
    }

    public void setSeparator(String string) {
        separator = string;
    }

    public IntColumn getIndexColumn() {
        return indexColumn;
    }

    public void setIndexColumn(IntColumn column) {
        indexColumn = column;
    }

}
